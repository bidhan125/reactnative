import 'semantic-ui-css/semantic.min.css';
import 'react-tiny-fab/dist/styles.css';
import '../imports/startup/client/routes';

import 'toastr/build/toastr.min.css';
