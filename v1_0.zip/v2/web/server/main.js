import { Meteor } from 'meteor/meteor';

import '../imports/startup/server/index';

Meteor.startup(() => {
  // code to run on server at startup
});
