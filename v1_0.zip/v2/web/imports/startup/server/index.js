import '../../api/users/server/methods';
import '../../api/users/server/publications';

import '../../api/doctors/server/methods';
import '../../api/doctors/server/publications';

import '../../api/appointments/server/methods';
import '../../api/appointments/server/publications';

import '../../api/diagnosticTests/server/methods';
import '../../api/diagnosticTests/server/publications';

import '../../api/utils/server/methods';
import '../../api/utils/server/publications';

import '../../api/orders/server/methods';
import '../../api/orders/server/publications';

import '../../api/medicines/server/methods';
import '../../api/medicines/server/publications';

import '../../api/medAccessories/server/methods';
import '../../api/medAccessories/server/publications';

import '../../api/reports/server/methods';

import '../../api/medicalHistory/server/methods';
