import React from 'react';
import { FlowRouter } from 'meteor/kadira:flow-router';
import { mount } from 'react-mounter';

import AdminLayout from '../../ui/layouts/adminLayout';

import Login from '../../ui/pages/auth/login';
import ForgotPassword from '../../ui/pages/auth/forgotPassword';
import Register from '../../ui/pages/auth/register';
import ResetPassword from '../../ui/pages/auth/resetPassword';

import Dashboard from '../../ui/components/home/dashboard';
import DoctorList from '../../ui/components/users/doctorsList';
import UsersList from '../../ui/components/users/usersList';
import MedicineList from '../../ui/components/medicine/medicineList';
import TestReports from '../../ui/components/testReports/testReports';
import HealthCare from '../../ui/components/healthcare/healthCare';
import Appointments from '../../ui/components/appointments/appointments';
import MedAccessories from '../../ui/components/medAccessories/medAccessories';
import Feedbacks from '../../ui/components/utils/feedbacks';
import Orders from '../../ui/components/orders/orders';
import Profile from '../../ui/components/users/profile';

console.log('v-0.1.3');

FlowRouter.route('/', {
	action(params, queryParams) {
		Meteor.userId()
			? mount(AdminLayout, { content: <Dashboard /> })
			: mount(Login, {
					content: <Login />
			  });
	}
});

FlowRouter.route('/login', {
	action(params, queryParams) {
		Meteor.userId() ? FlowRouter.go('/') : mount(Login);
	}
});

FlowRouter.route('/forgot-password', {
	action(params, queryParams) {
		Meteor.userId() ? FlowRouter.go('/') : mount(ForgotPassword);
	}
});

FlowRouter.route('/register', {
	action(params, queryParams) {
		Meteor.userId() ? FlowRouter.go('/') : mount(Register);
	}
});

FlowRouter.route('/reset-password', {
	action(params, queryParams) {
		Meteor.userId() ? FlowRouter.go('/') : mount(ResetPassword);
	}
});

FlowRouter.route('/home', {
	action(params, queryParams) {
		Meteor.userId()
			? mount(AdminLayout, { content: <Dashboard /> })
			: FlowRouter.go('/login');
	}
});

FlowRouter.route('/doctors', {
	action(params, queryParams) {
		Meteor.userId()
			? mount(AdminLayout, { content: <DoctorList /> })
			: FlowRouter.go('/login');
	}
});

FlowRouter.route('/users', {
	action(params, queryParams) {
		Meteor.userId()
			? mount(AdminLayout, { content: <UsersList /> })
			: FlowRouter.go('/login');
	}
});

FlowRouter.route('/appointments', {
	action(params, queryParams) {
		Meteor.userId()
			? mount(AdminLayout, { content: <Appointments /> })
			: FlowRouter.go('/login');
	}
});

FlowRouter.route('/orders', {
	action(params, queryParams) {
		Meteor.userId()
			? mount(AdminLayout, { content: <Orders /> })
			: FlowRouter.go('/login');
	}
});

FlowRouter.route('/home-care', {
	action(params, queryParams) {
		Meteor.userId()
			? mount(AdminLayout, { content: <HealthCare /> })
			: FlowRouter.go('/login');
	}
});

FlowRouter.route('/medicine-center', {
	action(params, queryParams) {
		Meteor.userId()
			? mount(AdminLayout, { content: <MedicineList /> })
			: FlowRouter.go('/login');
	}
});

FlowRouter.route('/medical-test', {
	action(params, queryParams) {
		Meteor.userId()
			? mount(AdminLayout, { content: <TestReports /> })
			: FlowRouter.go('/login');
	}
});

FlowRouter.route('/medical-accessories', {
	action(params, queryParams) {
		Meteor.userId()
			? mount(AdminLayout, { content: <MedAccessories /> })
			: FlowRouter.go('/login');
	}
});

FlowRouter.route('/feedbacks', {
	action(params, queryParams) {
		Meteor.userId()
			? mount(AdminLayout, { content: <Feedbacks /> })
			: FlowRouter.go('/login');
	}
});

FlowRouter.route('/profile', {
	action(params, queryParams) {
		Meteor.userId()
			? mount(AdminLayout, { content: <Profile /> })
			: FlowRouter.go('/login');
	}
});
