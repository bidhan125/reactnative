import React from 'react';
import {
	Container,
	Sidebar,
	Segment,
	Menu,
	Header,
	Icon,
	Divider
} from 'semantic-ui-react';
import { FlowRouter } from 'meteor/kadira:flow-router';

import { version } from '../../const';

export default class AdminLayout extends React.Component {
	constructor(props) {
		super(props);

		this.state = {
			visible: true,
			ar: [null, null]
		};
	}

	componentDidMount() {
		Tracker.autorun(() => {
			FlowRouter.watchPathChange();
			this.setState({
				ar: FlowRouter.current().path.split('/')
			});
		});
	}

	render() {
		const { visible } = this.state;
		return (
			<div className='ui segment'>
				{/* <Sidebar.Pushable as={Segment}> */}
				<Sidebar
					as={Menu}
					animation='slide along'
					icon='labeled'
					inverted
					//onHide={this.handleSidebarHide}slide along slide out uncover
					vertical
					visible={this.state.visible}
					width='thin'
				>
					<Menu.Item
						as='a'
						to='/'
						link='/home'
						name='dashboard'
						active={this.state.ar[1] == 'home'}
						onClick={() => FlowRouter.go('/home')}
					>
						{/* <Icon name="dashboard" /> */}
						<Icon size='huge' name='dashboard' />
						DashBoard
					</Menu.Item>

					<Menu.Item
						name='test'
						active={this.state.ar[1] == 'orders'}
						onClick={() => FlowRouter.go('/orders')}
					>
						<i className='cart arrow down icon' />
						Orders
					</Menu.Item>
					<Menu.Item
						name='appointments'
						active={this.state.ar[1] == 'appointments'}
						onClick={() => FlowRouter.go('/appointments')}
					>
						<i className='calendar alternate icon' />
						Appointments
					</Menu.Item>

					<Menu.Item
						as='a'
						to='/medicine'
						link='/home'
						name='medicine'
						active={this.state.ar[1] == 'users'}
						onClick={() => FlowRouter.go('/users')}
					>
						<i className='users icon' />
						Users
					</Menu.Item>
					<Menu.Item
						as='a'
						to='/doctors'
						link='/home'
						name='doctor'
						active={this.state.ar[1] == 'doctors'}
						onClick={() => FlowRouter.go('/doctors')}
					>
						<Icon name='doctor' />
						Doctor
					</Menu.Item>
					<Menu.Item
						name='test'
						active={this.state.ar[1] == 'medical-test'}
						onClick={() => FlowRouter.go('/medical-test')}
					>
						<i className='medkit icon' />
						Diagnostic Tests
					</Menu.Item>

					<Menu.Item
						as='a'
						to='/medicine'
						link='/medicine-center'
						name='medicine'
						active={this.state.ar[1] == 'medicine-center'}
						onClick={() => FlowRouter.go('/medicine-center')}
					>
						<i className='pills icon' />
						Medicine
					</Menu.Item>
					{/* <Menu.Item
              name="HomeCare"
              active={this.state.ar[1] == 'home-care'}
              onClick={() => FlowRouter.go('/home-care')}
            >
              <Icon name="wheelchair" />
              Home Care
            </Menu.Item> */}
					<Menu.Item
						name='Medical Accessories'
						active={this.state.ar[1] == 'medical-accessories'}
						onClick={() => FlowRouter.go('/medical-accessories')}
					>
						<Icon name='medkit' />
						Medical Accessories
					</Menu.Item>
					<Menu.Item
						name='Feebacks'
						active={this.state.ar[1] == 'feedbacks'}
						onClick={() => FlowRouter.go('/feedbacks')}
					>
						<Icon name='file alternate ' />
						Feedbacks
					</Menu.Item>
					<Menu.Item
						name='signout'
						active={this.state.ar[1] == ''}
						onClick={() => {
							Meteor.logout(() => {
								FlowRouter.go('/Login');
							});
						}}
					>
						<Icon name='sign out' />
						Sign Out
					</Menu.Item>
					<div className='copyrightinfo'>
						<p>Version {version} </p>
						<span>Powered by Durbin Labs Ltd.</span>
					</div>
				</Sidebar>

				<div style={{ 'padding-left': '150px' }}>
					<div className='topBar'>
						<Header as='h1' content='LabAid LifePlus' />
						<a className='profile-link' href='/profile'>
							<Icon name='user' circular size='small' />
						</a>
						<Divider className='topbar' />
					</div>
					<div>{this.props.content}</div>
				</div>
				{/* </Sidebar.Pushable> */}
			</div>
		);
	}
}
