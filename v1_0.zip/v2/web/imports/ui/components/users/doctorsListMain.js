import React from 'react';
import {
	Modal,
	Header,
	Image,
	Segment,
	Card,
	Button,
	Icon,
	Select,
	Dropdown
} from 'semantic-ui-react';
import { Meteor } from 'meteor/meteor';
import toastr from 'toastr';

import { DoctorDetailsModal } from './modals';
import { AddDoctorModal } from './modals';
import { isValid } from '../utils/phoneNumber';

export default class DoctorsListMain extends React.Component {
	constructor(props) {
		super(props);

		this.state = {
			visibilityDetailsModal: false,
			visibilityEditsModal: false,
			doctorItem: {}
		};
	}

	updateState(obj) {
		this.setState(obj);
	}

	updateStateDoctor(obj) {
		this.setState({
			doctorItem: {
				...this.state.doctorItem,
				...obj
			}
		});
	}

	updateStateArray(key, arr) {
		const { doctorItem } = this.state;
		doctorItem[key] = arr;
		this.setState(doctorItem);
	}

	handleUpdate() {
		const { doctorItem } = this.state;
		delete doctorItem.degreeSingle;
		delete doctorItem.expSingle;
		const bmdcNoInt = parseInt(doctorItem.bmdcNo);

		if (isNaN(bmdcNoInt) || bmdcNoInt <= 0 || bmdcNoInt > 120000) {
			toastr.error('Please enter a valid BMDC Number.');
			return;
		}

		if (!isValid(doctorItem.phone)) {
			toastr.error('Please enter a valid Phone Number.');
			return;
		}

		if (!doctorItem.name) {
			toastr.error('Please enter Name of the doctor');
			return;
		}

		if (!doctorItem.branch) {
			toastr.error('Please select a Branch');
			return;
		}

		if (!doctorItem.speciality) {
			toastr.error('Please select Speciality');
			return;
		}

		if (!doctorItem.experiences || !doctorItem.experiences.length) {
			toastr.error('Please provide Experiences of the doctor');
			return;
		}

		if (!doctorItem.degrees || !doctorItem.degrees.length) {
			toastr.error('Please provide Degrees of the doctor');
			return;
		}

		Meteor.call('updateDoctor', doctorItem, (err, res) => {
			console.log(err, res);
			if (err)
				alert(
					'Sorry! Failed to update doctor profile. Please try again later.'
				);
			else if (res) {
				toastr.success('Doctor updated successfully!');
				this.setState({ visibilityEditsModal: false });
			}
		});
	}

	render() {
		const {
			doctor,
			branches,
			specialities,
			speciality,
			branch,
			gender
		} = this.props;
		const {
			doctorItem,
			visibilityDetailsModal,
			visibilityEditsModal
		} = this.state;

		const branchOptions = branches.map((item, sl_no) => {
			return { key: sl_no, text: item.name, value: item.name };
		});

		const specialityOptions = specialities.map((item, sl_no) => {
			return { key: sl_no, text: item.name, value: item.name };
		});

		const genderOptions = [
			{ key: 1, text: 'Male', value: 'male' },
			{ key: 2, text: 'Female', value: 'female' }
		];

		return (
			// <div className="page">
			<React.Fragment>
				<DoctorDetailsModal
					visibility={visibilityDetailsModal}
					visibilityname='visibilityDetailsModal'
					heading="Doctor's Details"
					doctor={doctorItem}
					updateState={this.updateState.bind(this)}
				/>
				<AddDoctorModal
					title='Update Doctor'
					visibility={visibilityEditsModal}
					visibilityname='visibilityEditsModal'
					branches={branches}
					doctor={doctorItem}
					specialities={specialities}
					edit={true}
					handleSubmit={this.handleUpdate.bind(this)}
					updateState={this.updateState.bind(this)}
					updateStateDoctor={this.updateStateDoctor.bind(this)}
					updateStateArray={this.updateStateArray.bind(this)}
				/>
				<div className='infoTopBar'>
					<div className='ui transparent left icon input patientSrc left floated'>
						{/* <input type="text" placeholder="Search..." /> */}
						<Header as='h4'>
							<Icon name='filter' />
							<Header.Content>Filter Doctors</Header.Content>
						</Header>
					</div>
					<div className='filterContainer'>
						<ul>
							{/* <li style={{ fontWeight: 'bold' }}>Filter:</li> */}
							<li>
								<Dropdown
									selection={true}
									options={genderOptions}
									placeholder='Select Gender'
									value={gender ? gender : null}
									onChange={(e, data) =>
										this.props.handleStateParent({ gender: data.value })
									}
								/>
							</li>
							<li>
								<Dropdown
									selection={true}
									options={branchOptions}
									placeholder='Select Branch'
									value={branch ? branch : null}
									onChange={(e, data) =>
										this.props.handleStateParent({ branch: data.value })
									}
								/>
							</li>
							<li>
								<Dropdown
									selection={true}
									options={specialityOptions}
									placeholder='Select Speciality'
									value={speciality ? speciality : null}
									onChange={(e, data) =>
										this.props.handleStateParent({ speciality: data.value })
									}
								/>
							</li>
							<li style={{ marginLeft: '15px' }}>
								<button
									className='ui teal small button'
									style={{ margin: '0' }}
									onClick={() =>
										this.props.handleStateParent({
											gender: undefined,
											branch: undefined,
											speciality: undefined
										})
									}
								>
									Clear Filter
								</button>
								{/* <button className="ui small basic red button">Delete</button> */}
							</li>
						</ul>
					</div>
				</div>
				<Segment basic>
					<Card.Group>
						{doctor.map((item, idx) => (
							<Card href='' key={idx}>
								<Card.Content>
									<Image
										floated='right'
										size='mini'
										src={
											item.gender == 'male'
												? 'images/doctor.jpg'
												: 'images/doctor_female.png'
										}
									/>
									<Card.Header>{item.name}</Card.Header>
									<Card.Meta>
										{' '}
										{item.speciality
											? item.speciality
											: 'Speciality unavailable'}{' '}
									</Card.Meta>
									<Card.Description>
										{item.availability ? <b>Available</b> : 'Unnavailable'}
									</Card.Description>
									<Card.Description>
										{'Phone: ' +
											(item.phone ? item.phone : 'Description unavailable')}
									</Card.Description>
								</Card.Content>
								<Card.Content extra>
									<div className='ui two buttons'>
										<Button
											basic
											color='green'
											onClick={() => {
												this.setState({ doctorItem: item }, () =>
													this.setState({ visibilityDetailsModal: true })
												);
											}}
										>
											Details
										</Button>
										<Button
											basic
											color='blue'
											onClick={() =>
												this.setState({ doctorItem: item }, () => {
													this.setState({ visibilityEditsModal: true });
												})
											}
										>
											Edit
										</Button>
									</div>
								</Card.Content>
							</Card>
						))}
						{/* <button className="circular ui icon blue button complainAddBtn">
              <i className="icon add" />
            </button> */}
					</Card.Group>
				</Segment>
			</React.Fragment>
			// </div>
		);
	}
}
