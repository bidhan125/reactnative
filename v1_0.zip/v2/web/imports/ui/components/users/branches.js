import React from 'react';
import { withTracker } from 'meteor/react-meteor-data';
import { Icon, Menu, Table, Header } from 'semantic-ui-react';
import { Fab, Action } from 'react-tiny-fab';
import { titleCase } from '../../../const';
import { Branches } from '../../../api/doctors/branches';

class BranchList extends React.Component {
  render() {
    console.log(this.props);
    const { list } = this.props;

    return (
      <Table celled selectable>
        <Table.Header>
          <Table.Row>
            <Table.HeaderCell>Sl. No.</Table.HeaderCell>
            <Table.HeaderCell>Branch Name</Table.HeaderCell>
            <Table.HeaderCell>Phone Number</Table.HeaderCell>
            <Table.HeaderCell>Address</Table.HeaderCell>
            <Table.HeaderCell>District</Table.HeaderCell>
            <Table.HeaderCell>Creation Date</Table.HeaderCell>
          </Table.Row>
        </Table.Header>
        <Table.Body>
          {list &&
            list.length &&
            list.map((item, sl_no) => {
              return (
                <Table.Row>
                  <Table.Cell>{sl_no + 1}</Table.Cell>
                  <Table.Cell>{item.name}</Table.Cell>
                  <Table.Cell>{item.phone}</Table.Cell>
                  <Table.Cell>{item.address}</Table.Cell>
                  <Table.Cell>{titleCase(item.district)}</Table.Cell>
                  <Table.Cell>
                    {item.createdAt && item.createdAt.toLocaleDateString()}
                  </Table.Cell>
                </Table.Row>
              );
            })}
        </Table.Body>
      </Table>
    );
  }
}

export default withTracker(props => {
  // console.log(props);
  const handle = Meteor.subscribe('fetch.branches');

  return {
    ready: !handle.ready(),
    list: Branches.find().fetch(),
  };
})(BranchList);
