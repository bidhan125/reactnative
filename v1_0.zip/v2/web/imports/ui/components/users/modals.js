import React from 'react';
import { Button, Modal, Icon, Form, Dropdown, Input, List, Table } from 'semantic-ui-react';
import toastr from 'toastr'

import { district, districtList, titleCase } from '../../../const';
const genderOptions = [
  { key: 'm', text: 'Male', value: 'Male' },
  { key: 'f', text: 'Female', value: 'Female' },
];

export const DoctorDetailsModal = props => {
  const {
    name,
    bmdcNo,
    phone,
    gender,
    availability,
    email,
    branch,
    speciality,
    degrees,
    experiences,
  } = props.doctor;

  // console.log(props)

  return (
    <Modal
      header="Reminder!"
      open={props.visibility}
      actions={['Ok', 'Cancel']}
      size="tiny"
    >
      <Modal.Header>{props.heading}</Modal.Header>
      <Modal.Content>
      <Table basic='very' textAlign='left' >
      <Table.Body>
      <Table.Row >
        <Table.Cell><b>Name:</b> </Table.Cell>
        <Table.Cell>{name}</Table.Cell>
      </Table.Row>
      <Table.Row >
        <Table.Cell><b>BMDC Number:</b> </Table.Cell>
        <Table.Cell>{bmdcNo}</Table.Cell>
      </Table.Row>
      <Table.Row >
        <Table.Cell><b>Phone:</b> </Table.Cell>
        <Table.Cell>{phone}</Table.Cell>
      </Table.Row>
      <Table.Row >
        <Table.Cell><b>Gender:</b> </Table.Cell>
        <Table.Cell>{titleCase(gender)}</Table.Cell>
      </Table.Row>
      <Table.Row >
        <Table.Cell><b>Available:</b> </Table.Cell>
        <Table.Cell>{ (availability ? '' : 'Not ' )+ 'Available' }</Table.Cell>
      </Table.Row>
      <Table.Row >
        <Table.Cell><b>Branch:</b> </Table.Cell>
        <Table.Cell>{branch}</Table.Cell>
      </Table.Row>
      <Table.Row >
        <Table.Cell><b>Speciality:</b> </Table.Cell>
        <Table.Cell>{speciality}</Table.Cell>
      </Table.Row>
      <Table.Row >
        <Table.Cell><b>Degrees:</b> </Table.Cell>
        <Table.Cell> <List  bulleted >
          { !!degrees && degrees.map(item => <List.Item>{item}</List.Item>) } 
          </List>
          </Table.Cell>
      </Table.Row>
      <Table.Row >
        <Table.Cell><b>Experiences:</b> </Table.Cell>
        <Table.Cell> <List  bulleted >
          { !!experiences && experiences.map(item => <List.Item>{item}</List.Item>) } 
          </List>
          </Table.Cell>
      </Table.Row>
    </Table.Body>
      </Table>
      </Modal.Content>
      <Modal.Actions>
        <Button
          basic
          color="red"
          onClick={() => {
            props.updateState({ [props.visibilityname]: false });
          }}
        >
          <Icon name="remove" /> Close
        </Button>
      </Modal.Actions>
    </Modal>
  )
}

export const AddUserModal = props => {
  const {name, phone, email, gender, employeeId} = props;
  return (
  <Modal header="Reminder!" open={props.visibility} actions={['Ok', 'Cancel']}>
    <Modal.Header>User Details</Modal.Header>
    <Modal.Content>
      <Form>
        <Form.Field>
          <label>Full Name</label>
          <input placeholder="Full Name" 
              value={name}
              onChange={v => props.updateState({ name: v.target.value })} />
        </Form.Field>
        <Form.Field>
          <label>Phone Number(Phone number will be used to login)</label>
          <input placeholder="Phone Number"  
              value={phone}
              onChange={v => props.updateState({ phone: v.target.value })}/>
        </Form.Field>
        <Form.Field>
          <label>Initial Password</label>
          <input placeholder="Initial Password"  
              onChange={v => props.updateState({ password: v.target.value })}/>
        </Form.Field>
        <Form.Field>
          <Form.Select
            fluid
            label="Gender"
            value={gender}
            options={genderOptions}
            placeholder="Gender"
            onChange={(e, v) => props.updateState({ gender: v.value })}
          />
        </Form.Field>
        <Form.Field>
          <label>Email Address</label>
          <input placeholder="Email Address" 
              value={email}
              onChange={v => props.updateState({ email: v.target.value })}/>
        </Form.Field>
        <Form.Field>
          <label>Employee Id</label>
          <input placeholder="Employee Id"  
              value={employeeId}
              onChange={v => props.updateState({ employeeId: v.target.value })}/>
        </Form.Field>
      </Form>
    </Modal.Content>
    <Modal.Actions>
      <Button
        basic
        color="red"
        onClick={() => {
          props.updateState({ [props.visibilityname]: false });
        }}
      >
        <Icon name="remove" /> No
      </Button>
      <Button
        color="green"
        onClick={() => {
          // props.updateState({ [props.visibilityname]: false });
          props.handleSubmit()
        }}
      >
        <Icon name="checkmark" /> Yes
      </Button>
    </Modal.Actions>
  </Modal>
);}

export const AddDoctorModal = props => {
  const {
    name,
    bmdcNo,
    phone,
    gender,
    availability,
    email,
    branch,
    speciality,
    degrees,
    experiences,
    degreeSingle,
    expSingle,
  } = props.doctor;
  const { branches, specialities, edit, title } = props;
  const branchOptions = branches.map((item, sl_no) => {
    return { key: sl_no, text: item.name, value: item.name };
  });
  const specialityOptions = specialities.map((item, sl_no) => {
    return { key: sl_no, text: item.name, value: item.name };
  });
  // console.log(props);
  return (
    <Modal
      header="Reminder!"
      open={props.visibility}
      actions={['Ok', 'Cancel']}
    >
      <Modal.Header>{title}</Modal.Header>
      <Modal.Content>
        <Form>
          <Form.Field>
            <label>Full Name</label>
            <input
              placeholder="First Name"
              value={name}
              onChange={v => props.updateStateDoctor({ name: v.target.value })}
            />
          </Form.Field>
          <Form.Field>
            <label>BMDC Number</label>
            <input
              placeholder="BMDC Number"
              value={bmdcNo}
              onChange={v =>
                props.updateStateDoctor({ bmdcNo: v.target.value })
              }
            />
          </Form.Field>
          <Form.Field>
            <label>Phone Number</label>
            <input
              placeholder="Phone Number"
              value={phone}
              onChange={v => props.updateStateDoctor({ phone: v.target.value })}
            />
          </Form.Field>
          <Form.Group inline>
            <label>Available</label>
            <Form.Radio
              label="Yes"
              checked={availability == true}
              value={true}
              onChange={(e, v) =>
                props.updateStateDoctor({ availability: v.value })
              }
            />
            <Form.Radio
              label="Not Available"
              value={false}
              checked={availability != true}
              onChange={(e, v) =>
                props.updateStateDoctor({ availability: v.value })
              }
            />
          </Form.Group>
          <Form.Field>
            <Form.Select
              fluid
              label="Gender"
              options={genderOptions}
              placeholder="Select Gender"
              value={gender}
              onChange={(e, v) => props.updateStateDoctor({ gender: v.value })}
            />
          </Form.Field>
          <Form.Field>
            <Form.Select
              fluid
              label="Branch"
              options={branchOptions}
              placeholder="Select Branch"
              value={branch}
              onChange={(e, v) => props.updateStateDoctor({ branch: v.value })}
            />
          </Form.Field>
          <Form.Field>
            <Form.Select
              fluid
              label="Speciality"
              options={specialityOptions}
              placeholder="Select Speciality"
              value={speciality}
              onChange={(e, v) =>
                props.updateStateDoctor({ speciality: v.value })
              }
            />
          </Form.Field>

          {/* Degrees */}
          <Form.Field>
            <label> Degrees </label>
            {  <React.Fragment>
              <Input
              label={{
                basic: true,
                labelPosition: 'right',
                icon: 'tag',
              }}
              icon = <Icon name='plus' inverted circular link onClick={()=>{
                const x = degreeSingle && degreeSingle.trim();
                if(!x){
                  toastr.error("Please enter a valid Degree");
                  return;
                }
                const degreesNew = degrees ? [...degrees, degreeSingle] : [degreeSingle];
                props.updateStateDoctor({degrees: degreesNew, degreeSingle: '' })
              }}
               />
               value={degreeSingle}
              placeholder='Enter New Degree'
              onChange={ (e,v) => {
                // console.log(v)
                props.updateStateDoctor({'degreeSingle':  e.target.value})
              } }
              onKeyDown ={ (e, v) => {
                if (e.key === 'Enter'){
                  const x = degreeSingle && degreeSingle.trim();
                  if(!x){
                    toastr.error("Please enter a valid Degree");
                    return;
                  }
                  const degreesNew = degrees ? [...degrees, x] : [];
                  props.updateStateDoctor({degrees: degreesNew, degreeSingle: '' })
                }
              }}

              />
              { !!degrees && 
                degrees.map((item, sl_no) => 
                <List divided verticalAlign='middle'>
                  <List.Item>
                    <List.Content floated='right' >
                      <Icon name='remove' inverted circular link 
                          onClick={()=>{
                                  degrees.splice(sl_no, 1);
                                  // console.log(degrees);
                                  props.updateStateArray('degrees', degrees)
                                }} />
                    </List.Content>
                    <List.Content floated='left' style={{'margin-left': '13px'}}>
                      <Icon name='tag' />
                    </List.Content>
                    <List.Content>{item}</List.Content>
                </List.Item>
                </List> 
                  )
              }
            </React.Fragment>   }
          </Form.Field>

          {/* Experiences */}
          <Form.Field>
            <label> Experiences </label>
            {  <React.Fragment>
              <Input
              label={{
                basic: true,
                labelPosition: 'right',
                icon: 'tag',
              }}
              icon = <Icon name='plus' inverted circular link onClick={()=>{
                const x = expSingle && expSingle.trim();
                if(!x){
                  toastr.error("Please enter a valid Degree");
                  return;
                }
                const expNew = experiences ? [...experiences, x] : [x];
                props.updateStateDoctor({experiences: expNew, expSingle: '' })
              }}
               />
               value={expSingle}
              placeholder='Enter New Experience'
              onChange={ (e,v) => {
                // console.log(v)
                props.updateStateDoctor({'expSingle':  e.target.value})
              } }
              onKeyDown ={ (e, v) => {
                if (e.key === 'Enter'){
                  const x = expSingle && expSingle.trim();
                  if(!x){
                    toastr.error("Please enter a valid Degree");
                    return;
                  }
                  const expNew = experiences ? [...experiences, x] : [x];
                  props.updateStateDoctor({experiences: expNew, expSingle: '' })
                }
              }}

              />
              { !!experiences && 
                experiences.map((item, sl_no) => 
                <List divided verticalAlign='middle'>
                  <List.Item>
                    <List.Content floated='right' >
                      <Icon name='remove' inverted circular link 
                          onClick={()=>{
                                  experiences.splice(sl_no, 1);
                                  // console.log(experiences);
                                  props.updateStateArray('experiences', experiences)
                                }} />
                    </List.Content>
                    <List.Content floated='left' style={{'margin-left': '13px'}}>
                      <Icon name='tag' />
                    </List.Content>
                    <List.Content>{item}</List.Content>
                </List.Item>
                </List>)
              }
            </React.Fragment>   }
          </Form.Field>

        </Form>
      </Modal.Content>
      <Modal.Actions>
        <Button
          content="Cancel"
          icon="close"
          color="blue"
          labelPosition="left"
          onClick={() => {
            edit
              ? props.updateState({ [props.visibilityname]: false })
              : props.updateVisibilityState({ [props.visibilityname]: false });
          }}
        />
        <Button
          color="green"
          content={edit ? 'Update Doctor' : 'Add Doctor'}
          icon="add"
          labelPosition="left"
          onClick={() => {
            props.handleSubmit();
          }}
        />
      </Modal.Actions>
    </Modal>
  );
};

export const AddBranchModal = props => {
  const { name, address, phone, district, note } = props.branch;
  const districtOptions = districtList.map(item => {
    return { value: item.name.toLowerCase(), key: item.name, text: item.name };
  });

  return (
    <Modal
      header="Reminder!"
      open={props.visibility}
      actions={['Ok', 'Cancel']}
    >
      <Modal.Header>Add Branch</Modal.Header>
      <Modal.Content>
        <Form>
          <Form.Field>
            <label>Branch Name</label>
            <input
              placeholder="Branch Name"
              value={name}
              onChange={v => props.updateStateBranch({ name: v.target.value })}
            />
          </Form.Field>
          <Form.Field>
            <label>Address</label>
            <input
              placeholder="Address"
              value={address}
              onChange={v =>
                props.updateStateBranch({ address: v.target.value })
              }
            />
          </Form.Field>
          <Form.Field>
            <label>Phone Number</label>
            <input
              placeholder="Phone Number"
              value={phone}
              onChange={v => props.updateStateBranch({ phone: v.target.value })}
            />
          </Form.Field>
          <Form.Field>
            {/* <Form.Select */}
            <Dropdown
              fluid
              search
              selection
              minCharacters={0}
              placeholder="District"
              label="District"
              options={districtOptions}
              value={district}
              onChange={(e, v) =>
                props.updateStateBranch({ district: v.value })
              }
            />
          </Form.Field>
          <Form.Field>
            <label>Note</label>
            <input
              placeholder="Note"
              value={note}
              onChange={v => props.updateStateBranch({ note: v.target.value })}
            />
          </Form.Field>
        </Form>
      </Modal.Content>
      <Modal.Actions>
        <Button
          content="Cancel"
          icon="close"
          color="blue"
          labelPosition="left"
          onClick={() => {
            props.updateVisibilityState({ [props.visibilityname]: false });
          }}
        />
        <Button
          color="green"
          content="Add Doctor"
          icon="add"
          labelPosition="left"
          onClick={() => {
            props.handleSubmit();
          }}
        />
      </Modal.Actions>
    </Modal>
  );
};


export const AddSpecialityModal = props => {
  const { name, note } = props.speciality;
  const districtOptions = districtList.map(item => {
    return { value: item.name.toLowerCase(), key: item.name, text: item.name };
  });

  return (
    <Modal
      header="Reminder!"
      open={props.visibility}
      actions={['Ok', 'Cancel']}
    >
      <Modal.Header>Add Speciality</Modal.Header>
      <Modal.Content>
        <Form>
          <Form.Field>
            <label>Speciality Name</label>
            <input
              placeholder="Speciality Name"
              value={name}
              onChange={v =>
                props.updateStateSpeciality({ name: v.target.value })
              }
            />
          </Form.Field>
          <Form.Field>
            <label>Note</label>
            <input
              placeholder="Note"
              value={note}
              onChange={v =>
                props.updateStateSpeciality({ note: v.target.value })
              }
            />
          </Form.Field>
        </Form>
      </Modal.Content>
      <Modal.Actions>
        <Button
          content="Cancel"
          icon="close"
          color="blue"
          labelPosition="left"
          onClick={() => {
            props.updateVisibilityState({ [props.visibilityname]: false });
          }}
        />
        <Button
          color="green"
          content="Add Speciality"
          icon="add"
          labelPosition="left"
          onClick={() => {
            props.handleSubmit();
          }}
        />
      </Modal.Actions>
    </Modal>
  );
};


export const EditProfileModal = props => {
  const { name, phone, gender, email, employeeId, address, nId } = props.profile;

  return (
    <Modal
      header="Reminder!"
      open={props.visibility}
      actions={['Ok', 'Cancel']}
    >
      <Modal.Header>Edit Profile</Modal.Header>
      <Modal.Content>
      <Form>
        <Form.Field>
          <label>Full Name</label>
          <input placeholder="Full Name" 
              value={name}
              onChange={v => props.updateState({ name: v.target.value })} />
        </Form.Field>
        <Form.Field>
          <label>Phone Number(Phone number will be used to login)</label>
          <input placeholder="Phone Number" disabled  
              value={phone}
              onChange={v => props.updateState({ phone: v.target.value })}/>
        </Form.Field>
        <Form.Field>
          <Form.Select
            fluid
            label="Gender"
            value={gender}
            options={genderOptions}
            placeholder="Gender"
            onChange={(e, v) => props.updateState({ gender: v.value })}
          />
        </Form.Field>
        <Form.Field>
          <label>Email Address</label>
          <input placeholder="Email Address" 
              value={email}
              onChange={v => props.updateState({ email: v.target.value })}/>
        </Form.Field>
        <Form.Field>
          <label>National Id</label>
          <input placeholder="National Id"  
              value={nId}
              onChange={v => props.updateState({ nId: v.target.value })}/>
        </Form.Field>
        <Form.Field>
          <label>Employee Id</label>
          <input placeholder="Employee Id"  
              value={employeeId}
              onChange={v => props.updateState({ employeeId: v.target.value })}/>
        </Form.Field>
        <Form.Field>
          <label>Address</label>
          <input placeholder="Address"  
              value={address}
              onChange={v => props.updateState({ address: v.target.value })}/>
        </Form.Field>
      </Form>
      </Modal.Content>
      <Modal.Actions>
        <Button
          content="Cancel"
          icon="close"
          color="blue"
          labelPosition="left"
          onClick={() => {
            props.updateState({ [props.visibilityname]: false });
          }}
        />
        <Button
          color="green"
          content="Update Profile"
          icon="add"
          labelPosition="left"
          onClick={() => {
            props.handleSubmit();
          }}
        />
      </Modal.Actions>
    </Modal>
  );
};


export const UpdatePasswordModal = props => {

  return (
    <Modal
      header="Reminder!"
      open={props.visibility}
      actions={['Ok', 'Cancel']}
    >
      <Modal.Header>Update Password</Modal.Header>
      <Modal.Content>
        <Form>
          <Form.Field>
            <label>Current Password</label>
            <input
              placeholder="Speciality Name"
              type='password'
              onChange={v =>
                props.updateState({ currentPassword: v.target.value })
              }
            />
          </Form.Field>
          <Form.Field>
            <label>New Password</label>
            <input
              placeholder="Speciality Name"
              type='password'
              onChange={v =>
                props.updateState({ newPassword: v.target.value })
              }
            />
          </Form.Field>
          <Form.Field>
            <label>Retype New Password</label>
            <input
              placeholder="Speciality Name"
              type='password'
              onChange={v =>
                props.updateState({ newPassword1: v.target.value })
              }
            />
          </Form.Field>
        </Form>
      </Modal.Content>
      <Modal.Actions>
        <Button
          content="Cancel"
          icon="close"
          color="blue"
          labelPosition="left"
          onClick={() => {
            props.updateState({ [props.visibilityname]: false });
          }}
        />
        <Button
          color="green"
          content="Update Password"
          icon="add"
          labelPosition="left"
          onClick={() => {
            props.handleSubmit();
          }}
        />
      </Modal.Actions>
    </Modal>
  );
};
