import React from 'react';
import { withTracker } from 'meteor/react-meteor-data';
import {
	Icon,
	Menu,
	Table,
	Header,
	Pagination,
	Button,
	ItemMeta
} from 'semantic-ui-react';
import { Fab, Action } from 'react-tiny-fab';
import toastr from 'toastr';
const AWS = require('aws-sdk');
import moment from 'moment';

import {
	mainButtonStyles,
	actionButtonStyles,
	awsConfig
} from '../../../const';
import { AddUserModal } from './modals';
import testHomeCollectionRequests from '../testReports/testHomeCollectionRequests';

import { DetailsModal } from '../utils/modals';

page_size = 10;

class UsersListMain extends React.Component {
	constructor(props) {
		super(props);

		this.state = {
			userModalVisibility: false,

			activePage: 1,
			boundaryRange: 1,
			siblingRange: 3,
			showEllipsis: true,
			showFirstAndLastNav: true,
			showPreviousAndNextNav: true,
			totalPages: 1,

			userdata: {},
			uploading: {}
		};

		// this.fileInputRef = React.createRef();

		this.fetchAppUserCount();
	}

	fetchAppUserCount() {
		const { searchQuery } = this.props;
		Meteor.call(
			'fetchAppUserCount',
			{ searchQuery, type: this.props.activeItem },
			(err, res) => {
				// console.log(err, res);
				// console.log(Math.ceil(res / page_size));
				if (err)
					alert('Failed to fetch medicine count, please try again later');
				else if (res) this.setState({ totalPages: Math.ceil(res / page_size) });
			}
		);
	}

	handleActiveItem(activeItem) {
		this.props.updateState({ activeItem, activePage: 1 }, () =>
			this.fetchAppUserCount()
		);
	}

	updateState(obj) {
		this.setState(obj);
	}

	handlePaginationChange = (e, { activePage }) => {
		this.props.updateState({ activePage });
	};

	addUser() {
		// console.log(this.state);
		const { name, phone, password, email, employeeId, gender } = this.state;
		Meteor.call(
			'create.admin',
			{ name, phone, password, email, employeeId, gender },
			(err, res) => {
				console.log(err, res);
				if (err) {
					alert(err.message);
					toastr.error('Sorry! User creation failed.');
				} else if (res) {
					toastr.success('User has been  created');
					this.setState({
						userModalVisibility: false
					});
				}
			}
		);
	}

	handleReset() {
		this.props.updateState({ searchQuery: undefined }, () =>
			this.fetchAppUserCount()
		);
	}

	uploadFile(patientId, patientName, file) {
		const s3bucket = new AWS.S3(awsConfig);
		let { uploading } = this.state;
		uploading[patientId] = true;
		this.setState({ uploading });

		var params = {
			Bucket: awsConfig.Bucket,
			Key: 'medicalHistory/' + file.name,
			Body: file
		};

		// const res = await s3bucket.upload(params);

		s3bucket.upload(params, (err, res) => {
			//   console.log(err, res);
			if (res) {
				// fileUrl is in: res.Location
				const fileUrl = res.Location;
				const m = new moment();
				Meteor.call(
					'addMedicalHistory',
					{
						patientId,
						patientName,
						fileUrl,
						name: 'History on ' + m.format('DD-MM-YY')
					},
					(e, r) => {
						console.log(e, r);
						if (r) {
							toastr.success('Successfully added Medical History');
							uploading[patientId] = false;
							this.setState({ uploading });
						}
					}
				);
			}
		});
	}

	render() {
		const { activeItem, list, activePage = 1, searchQuery } = this.props;
		const {
			detailsModalVisibility,
			userModalVisibility,
			userdata,
			boundaryRange,
			siblingRange,
			totalPages,
			showEllipsis,
			showFirstAndLastNav,
			showPreviousAndNextNav,
			uploading
		} = this.state;

		if (this.props.activeItem == 'app') {
			let idx = -1;
			list.map((item, sl_no) => {
				if (item._id == this.props.currentUser._id) idx = sl_no;
			});
			if (idx != -1) list.splice(idx, 1);
		}

		return (
			<React.Fragment>
				<AddUserModal
					visibility={userModalVisibility}
					visibilityname='userModalVisibility'
					updateState={this.updateState.bind(this)}
					handleSubmit={this.addUser.bind(this)}
				/>
				<DetailsModal
					visibility={detailsModalVisibility}
					visibilityname='detailsModalVisibility'
					heading='User Details'
					item={userdata}
					updateState={this.updateState.bind(this)}
				/>
				<div className='infoTopBar'>
					<div className='ui transparent left icon input patientSrc left floated'>
						<input
							type='text'
							placeholder='Search...'
							value={searchQuery ? searchQuery : ''}
							onChange={v => {
								const x = v.target.value;
								this.props.updateState({ searchQuery: x }, () => {
									setTimeout(() => {
										this.fetchAppUserCount();
									}, 500);
								});
							}}
						/>
						<i className='search icon' />
					</div>
					<div className='filterContainer'>
						<ul>
							<li style={{ marginLeft: '15px' }}>
								<button
									className='ui teal small button'
									style={{ margin: '0' }}
									onClick={() => this.handleReset()}
								>
									Reset
								</button>
							</li>
						</ul>
					</div>
				</div>
				<Menu tabular>
					<Menu.Item
						name='Admin Users'
						active={activeItem === 'admin'}
						onClick={() => this.handleActiveItem('admin')}
					/>
					<Menu.Item
						name='App Users'
						active={activeItem === 'app'}
						onClick={() => this.handleActiveItem('app')}
					/>
				</Menu>
				<Table celled selectable>
					<Table.Header>
						<Table.Row>
							<Table.HeaderCell>Sl. No.</Table.HeaderCell>
							<Table.HeaderCell>Name</Table.HeaderCell>
							<Table.HeaderCell>Phone</Table.HeaderCell>
							<Table.HeaderCell>Gender</Table.HeaderCell>
							<Table.HeaderCell>Address</Table.HeaderCell>
							<Table.HeaderCell>NId</Table.HeaderCell>
							<Table.HeaderCell>Email</Table.HeaderCell>
							<Table.HeaderCell>Created At</Table.HeaderCell>
							<Table.HeaderCell>Medical History</Table.HeaderCell>
						</Table.Row>
					</Table.Header>

					<Table.Body>
						{list &&
							!!list.length &&
							list.map((item, sl_no) => {
								return (
									<Table.Row key={item._id}>
										<Table.Cell>{sl_no + 1}</Table.Cell>
										<Table.Cell
											onClick={() => {
												const {
													name,
													phone,
													email,
													address,
													gender,
													bloodGroup,
													nId
												} = item.profile;
												this.setState({
													userdata: {
														name,
														phone,
														email,
														address,
														gender,
														bloodGroup,
														nId
													},
													detailsModalVisibility: true
												});
											}}
											style={{ cursor: 'pointer' }}
										>
											{item.profile.name}
										</Table.Cell>
										<Table.Cell>{item.username}</Table.Cell>
										<Table.Cell>{item.profile.gender}</Table.Cell>
										<Table.Cell>{item.profile.address}</Table.Cell>
										<Table.Cell>{item.profile.nId}</Table.Cell>
										<Table.Cell onClick={() => console.log(item)}>
											{item.profile.email}
										</Table.Cell>
										<Table.Cell>
											{item.createdAt && item.createdAt.toLocaleDateString()}
										</Table.Cell>
										<Table.Cell>
											{uploading[item._id] ? (
												<Icon loading name='spinner' />
											) : (
												<input
													type='file'
													id='file'
													onChange={e => {
														const { _id: patientId, profile } = item;
														const { name: patientName } = profile;
														this.uploadFile(
															patientId,
															patientName,
															e.target.files[0]
														);
													}}
												/>
											)}
										</Table.Cell>
									</Table.Row>
								);
							})}
					</Table.Body>

					<Table.Footer>
						<Table.Row>
							<Table.HeaderCell colSpan='9'>
								<Menu floated='right' pagination>
									<Pagination
										floated='right'
										activePage={activePage}
										boundaryRange={boundaryRange}
										onPageChange={this.handlePaginationChange}
										size='small'
										siblingRange={siblingRange}
										totalPages={totalPages}
										// Heads up! All items are powered by shorthands, if you want to hide one of them, just pass `null` as value
										ellipsisItem={showEllipsis ? undefined : null}
										firstItem={showFirstAndLastNav ? undefined : null}
										lastItem={showFirstAndLastNav ? undefined : null}
										prevItem={showPreviousAndNextNav ? undefined : null}
										nextItem={showPreviousAndNextNav ? undefined : null}
									/>
								</Menu>
							</Table.HeaderCell>
						</Table.Row>
					</Table.Footer>
				</Table>
				{this.props.activeItem == 'admin' && (
					<div
						onClick={() =>
							this.setState({
								userModalVisibility: !this.state.userModalVisibility
							})
						}
					>
						<Fab
							mainButtonStyles={mainButtonStyles}
							icon={<Icon name='plus' />}
						/>
					</div>
				)}
			</React.Fragment>
		);
	}
}

export default withTracker(props => {
	const handle = Meteor.subscribe('fetchUsers', {
		type: props.activeItem,
		searchQuery: props.searchQuery,
		activePage: props.activePage
	});

	return {
		activeItem: props.activeItem,
		currentUser: Meteor.user(),
		ready: !handle.ready(),
		list: Meteor.users.find().fetch()
	};
})(UsersListMain);
