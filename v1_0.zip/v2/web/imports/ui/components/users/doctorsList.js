import React from 'react';
import { withTracker } from 'meteor/react-meteor-data';
import { Menu, Icon } from 'semantic-ui-react';
import { Fab, Action } from 'react-tiny-fab';
import toastr from 'toastr';

import { mainButtonStyles, actionButtonStyles } from '../../../const';
import { Doctors } from '../../../api/doctors/doctors';
import { isValid } from '../utils/phoneNumber';

import DoctorsListMain from './doctorsListMain';
import SpecialitiesList from './specialities';
import BranchList from './branches';

import { AddDoctorModal, AddBranchModal, AddSpecialityModal } from './modals';

export default class DoctorsPage extends React.Component {
	handleState(obj) {
		this.setState(obj);
	}
	render() {
		return (
			<DoctorsListHOC
				handleState={this.handleState.bind(this)}
				{...this.state}
			/>
		);
	}
}
class DoctorsList extends React.Component {
	constructor(props) {
		super(props);

		this.state = {
			doctor: {},
			branch: {},
			speciality: {},
			others: {
				activeItem: 'doctors',
				doctorList: [],
				specialitiesList: [],
				branchList: []
			}
		};

		this.fetchBranchNSpecialities();
	}

	fetchBranchNSpecialities() {
		Meteor.call('fetchBranchNSpecialities', (err, res) => {
			if (err) console.log(err);
			if (res) {
				this.setState({
					others: {
						...this.state.others,
						...res
					}
				});
			}
		});
	}

	handleActiveItem(activeItem) {
		this.setState({ others: { ...this.state.others, activeItem } });
	}

	updateVisibilityState(obj) {
		this.setState({
			others: {
				...this.state.others,
				...obj
			}
		});
	}

	updateStateDoctor(obj) {
		this.setState({
			doctor: {
				...this.state.doctor,
				...obj
			}
		});
	}

	updateStateBranch(obj) {
		this.setState({
			branch: {
				...this.state.branch,
				...obj
			}
		});
	}
	updateStateSpeciality(obj) {
		this.setState({
			speciality: {
				...this.state.speciality,
				...obj
			}
		});
	}

	addSpeciality() {
		const { speciality } = this.state;

		Meteor.call('add.speciality', speciality, (error, success) => {
			if (error) {
				console.log('error', error);
			}
			if (success) {
				this.updateVisibilityState({ modalSpeciality: false, speciality: {} });
			}
		});
	}

	addbranch() {
		const { branch } = this.state;

		Meteor.call('add.branch', branch, (error, success) => {
			if (error) {
				console.log('error', error);
			}
			if (success) {
				this.updateVisibilityState({ modalBranch: false, branch: {} });
			}
		});
	}

	addDoctor() {
		const { doctor: doctorItem } = this.state;
		console.log(this.state);

		delete doctorItem.degreeSingle;
		delete doctorItem.expSingle;
		const bmdcNoInt = parseInt(doctorItem.bmdcNo);

		if (isNaN(bmdcNoInt) || bmdcNoInt <= 0 || bmdcNoInt > 120000) {
			toastr.error('Please enter a valid BMDC Number.');
			return;
		}

		if (!isValid(doctorItem.phone)) {
			toastr.error('Please enter a valid Phone Number.');
			return;
		}

		if (!doctorItem.name) {
			toastr.error('Please enter Name of the doctor');
			return;
		}

		if (!doctorItem.branch) {
			toastr.error('Please select a Branch');
			return;
		}

		if (!doctorItem.speciality) {
			toastr.error('Please select Speciality');
			return;
		}

		if (!doctorItem.experiences || !doctorItem.experiences.length) {
			toastr.error('Please provide Experiences of the doctor');
			return;
		}

		if (!doctorItem.degrees || !doctorItem.degrees.length) {
			toastr.error('Please provide Degrees of the doctor');
			return;
		}

		Meteor.call('add.doctor', doctorItem, (error, success) => {
			if (error) {
				console.log('error', error);
			}
			if (success) {
				this.setState({ doctor: {} });
				this.updateVisibilityState({ modalDoctor: false });
			}
		});
	}

	render() {
		const {
			activeItem,
			modalDoctor,
			modalBranch,
			modalSpeciality,
			branchList,
			specialitiesList
		} = this.state.others;

		const { doctorList } = this.props;
		const { doctor, branch, speciality } = this.state;

		// console.log(this.props.doctorList);

		return (
			<React.Fragment>
				<Menu tabular>
					<Menu.Item
						name='Doctors'
						active={activeItem === 'doctors'}
						onClick={() => this.handleActiveItem('doctors')}
					/>
					<Menu.Item
						name='Branches'
						active={activeItem === 'branches'}
						onClick={() => this.handleActiveItem('branches')}
					/>
					<Menu.Item
						name='Specialities'
						active={activeItem === 'specialities'}
						onClick={() => this.handleActiveItem('specialities')}
					/>
				</Menu>

				{modalDoctor && (
					<AddDoctorModal
						title='Add Doctor'
						visibility={modalDoctor}
						visibilityname='modalDoctor'
						updateVisibilityState={this.updateVisibilityState.bind(this)}
						updateStateDoctor={this.updateStateDoctor.bind(this)}
						handleSubmit={this.addDoctor.bind(this)}
						doctor={doctor}
						branches={branchList}
						specialities={specialitiesList}
					/>
				)}

				{modalBranch && (
					<AddBranchModal
						visibility={modalBranch}
						visibilityname='modalBranch'
						updateVisibilityState={this.updateVisibilityState.bind(this)}
						updateStateBranch={this.updateStateBranch.bind(this)}
						handleSubmit={this.addbranch.bind(this)}
						branch={branch}
					/>
				)}

				{modalSpeciality && (
					<AddSpecialityModal
						visibility={modalSpeciality}
						visibilityname='modalSpeciality'
						updateVisibilityState={this.updateVisibilityState.bind(this)}
						updateStateSpeciality={this.updateStateSpeciality.bind(this)}
						handleSubmit={this.addSpeciality.bind(this)}
						speciality={speciality}
					/>
				)}

				{activeItem == 'doctors' && (
					<DoctorsListMain
						{...this.props}
						doctor={doctorList}
						branches={branchList}
						specialities={specialitiesList}
						handleStateParent={this.props.handleState}
					/>
				)}
				{activeItem == 'specialities' && <SpecialitiesList />}
				{activeItem == 'branches' && <BranchList />}

				<Fab
					mainButtonStyles={mainButtonStyles}
					actionButtonStyles={actionButtonStyles}
					icon={<Icon name='setting' />}
					//   event={event}
				>
					<Action
						style={actionButtonStyles[0]}
						text='Add Branch'
						onClick={() => {
							this.setState({
								others: {
									...this.state.others,
									modalBranch: true
								}
							});
						}}
					>
						<Icon inverted={true} name='code branch' />
					</Action>
					<Action
						style={actionButtonStyles[1]}
						text='Add Speciality'
						onClick={() => {
							this.setState({
								others: {
									...this.state.others,
									modalSpeciality: true
								}
							});
						}}
					>
						<Icon inverted={true} name='tags' />
					</Action>
					<Action
						style={actionButtonStyles[2]}
						text='Add Doctor'
						onClick={() => {
							this.setState({
								others: {
									...this.state.others,
									modalDoctor: true
								}
							});
						}}
					>
						<Icon inverted={true} name='doctor' />
					</Action>
				</Fab>
			</React.Fragment>
		);
	}
}

DoctorsListHOC = withTracker(props => {
	const { speciality, branch, gender } = props;
	const handle = Meteor.subscribe('fetch.doctors', {
		speciality,
		branch,
		gender
	});

	return {
		...props,
		currentUser: Meteor.user(),
		ready: !handle.ready(),
		doctorList: Doctors.find({}, { sort: { createdAt: -1 } }).fetch()
	};
})(DoctorsList);
