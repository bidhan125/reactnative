import React from 'react';
import { withTracker } from 'meteor/react-meteor-data';
import { Icon, Menu, Table, Header } from 'semantic-ui-react';
import { Fab, Action } from 'react-tiny-fab';
import { mainButtonStyles, actionButtonStyles } from '../../../const';
import { Specialities } from '../../../api/doctors/specialities';

class SpecialitiesList extends React.Component {
  render() {
    console.log(this.props);
    const { list } = this.props;

    return (
      <Table celled selectable>
        <Table.Header>
          <Table.Row>
            <Table.HeaderCell>Sl. No.</Table.HeaderCell>
            <Table.HeaderCell>Name</Table.HeaderCell>
            <Table.HeaderCell>Creation Date</Table.HeaderCell>
            <Table.HeaderCell>Note</Table.HeaderCell>
          </Table.Row>
        </Table.Header>

        <Table.Body>
          {list &&
            !!list.length &&
            list.map((item, sl_no) => {
              return (
                <Table.Row key={sl_no}>
                  <Table.Cell>{sl_no + 1}</Table.Cell>
                  <Table.Cell>{item.name}</Table.Cell>
                  <Table.Cell>
                    {item.createdAt && item.createdAt.toLocaleDateString()}
                  </Table.Cell>
                  <Table.Cell>{item.note}</Table.Cell>
                </Table.Row>
              );
            })}
        </Table.Body>
      </Table>
    );
  }
}

export default withTracker(props => {
  // console.log(props);
  const handle = Meteor.subscribe('fetch.specialities');

  return {
    ready: !handle.ready(),
    list: Specialities.find().fetch(),
  };
})(SpecialitiesList);
