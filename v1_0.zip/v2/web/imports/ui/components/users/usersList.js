import React from 'react';
import UsersListMain from './usersListMain';

export default class UsersList extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      activeItem: 'admin',
      searchQuery: undefined,
      activePage: 1,
    };
  }

  updateState(obj, callback) {
    this.setState(obj, callback);
  }

  render() {
    const { activeItem, searchQuery, activePage } = this.state;
    return (
      <UsersListMain
        updateState={this.updateState.bind(this)}
        activeItem={activeItem}
        searchQuery={searchQuery}
        activePage={activePage}
      />
    );
  }
}
