import React from 'react';
import { Segment, Table, Image, Button, Divider } from 'semantic-ui-react';
import { EditProfileModal, UpdatePasswordModal } from './modals';
import { Meteor } from 'meteor/meteor';
import toastr from 'toastr';
import { Accounts } from 'meteor/accounts-base';

export default class Prodile extends React.Component {
	constructor(props) {
		super(props);

		this.state = {
			user: undefined
		};
	}

	componentDidMount() {
		Tracker.autorun(() => {
			const user = Meteor.user();
			if (user) {
				const {
					name,
					phone,
					gender,
					email,
					employeeId,
					address,
					nId
				} = user.profile;
				this.setState({
					user,
					name,
					phone,
					gender,
					email,
					employeeId,
					address,
					nId
				});
			}
		});
	}

	updateState(obj) {
		this.setState(obj);
	}

	updateProfile() {
		const { name, phone, gender, email, employeeId, address, nId } = this.state;
		console.log(name, phone, gender, email, employeeId, address, nId);
		const id = this.state.user._id;
		Meteor.call(
			'updateProfile',
			{ id, name, phone, gender, email, employeeId, address, nId },
			(e, r) => {
				console.log(e, r);
				if (e)
					toastr.error(
						'Sorry! Failed to update profile. Please try again later;'
					);
				else if (r) {
					toastr.success('Successfully updated profile.');
					this.setState({ visibilityEditProfile: false });
				}
			}
		);
	}

	updatePassword() {
		const { currentPassword, newPassword, newPassword1 } = this.state;
		if (newPassword != newPassword1) {
			toastr.error('Sorry! New passwords do not match');
			return;
		}

		Accounts.changePassword(currentPassword, newPassword, (e, r) => {
			console.log(e, r);
			if (e) toastr.error(e.reason);
			else {
				toastr.success('Successfully updated your password!');
				this.setState({ visibilityUpdatePassword: false });
			}
		});
	}

	render() {
		console.log(this.state.user);
		const {
			user,
			visibilityEditProfile,
			visibilityUpdatePassword
		} = this.state;
		const { name, phone, gender, email, employeeId, address, nId } = this.state;
		const newProfile = { name, phone, gender, email, employeeId, address, nId };
		return (
			<div>
				{visibilityEditProfile && (
					<EditProfileModal
						profile={newProfile}
						visibility={visibilityEditProfile}
						visibilityname={'visibilityEditProfile'}
						updateState={this.updateState.bind(this)}
						handleSubmit={this.updateProfile.bind(this)}
					/>
				)}
				{visibilityUpdatePassword && (
					<UpdatePasswordModal
						visibility={visibilityUpdatePassword}
						visibilityname={'visibilityUpdatePassword'}
						updateState={this.updateState.bind(this)}
						handleSubmit={this.updatePassword.bind(this)}
					/>
				)}
				<Segment>
					<Table basic='very' collapsing style={{ margin: '0 auto' }}>
						<Table.Body>
							<Table.Row>
								<Table.Cell columns={5}>
									<b>Name:</b>{' '}
								</Table.Cell>
								<Table.Cell columns={5}>
									{' '}
									{user ? user.profile.name : 'N/A'}
								</Table.Cell>
							</Table.Row>
							<Table.Row>
								<Table.Cell>
									<b>Gender:</b>{' '}
								</Table.Cell>
								<Table.Cell>{user ? user.profile.gender : 'N/A'}</Table.Cell>
							</Table.Row>
							<Table.Row>
								<Table.Cell>
									<b>Address:</b>{' '}
								</Table.Cell>
								<Table.Cell>{user ? user.profile.address : 'N/A'}</Table.Cell>
							</Table.Row>

							<Table.Row>
								<Table.Cell>
									<b>Contact Number:</b>{' '}
								</Table.Cell>
								<Table.Cell>{user ? user.username : 'N/A'}</Table.Cell>
							</Table.Row>

							<Table.Row>
								<Table.Cell>
									<b>Email:</b>{' '}
								</Table.Cell>
								<Table.Cell>{user ? user.profile.email : 'N/A'}</Table.Cell>
							</Table.Row>
							<Table.Row>
								<Table.Cell>
									<b>NId:</b>{' '}
								</Table.Cell>
								<Table.Cell> {user ? user.profile.nId : 'N/A'}</Table.Cell>
							</Table.Row>
							<Table.Row>
								<Table.Cell>
									<b>Employee Id:</b>{' '}
								</Table.Cell>
								<Table.Cell>
									{' '}
									{user ? user.profile.employeeId : 'N/A'}
								</Table.Cell>
							</Table.Row>
						</Table.Body>
					</Table>
				</Segment>
				{/* <Divider section /> */}
				<div style={{ textAlign: 'center' }}>
					<Button
						content='Edit Profile'
						basic
						color='blue'
						icon='pencil'
						labelPosition='right'
						onClick={() => this.setState({ visibilityEditProfile: true })}
					/>
					<Button
						content='Change Password'
						basic
						color='red'
						icon='privacy'
						labelPosition='right'
						onClick={() => this.setState({ visibilityUpdatePassword: true })}
					/>
				</div>
			</div>
		);
	}
}
