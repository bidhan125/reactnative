import React from 'react';
import { Icon, Menu, Loader, Table, Header } from 'semantic-ui-react';
import { Meteor } from 'meteor/meteor';
import { withTracker } from 'meteor/react-meteor-data';

import { Orders } from '../../../api/orders/orders';

import TabItem from './tabItem';
import { order_types, order_table_cells } from '../../../const';

page_size = 10;

class OrderTabs extends React.Component {
	constructor(props) {
		super(props);

		this.state = {
			activePage: 1,
			boundaryRange: 1,
			siblingRange: 3,
			showEllipsis: true,
			showFirstAndLastNav: true,
			showPreviousAndNextNav: true,
			totalPages: 1
		};

		this.fetchOrderCount();
	}

	updateState(obj) {
		this.state(obj);
	}

	fetchOrderCount() {
		// console.log('key');
		Meteor.call('fetchOrderCount', this.props.activeItem, (err, res) => {
			console.log(err, res);
			if (res) this.setState({ totalPages: Math.ceil(res / page_size) });
		});
	}

	render() {
		const { activeItem, list, isReady, activePage } = this.props;
		const {
			boundaryRange,
			siblingRange,
			totalPages,
			showEllipsis,
			showFirstAndLastNav,
			showPreviousAndNextNav
		} = this.state;
		const pagination = {
			activePage,
			boundaryRange,
			siblingRange,
			totalPages,
			showEllipsis,
			showFirstAndLastNav,
			showPreviousAndNextNav
		};

		const menuItemss = [];
		for (let key in order_types) {
			menuItemss.push(
				<Menu.Item
					name={order_types[key]}
					active={activeItem == key}
					onClick={() => {
						this.props.updateState({ activeItem: key, activePage: 1 }, () => {
							this.fetchOrderCount();
						});
					}}
				/>
			);
		}
		return (
			<div className='page'>
				<Menu tabular>{menuItemss}</Menu>
				{!isReady && <Loader active inline='centered' />}
				{isReady && (
					<TabItem
						type={activeItem}
						list={list}
						header={order_table_cells[activeItem]}
						pagination={pagination}
						updateStateGrandParent={this.props.updateState}
					/>
				)}
			</div>
		);
	}
}

export default withTracker(props => {
	// console.log(props);
	const handle = Meteor.subscribe(
		'fetch.orders',
		props.activeItem,
		props.activePage
	);

	return {
		...props,
		isReady: handle.ready(),
		list: Orders.find().fetch()
	};
})(OrderTabs);
