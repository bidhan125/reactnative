import React from 'react';

import OrderTabs from './ordersNavTab';

export default class Orders extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      activeItem: 'single_test',
      activePage: 1,
    };
  }

  updateState(obj, fun) {
    this.setState(obj, () => fun && fun());
  }

  render() {
    const { activeItem, activePage } = this.state;
    return (
      <OrderTabs
        activeItem={activeItem}
        activePage={activePage}
        updateState={this.updateState.bind(this)}
      />
    );
  }
}
