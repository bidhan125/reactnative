import React from 'react';
import { withTracker } from 'meteor/react-meteor-data';
import {
	Dropdown,
	Icon,
	Label,
	Menu,
	Table,
	Header,
	Pagination,
	Button
} from 'semantic-ui-react';
import moment from 'moment';

import { order_status } from '../../../const';

import { DetailsModal } from '../utils/modals';
import ReportUploadModal from './uploadFileModal';

export default class TabItem extends React.Component {
	constructor(props) {
		super(props);

		this.state = {
			visibilityDetailsModal: false,
			visibilityUploadModal: false,
			item: {}
		};
	}

	componentDidCatch(error, info) {
		// Display fallback UI
		this.setState({ hasError: true });
		// You can also log the error to an error reporting service
		// logErrorToMyService(error, info);
		// console.log(error, info);
	}

	updateState(obj) {
		this.setState(obj);
	}

	handlePaginationChange = (e, { activePage }) => {
		this.props.updateStateGrandParent({ activePage });
	};

	updateStatus(id, v) {
		Meteor.call('updateOrderStatus', id, v, (err, res) => {
			console.log(err, res);
		});
	}

	handleType(type, item) {
		// console.log(item);
		switch (type) {
			case 'single_test':

			case 'package_test': {
				const { patient, tests } = item;
				if (!tests) return {};
				let testArr = [];
				tests.map((i, idx) => {
					const { name, price } = i;
					const whom = i.for;
					testArr.push({
						'Test Name': name,
						price,
						'Client Name': whom.name,
						'Blood Group': whom.bloodGroup,
						gender: whom.gender,
						height: whom.height,
						weight: whom.weight
					});
				});
				return {
					'Patient Name': patient.name,
					phone: patient.phone,
					age: patient.age,
					tests: testArr
				};
			}

			case 'medicine': {
				try {
					const { instruction, paymentMethod, cart } = item;
					let cartArr = [];
					for (let key in cart) {
						const itm = cart[key];
						// console.log(itm);
						const { name, price, quantity, type } = itm;
						cartArr.push({
							name,
							price,
							quantity,
							type
						});
					}
					return {
						instruction,
						paymentMethod,
						'Cart Items': cartArr
					};
				} catch (error) {
					return {};
					// throw new Error('It crashed!');
				}
			}

			case 'home_care': {
				return { 'Patient Condition': item.patientCondition };
			}

			case 'report_delivery': {
				const { reportId, invoiceId, gender } = item;
				return { reportId, invoiceId, gender };
			}

			default:
				return {};
		}
	}

	handleClick(item) {
		console.log(item);
		const obj = {
			...item
		};
		this.setState({ item: obj }, () =>
			this.setState({ visibilityDetailsModal: true })
		);
	}

	renderStatus(status, id) {
		// console.log(id);
		const trigger = (
			<span>
				<Label empty circular color={order_status[status]} key={status} />{' '}
				{status}
			</span>
		);
		const options = [];
		for (let k in order_status)
			options.push({
				key: id + order_status[k],
				value: k,
				text: k,
				label: { color: order_status[k], empty: true, circular: true }
			});
		return (
			<Dropdown
				trigger={trigger}
				options={options}
				// value={value}
				onChange={(e, v) => {
					// console.log(v);
					this.updateStatus(id, v.value);
				}}
			/>
		);
	}

	renderField(key, val, id) {
		if (key == 'createdAt') {
			const m = new moment(val);
			return m.format('DD/MM/YY - hh:mmA');
		} else if (key == 'tests') return val && val.length;
		else if (key == 'patient') return val && val.name;
		else if (key == 'isBeneficiary') return val ? 'Yes' : 'No';
		else if (key == 'status') return this.renderStatus(val, id);
		return val;
	}

	render() {
		let { list, header, type } = this.props;
		const {
			item,
			visibilityDetailsModal,
			orderId,
			visibilityUploadModal
		} = this.state;
		const showUpload = type == 'single_test' || type == 'package_test';
		const {
			activePage,
			boundaryRange,
			siblingRange,
			totalPages,
			showEllipsis,
			showFirstAndLastNav,
			showPreviousAndNextNav
		} = this.props.pagination;

		return (
			<Table celled selectable>
				{visibilityDetailsModal && (
					<DetailsModal
						heading='Order Details'
						item={item}
						type={type}
						visibility={visibilityDetailsModal}
						visibilityname='visibilityDetailsModal'
						updateState={this.updateState.bind(this)}
					/>
				)}
				{visibilityUploadModal && (
					<ReportUploadModal
						heading='Upload report'
						item={item}
						orderId={orderId}
						visibility={visibilityUploadModal}
						visibilityname='visibilityUploadModal'
						updateState={this.updateState.bind(this)}
					/>
				)}
				<Table.Header>
					<Table.Row>
						<Table.HeaderCell key={'sl_no'}> Sl. No. </Table.HeaderCell>
						{header.map((item, idx) => (
							<Table.HeaderCell key={idx}>{item}</Table.HeaderCell>
						))}
						{showUpload && (
							<Table.HeaderCell key={'upload'}>
								{' '}
								Upload Report{' '}
							</Table.HeaderCell>
						)}
					</Table.Row>
				</Table.Header>

				{this.state.hasError && ''}

				{!this.state.hasError && (
					<Table.Body>
						{list &&
							list.length &&
							list.map((item, sl_no) => {
								const obj = { ...this.handleType(type, item) };
								header.map((key, idx) => {
									if (!obj.hasOwnProperty(key)) obj[key] = item[key];
								});
								return (
									<Table.Row key={sl_no}>
										<Table.Cell key={'rteett'}>{sl_no + 1}</Table.Cell>
										{header.map((key, idx) => (
											<Table.Cell
												key={idx}
												style={{ cursor: 'pointer' }}
												onClick={() =>
													this.handleClick({
														...obj,
														id: item._id,
														prescriptions: item.prescriptions
													})
												}
											>
												{this.renderField(key, obj[key], item._id)}
											</Table.Cell>
										))}
										{showUpload && (
											<Table.Cell>
												<Button
													basic
													color='blue'
													content='Reports'
													onClick={() => {
														this.setState(
															{
																item,
																orderId: item._id
															},
															() =>
																this.setState({ visibilityUploadModal: true })
														);
													}}
												/>
											</Table.Cell>
										)}
									</Table.Row>
								);
							})}
					</Table.Body>
				)}

				<Table.Footer>
					<Table.Row>
						<Table.HeaderCell colSpan='10'>
							<Menu floated='right' pagination>
								<Pagination
									floated='right'
									activePage={activePage}
									boundaryRange={boundaryRange}
									onPageChange={this.handlePaginationChange}
									size='small'
									siblingRange={siblingRange}
									totalPages={totalPages}
									// Heads up! All items are powered by shorthands, if you want to hide one of them, just pass `null` as value
									ellipsisItem={showEllipsis ? undefined : null}
									firstItem={showFirstAndLastNav ? undefined : null}
									lastItem={showFirstAndLastNav ? undefined : null}
									prevItem={showPreviousAndNextNav ? undefined : null}
									nextItem={showPreviousAndNextNav ? undefined : null}
								/>
							</Menu>
						</Table.HeaderCell>
					</Table.Row>
				</Table.Footer>
			</Table>
		);
	}
}
