import React from 'react';
import {
	Modal,
	Grid,
	Button,
	Icon,
	Card,
	ItemMeta,
	Divider
} from 'semantic-ui-react';
import { Meteor } from 'meteor/meteor';
import toastr from 'toastr';
const AWS = require('aws-sdk');
import moment from 'moment';

import { awsConfig } from '../../../const';

const { Row, Column } = Grid;

export default class ReportUploadModal extends React.Component {
	constructor(props) {
		super(props);

		this.state = {
			dataFetching: true,
			list: []
		};

		this.fetchData();
	}

	fetchData() {
		Meteor.call('fetchReportbyOrderId', this.props.orderId, (e, r) => {
			console.log(e, r);
			if (r)
				this.setState({
					dataFetching: false,
					list: r
				});
		});
	}

	uploadFile({ patientId, orderId, file }) {
		console.log(patientId, file);
		// return;
		const s3bucket = new AWS.S3(awsConfig);
		this.setState({ uploading: true });

		var params = {
			Bucket: awsConfig.Bucket,
			Key: 'medicalReports/' + file.name,
			Body: file
		};

		// const res = await s3bucket.upload(params);

		s3bucket.upload(params, (err, res) => {
			//   console.log(err, res);
			if (res) {
				// fileUrl is in: res.Location
				const fileUrl = res.Location;
				const m = new moment();
				Meteor.call(
					'addReport',
					{
						orderId,
						patientId,
						url: fileUrl,
						name: 'Report on ' + m.format('DD-MM-YY')
					},
					(e, r) => {
						console.log(e, r);
						if (r) {
							toastr.success('Successfully added Medical Report');
							this.setState({ uploading: false });
							this.fetchData();
						}
					}
				);
			}
		});
	}

	render() {
		const { list, dataFetching, uploading } = this.state;
		const { orderId, item } = this.props;
		console.log(orderId, item);

		return (
			<Modal
				header='Reminder!'
				open={this.props.visibility}
				actions={['Ok', 'Cancel']}
				size='small'
			>
				<Modal.Header>{this.props.heading}</Modal.Header>
				<Modal.Content>
					<Grid width={16} textAlign='left'>
						<Column width={4}>Uploaded Reports:</Column>
						<Column width={12}>
							{dataFetching && <Icon name='loading' />}
							{!dataFetching && (
								<Card.Group itemsPerRow={3}>
									{list.map(item => (
										<Card raised color='red' image={item.url} />
									))}
								</Card.Group>
							)}
							<Divider section />
						</Column>
						<Column width={4}> Upload New Report:</Column>
						{!uploading ? (
							<input
								type='file'
								id='file'
								onChange={e => {
									this.uploadFile({
										orderId,
										patientId: item.createdBy,
										file: e.target.files[0]
									});
								}}
							/>
						) : (
							<Icon loading name='spinner' />
						)}
					</Grid>
				</Modal.Content>
				<Modal.Actions>
					<Button
						basic
						color='red'
						onClick={() => {
							this.props.updateState({ [this.props.visibilityname]: false });
						}}
					>
						<Icon name='remove' /> Close
					</Button>
				</Modal.Actions>
			</Modal>
		);
	}
}
