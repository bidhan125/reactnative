import React from 'react';
import { Button, Modal, Icon, Form, TextArea } from 'semantic-ui-react';

import EditorComponent from '../editor/editor';
import { medicine_types } from '../../../const';

export const AddMedicineModal = props => {
  const typeOptions = medicine_types.map((item, sl_no) => {
    return { key: sl_no, text: item.name, value: item.name };
  });

  return (
    <Modal
      header="Reminder!"
      open={props.visibility}
      actions={['Ok', 'Cancel']}
    >
      <Modal.Header>Medicine Details</Modal.Header>
      <Modal.Content>
        <Form>
          <Form.Field>
            <label>Medicine Name</label>
            <input
              placeholder="Medicine Name"
              onChange={v => props.updateState({ name: v.target.value })}
            />
          </Form.Field>
          <Form.Field>
            <label>Generic Name</label>
            <input
              placeholder="Medicine Name"
              onChange={v => props.updateState({ generic_name: v.target.value })}
            />
          </Form.Field>
          <Form.Field>
            <Form.Select
              fluid
              search
              label="Select Type"
              options={typeOptions}
              onChange={(event, data) => {
                props.updateState({ type: data.value });
              }}
              placeholder="Type"
            />
          </Form.Field>

          <Form.Field>
            <label>Description of Medicine </label>
            <div className="draft-design">
              <EditorComponent updateState={props.updateState} />
            </div>
          </Form.Field>
          <Form.Field>
            <label>Strength</label>
            <input
              placeholder="Strength"
              onChange={v => props.updateState({ strength: v.target.value })}
            />
          </Form.Field>
          <Form.Field>
            <label>Pharmaceuticals</label>
            <input
              placeholder="Pharmaceuticals"
              onChange={v => props.updateState({ pharma: v.target.value })}
            />
          </Form.Field>
          <Form.Field>
            <label>Unit</label>
            <input
              placeholder="Unit"
              onChange={v => props.updateState({ unit: v.target.value })}
            />
          </Form.Field>
          <Form.Field>
            <label>Available Quantity</label>
            <input
              placeholder="Available Quantity"
              onChange={v =>
                props.updateState({ available_quantity: v.target.value })
              }
            />
          </Form.Field>
          <Form.Field>
            <label>Price</label>
            <input
              placeholder="Price"
              onChange={v => props.updateState({ price: v.target.value })}
            />
          </Form.Field>
        </Form>
      </Modal.Content>
      <Modal.Actions>
        <Button
          basic
          color="red"
          onClick={() => {
            props.updateState({ [props.visibilityname]: false });
          }}
        >
          <Icon name="remove" /> Cancel
        </Button>
        <Button
          color="green"
          onClick={() => {
            props.handleSubmit();
          }}
        >
          <Icon name="checkmark" /> Add Medicine
        </Button>
      </Modal.Actions>
    </Modal>
  );
};
