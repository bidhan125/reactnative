import React from 'react';
import {
  Modal,
  Checkbox,
  Header,
  Image,
  Icon,
  Segment,
  Card,
  Button,
  Select,
  Table,
  Menu,
  Pagination,
} from 'semantic-ui-react';

import { Fab, Action } from 'react-tiny-fab';

import { AddMedicineModal } from './modals';

import { mainButtonStyles, actionButtonStyles } from '../../../const';
import { medicine_types_new } from '../../../const';

page_size = 10;

export default class MedicineList extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      list: [],
      activePage: 1,
      boundaryRange: 1,
      siblingRange: 3,
      showEllipsis: true,
      showFirstAndLastNav: true,
      showPreviousAndNextNav: true,
      totalPages: 1,
    };

    this.fetchData();
    this.fetchTotalMedicineCount();
  }

  fetchTotalMedicineCount() {
    const { form, searchQuery } = this.state;
    Meteor.call(
      'fetchTotalMedicineCount',
      { searchQuery, form, src: 'web' },
      (err, res) => {
        if (err)
          alert('Failed to fetch medicine count, please try again later');
        else if (res) this.setState({ totalPages: Math.ceil(res / page_size) });
      },
    );
  }

  fetchData(recount) {
    const { activePage, form, searchQuery } = this.state;
    if (recount) this.fetchTotalMedicineCount();

    Meteor.call(
      'fetchMedicines',
      { searchQuery, form, page_no: activePage, src: 'web' },
      (err, res) => {
        // console.log(err, res);
        if (err) {
          console.log('Failed to fetch medicine list');
        } else if (res) {
          this.setState({ list: res });
        }
      },
    );
  }

  toggleStorePresence(id, val, sl_no) {
    Meteor.call('toggleStorePresence', id, val, (err, res) => {
      console.log(err, res);
      if (err)
        alert(
          'Sorry! Failed ttot update store presence. Please try again later..',
        );
      else if (res) {
        const { list } = this.state;
        list[sl_no].storePresence = val;
        this.setState({ list });
      }
    });
  }

  updateState(obj) {
    this.setState(obj);
  }

  handlePaginationChange = (e, { activePage }) => {
    this.setState({ activePage }, () => this.fetchData());
  };

  handleSubmit() {
    // console.log(this.state);
    const {
      brand_name,
      generic_name,
      form,
      strength,
      pharma,
      packsize,
      price,
      available_quantity,
    } = this.state;

    const data = {
      brand_name,
      generic_name,
      form,
      strength,
      pharma,
      packsize,
      price,
      available_quantity,
    };

    Meteor.call('addMedicine', data, (err, res) => {
      if (err) {
        alert(
          'Sorry! Failed to add medicine at this moment. Please try again after sometime',
        );
        this.setState({ medicineModalVisibility: false });
      } else if (res) {
        const {
          brand_name,
          generic_name,
          form,
          strength,
          pharma,
          packsize,
          price,
          available_quantity,
        } = {};
        const data = {
          brand_name,
          generic_name,
          form,
          strength,
          pharma,
          packsize,
          price,
          available_quantity,
        };
        this.setState({ ...data, medicineModalVisibility: false });
        this.fetchData(true);
      }
    });
  }

  render() {
    const {
      list,
      activePage,
      boundaryRange,
      siblingRange,
      totalPages,
      showEllipsis,
      showFirstAndLastNav,
      showPreviousAndNextNav,
    } = this.state;
    // console.log(list);

    const formOptions = [{ text: 'Select Form', value: undefined, key: -1 }];
    medicine_types_new.map((i, idx) => {
      formOptions.push({ text: i.name, value: i.name, key: idx });
    });

    return (
      <Segment basic>
        <AddMedicineModal
          visibility={this.state.medicineModalVisibility}
          visibilityname="medicineModalVisibility"
          updateState={this.updateState.bind(this)}
          handleSubmit={this.handleSubmit.bind(this)}
        />
        <Header as="h3">Medicine List</Header>
        <div className="infoTopBar">
          <div
            className="ui transparent left icon input patientSrc left floated"
            onChange={v => {
              const x = v.target.value;

              this.setState({ searchQuery: x }, () => {
                if (x.length > 2) this.fetchData(true);
              });
            }}
          >
            <input
              type="text"
              placeholder="Search Medicine..."
              value={this.state.searchQuery}
            />
            <i className="search icon" />
          </div>

          <div className="filterContainer">
            <ul>
              <li>
                <Select
                  options={formOptions}
                  // value={this.state.form}
                  placeholder="Select Form"
                  onChange={(e, data) =>
                    this.setState({ form: data.value }, () =>
                      this.fetchData(true),
                    )
                  }
                />
              </li>
              <li style={{ marginLeft: '15px' }}>
                <button
                  className="ui teal small button"
                  style={{ margin: '0' }}
                  onClick={() =>
                    this.setState({ searchQuery: '', form: undefined }, () =>
                      this.fetchData(true),
                    )
                  }
                >
                  Clear Filter
                </button>
                {/* <button className="ui small basic red button">Delete</button> */}
              </li>
            </ul>
          </div>
        </div>

        <Table celled selectable>
          <Table.Header>
            <Table.Row>
              <Table.HeaderCell>Sl. No.</Table.HeaderCell>
              <Table.HeaderCell>Name</Table.HeaderCell>
              <Table.HeaderCell>Generic Name</Table.HeaderCell>
              <Table.HeaderCell>Form</Table.HeaderCell>
              <Table.HeaderCell>Strength</Table.HeaderCell>
              <Table.HeaderCell>Pharmaceuticals</Table.HeaderCell>
              <Table.HeaderCell>Packsize</Table.HeaderCell>
              <Table.HeaderCell>Price</Table.HeaderCell>
              <Table.HeaderCell>Store Presence</Table.HeaderCell>
            </Table.Row>
          </Table.Header>

          <Table.Body>
            {list &&
              !!list.length &&
              list.map((item, sl_no) => {
                return (
                  <Table.Row>
                    <Table.Cell>{sl_no + 1}</Table.Cell>
                    <Table.Cell>{item.brand_name}</Table.Cell>
                    <Table.Cell>{item.generic_name}</Table.Cell>
                    <Table.Cell>{item.form}</Table.Cell>
                    <Table.Cell>{item.strength}</Table.Cell>
                    <Table.Cell>{item.pharma}</Table.Cell>
                    <Table.Cell>{item.packsize}</Table.Cell>
                    <Table.Cell>{item.price}</Table.Cell>
                    <Table.Cell textAlign="center">
                      <Checkbox
                        key={item._id}
                        toggle
                        checked={item.storePresence}
                        onChange={(e, d) =>
                          this.toggleStorePresence(item._id, d.checked, sl_no)
                        }
                      />
                    </Table.Cell>
                  </Table.Row>
                );
              })}
          </Table.Body>

          <Table.Footer>
            <Table.Row>
              <Table.HeaderCell colSpan="9">
                <Menu floated="right" pagination>
                  <Pagination
                    floated="right"
                    activePage={activePage}
                    boundaryRange={boundaryRange}
                    onPageChange={this.handlePaginationChange}
                    size="small"
                    siblingRange={siblingRange}
                    totalPages={totalPages}
                    // Heads up! All items are powered by shorthands, if you want to hide one of them, just pass `null` as value
                    ellipsisItem={showEllipsis ? undefined : null}
                    firstItem={showFirstAndLastNav ? undefined : null}
                    lastItem={showFirstAndLastNav ? undefined : null}
                    prevItem={showPreviousAndNextNav ? undefined : null}
                    nextItem={showPreviousAndNextNav ? undefined : null}
                  />
                </Menu>
              </Table.HeaderCell>
            </Table.Row>
          </Table.Footer>
        </Table>

        {/* <div onClick={() => this.setState({ medicineModalVisibility: true })}>
          <Fab
            mainButtonStyles={mainButtonStyles}
            icon={<Icon name="plus" />}
          />
        </div> */}
      </Segment>
    );
  }
}
