const libPhone = require('google-libphonenumber');

const PNF = libPhone.PhoneNumberFormat;
const phoneUtil = libPhone.PhoneNumberUtil.getInstance();

const formatNumber = (number) => {
  let phoneNumber;
  try {
    phoneNumber = phoneUtil.parse(number);
  } catch (err) {
    return { isValid: false };
  }
  const isValid = phoneUtil.isValidNumber(phoneNumber);

  const ret = { isValid };
  if (isValid) ret.number = phoneUtil.format(phoneNumber, PNF.E164);
  return ret;
};

exports.formatNumber = formatNumber;

const isValid = (number) => {
  const formattedNumber = formatNumber(number);
  return formattedNumber.isValid && formattedNumber.number === number;
};

exports.isValid = isValid;
