import React from 'react';
import {
	Button,
	Modal,
	Icon,
	Form,
	Input,
	List,
	Table,
	Grid,
	Card
} from 'semantic-ui-react';
import moment from 'moment';

import { titleCase } from '../../../const';

const { Row, Column } = Grid;

const renderObject = obj => {
	const arr = [];

	for (key in obj) {
		arr.push(
			<Table.Row key={key}>
				<Table.Cell>
					<b>{titleCase(key)}:</b>{' '}
				</Table.Cell>
				<Table.Cell>
					<b> {obj[key] ? obj[key].toString() : 'Not Given'} </b>{' '}
				</Table.Cell>
			</Table.Row>
		);
	}

	return (
		<Table basic='very' textAlign='left'>
			<Table.Body>{arr}</Table.Body>
		</Table>
	);
};

const handleArray = (v, key) => {
	if (!v || typeof v.map != 'function') return;
	const arrHeaderSet = new Set();
	const arrHeaderRow = [];
	const arrBody = [];

	try {
		v.map(itm => {
			for (let k in itm) {
				if (itm.hasOwnProperty(k)) arrHeaderSet.add(k);
			}
		});
	} catch (e) {
		console.log(e, v, typeof v, v.map);
	}

	const temArr = Array.from(arrHeaderSet);
	// console.log(temArr);
	// temArr.map(itm => console.log(itm));
	temArr.map(itm =>
		arrHeaderRow.push(<Table.HeaderCell>{titleCase(itm)}</Table.HeaderCell>)
	);
	// new Array([...arrHeaderSet]).map(itm => console.log(itm));

	// console.log(arrHeaderSet);
	v.map((item, idx) => {
		const singleRow = [];
		for (idx in temArr) {
			const k = temArr[idx];
			singleRow.push(
				<Table.Cell>
					{' '}
					{item.hasOwnProperty(k) ? item[k] : 'Not Given'}{' '}
				</Table.Cell>
			);
		}
		arrBody.push(<Table.Row>{singleRow}</Table.Row>);
	});

	return (
		<React.Fragment>
			{titleCase(key)}
			<Table selectable>
				<Table.Header>{arrHeaderRow}</Table.Header>
				<Table.Body>{arrBody}</Table.Body>
			</Table>
		</React.Fragment>
	);
};

const renderRow = (v, key) => {
	// console.log(v);
	if (typeof v == 'boolean')
		return (
			<Row>
				<Column width={4}>
					<b>
						{titleCase(key)}: {'  '} {'  '}{' '}
					</b>
				</Column>
				<Column width={12}> {v ? 'Yes' : 'No'} </Column>
			</Row>
		);
	else if (Array.isArray(v)) {
		return (
			<Row>
				<Column width={16}> {handleArray(v, key)} </Column>
			</Row>
		);
	} else if (typeof v == 'object') {
		const m = moment(v);
		return (
			<Row>
				<Column width={4}>
					<b>
						Date : {'  '} {'  '}{' '}
					</b>
				</Column>
				<Column width={12}>
					{' '}
					{m.isValid ? m.format('LLL') : 'Invalid value.'}{' '}
				</Column>
			</Row>
		);
	}
	return (
		<Row>
			<Column width={4}>
				<b>{titleCase(key)}: </b>{' '}
			</Column>
			<Column width={12}>{v ? titleCase(v.toString()) : 'Not Given'}</Column>
		</Row>
	);
};

/*
 *  props: {
 *     item: Object
 *     visibility: Boolean
 *     visibilityname: String
 *     heading: String
 *     updateState: function bound in parent context
 *  }
 */
export const DetailsModal = props => {
	// console.log(props.item.prescriptions, props);
	const { item } = props;
	if (Object.keys(item).length == 0) return null;
	const prescriptions = item.prescriptions ? [...item.prescriptions] : null;
	delete item.id;
	delete item.prescriptions;
	// console.log(Array.isArray(prescriptions), props.item);

	const arr = [];
	for (k in item) if (k != '_id') arr.push(renderRow(item[k], k));
	return (
		<Modal
			header='Reminder!'
			open={props.visibility}
			actions={['Ok', 'Cancel']}
			size='small'
		>
			<Modal.Header>{props.heading}</Modal.Header>
			<Modal.Content>
				<Grid width={16} textAlign='left'>
					{arr}
					{props.type == 'medicine' && (
						// renderPrescriptions(item)
						<Grid width={16} textAlign='left'>
							<Column width={4}>Uploaded Reports:</Column>
							<Column width={12}>
								{prescriptions && (
									<Card.Group itemsPerRow={3} style={{ cursor: 'pointer' }}>
										{prescriptions.map(itm => (
											<Card
												raised
												color='red'
												image={itm}
												onClick={() => window.open(itm, '_blank')}
											/>
										))}
									</Card.Group>
								)}
							</Column>
						</Grid>
					)}
				</Grid>
			</Modal.Content>
			<Modal.Actions>
				<Button
					basic
					color='red'
					onClick={() => {
						props.updateState({ [props.visibilityname]: false });
					}}
				>
					<Icon name='remove' /> Close
				</Button>
			</Modal.Actions>
		</Modal>
	);
};

// const item = {
//   name: 'Not Given',
//   phone: 'Not Given',
//   email: 'Not Given',
//   category: 'Not Given',
//   description: 'Not Given',
// };

// DetailsModal.defaultProps = {
//   item,
// };
