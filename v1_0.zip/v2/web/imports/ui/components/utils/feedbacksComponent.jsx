import React from 'react';
import {
  Dropdown,
  Icon,
  Menu,
  Table,
  Header,
  Loader,
  Label,
  Pagination,
} from 'semantic-ui-react';
import { Meteor } from 'meteor/meteor';
import { withTracker } from 'meteor/react-meteor-data';

import { Feedback } from '../../../api/utils/utilSchemas';

import { DetailsModal } from './modals';
import { feedback_status } from '../../../const';

page_size = 10;

class FeedbackComponent extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      detailsModalVisibility: false,
      item: {},
      boundaryRange: 1,
      siblingRange: 3,
      showEllipsis: true,
      showFirstAndLastNav: true,
      showPreviousAndNextNav: true,
      totalPages: 1,
    };

    this.fetchFeedbackCount();
  }

  fetchFeedbackCount() {
    Meteor.call('fetchFeedbackCount', (err, res) => {
      // console.log(err, res);
      // console.log(Math.ceil(res / page_size));
      if (err) alert('Failed to fetch medicine count, please try again later');
      else if (res) this.setState({ totalPages: Math.ceil(res / page_size) });
    });
  }

  updateState(obj) {
    this.setState(obj);
  }

  updateStatus(id, v) {
    Meteor.call('updateFeedbackStatus', id, v, (err, res) => {
      console.log(err, res);
    });
  }

  handlePaginationChange = (e, { activePage }) => {
    // this.setState({ activePage }, () => this.fetchData());
    this.props.updateState({ activePage });
  };

  renderStatus(id, status) {
    // console.log(id, status);
    const trigger = (
      <span>
        <Label empty circular color={feedback_status[status]} key={status} />{' '}
        {status}
      </span>
    );
    const options = [];
    for (let k in feedback_status)
      options.push({
        key: k,
        text: k,
        value: k,
        label: { color: feedback_status[k], empty: true, circular: true },
      });
    return (
      <Dropdown
        trigger={trigger}
        options={options}
        onChange={(e, v) => {
          this.updateStatus(id, v.value);
        }}
      />
    );
  }

  render() {
    const {
      detailsModalVisibility,
      item,
      boundaryRange,
      siblingRange,
      totalPages,
      showEllipsis,
      showFirstAndLastNav,
      showPreviousAndNextNav,
    } = this.state;

    const { list, isReady: isDataLoaded, activePage } = this.props;

    // console.log(this.props, this.state);
    return (
      <div>
        <DetailsModal
          visibility={detailsModalVisibility}
          visibilityname="detailsModalVisibility"
          heading="Feedbback Details"
          item={item}
          updateState={this.updateState.bind(this)}
        />
        <Header as="h3">User Feedbacks</Header>
        {!isDataLoaded && <Loader active inline="centered" />}
        {isDataLoaded && (
          <Table celled>
            <Table.Header>
              <Table.Row>
                <Table.HeaderCell>Sl. No.</Table.HeaderCell>
                {/* <Table.HeaderCell>Categrory</Table.HeaderCell> */}
                <Table.HeaderCell>Name</Table.HeaderCell>
                <Table.HeaderCell>Phone</Table.HeaderCell>
                <Table.HeaderCell>Email</Table.HeaderCell>
                <Table.HeaderCell>Message</Table.HeaderCell>
                <Table.HeaderCell>Status</Table.HeaderCell>
              </Table.Row>
            </Table.Header>

            <Table.Body>
              {list.map((item, idx) => (
                <Table.Row
                  key={idx}
                  onClick={() =>
                    this.setState({ item, detailsModalVisibility: true })
                  }
                  style={{cursor: 'pointer'}}
                >
                  <Table.Cell> {idx + 1} </Table.Cell>
                  {/* <Table.Cell>{item.categrory}</Table.Cell> */}
                  <Table.Cell>{item.name}</Table.Cell>
                  <Table.Cell>{item.phone}</Table.Cell>
                  <Table.Cell>{item.email}</Table.Cell>
                  <Table.Cell>{item.description}</Table.Cell>
                  <Table.Cell>
                    {this.renderStatus(item._id, item.status)}
                  </Table.Cell>
                </Table.Row>
              ))}
            </Table.Body>

            <Table.Footer>
              <Table.Row>
                <Table.HeaderCell colSpan="9">
                  <Menu floated="right" pagination>
                    <Pagination
                      floated="right"
                      activePage={activePage}
                      boundaryRange={boundaryRange}
                      onPageChange={this.handlePaginationChange}
                      size="small"
                      siblingRange={siblingRange}
                      totalPages={totalPages}
                      // Heads up! All items are powered by shorthands, if you want to hide one of them, just pass `null` as value
                      ellipsisItem={showEllipsis ? undefined : null}
                      firstItem={showFirstAndLastNav ? undefined : null}
                      lastItem={showFirstAndLastNav ? undefined : null}
                      prevItem={showPreviousAndNextNav ? undefined : null}
                      nextItem={showPreviousAndNextNav ? undefined : null}
                    />
                  </Menu>
                </Table.HeaderCell>
              </Table.Row>
            </Table.Footer>
          </Table>
        )}
      </div>
    );
  }
}

export default withTracker(props => {
  // console.log(props);
  const handle = Meteor.subscribe('fetchFeedbacks', props.activePage);

  return {
    ...props,
    isReady: handle.ready(),
    list: Feedback.find().fetch(),
  };
})(FeedbackComponent);
