import React from 'react';

import FeedbackComponent from './feedbacksComponent';

page_size = 10;

export default class Feedback extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      activePage: 1,
    };
  }

  updateState(obj) {
    this.setState(obj);
  }

  render() {
    return (
      <FeedbackComponent
        updateState={this.updateState.bind(this)}
        activePage={this.state.activePage}
      />
    );
  }
}
