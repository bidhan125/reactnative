import React from 'react';

import {
  CartesianGrid,
  Tooltip,
  XAxis,
  YAxis,
  BarChart,
  Bar,
  Cell,
  ComposedChart,
  Line,
  Area,
  AreaChart,
  Legend,
  Scatter,
  LineChart,
} from 'recharts';
import moment from 'moment'

import { Header, Segment, Card, Image, Icon } from 'semantic-ui-react';
import { Meteor } from 'meteor/meteor';

class Dashboard extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      isDataFetched: false,
      appointments: [],
      medicines: []
    };

    this.fetchData();
  }

  fetchData() {
    Meteor.call('fetchDashboardData', (err, res) => {
      // console.log(err, res);
      if (err) alert('Failed to fetch Dashboard data. Please try again later');
      else if (res) {
        this.setState({ ...res, isDataFetched: true });
      }
    });
  }

  renderCards() {
    const {
      total_branches,
      total_doctors,
      total_users,
      total_appointments,
      total_orders,
      total_medicines,
      isDataFetched,
    } = this.state;
    const square = { width: 175, height: 175 };
    return (
      <Segment placeholder>
        <h2> Lifetime Statistics </h2>
        <div
          style={{
            display: 'flex',
            'justify-content': 'space-around',
            marginTop: 25,
            marginBottom: 20,
          }}
        >
          <div>
            <Segment circular style={{ ...square, borderColor: 'red' }}>
              <Header as="h2">
                {' '}
                {isDataFetched ? (
                  total_users
                ) : (
                  <Icon loading name="spinner" />
                )}{' '}
                <Header.Subheader>Total Users</Header.Subheader>
              </Header>
            </Segment>
          </div>

          <div>
            <Segment circular style={{ ...square, borderColor: 'blue' }}>
              <Header as="h2">
                {' '}
                {isDataFetched ? (
                  total_doctors
                ) : (
                  <Icon loading name="spinner" />
                )}{' '}
                <Header.Subheader>Total Doctors</Header.Subheader>
              </Header>
            </Segment>
          </div>

          <div>
            <Segment circular style={{ ...square, borderColor: 'green' }}>
              <Header as="h2">
                {' '}
                {isDataFetched ? (
                  total_branches
                ) : (
                  <Icon loading name="spinner" />
                )}{' '}
                <Header.Subheader>Total Branches</Header.Subheader>
              </Header>
            </Segment>
          </div>

          <div>
            <Segment circular style={{ ...square, borderColor: 'orange' }}>
              <Header as="h2">
                {' '}
                {isDataFetched ? (
                  total_appointments
                ) : (
                  <Icon loading name="spinner" />
                )}{' '}
                <Header.Subheader>Total Appointments</Header.Subheader>
              </Header>
            </Segment>
          </div>

          <div>
            <Segment circular style={{ ...square, borderColor: 'purple' }}>
              <Header as="h2">
                {' '}
                {isDataFetched ? (
                  total_orders
                ) : (
                  <Icon loading name="spinner" />
                )}{' '}
                <Header.Subheader>Total Orders</Header.Subheader>
              </Header>
            </Segment>
          </div>
          <div>
            <Segment circular style={{ ...square, borderColor: 'brown' }}>
              <Header as="h2">
                {' '}
                {isDataFetched ? (
                  total_medicines
                ) : (
                  <Icon loading name="spinner" />
                )}{' '}
                <Header.Subheader>Total Medicines</Header.Subheader>
              </Header>
            </Segment>
          </div>
        </div>
      </Segment>
    );
  }

  renderChart(data, key, color1, color2) {
    const w = screen.width;
    console.log(data, key)
    return (
      <Segment placeholder>
        <h2>{key}</h2>
        <AreaChart
          width={w - 300}
          height={250}
          data={data}
          margin={{
            top: 15,
            right: 5,
            left: 5,
            bottom: 5,
          }}
          // syncId="anyId"
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey='date' />
          <YAxis />
          <Tooltip />
          <Legend />
          <Area type="monotone" dataKey="count" stroke={color1} fill={color2} />
          {/* <Line type="monotone" dataKey="uv" stroke="#82ca9d" /> */}
        </AreaChart>
      </Segment>
    );
  }
  render() {
    return (
      <Segment basic>
        <Header as="h3">Dashboard</Header>
        {/* <Card color="red"> */}
        {this.renderCards()}
        {this.renderChart(
          this.state.appointments.map(itm=> {
              const m = moment(itm.date)
              return {count: itm.count, date: m.format('dddd')}
            } ) ,
          'Appointments (Last 7 Days)',
          '#000',
          '#e4f280',
        )}
        {this.renderChart(
          this.state.medicines.map(itm=> {
            const m = moment(itm.date)
            return {count: itm.count, date: m.format('dddd')}
          } ) ,
          'Medicine & Medical Accessories  (Last 7 Days)',
          '#000',
          '#7fcbf1',
        )}
      </Segment>
    );
  }
}

export default Dashboard;
