import React from 'react';
import { Button, Modal, Icon, Form, TextArea } from 'semantic-ui-react';

import EditorComponent from '../editor/editor';
//import { stateToHTML } from 'draft-js-export-html';
// import { Editor, EditorState, RichUtils } from 'draft-js';
// import { stateToHTML } from 'draft-js-export-html';

export const AddTestModal = props => {
	let { branchesList, categoriesList, requirementsList, edit } = props;
	// let editorState = localStorage.getItem("editorData");
	// let editorContentHtml = stateToHTML(JSON.parse(editorState.getCurrentContent()))
	// let kaka = stateToHTML(JSON.parse(contentState.getCurrentContent()));
	// console.log(props);
	let {
		name,
		type,
		categories,
		branches,
		prerequisitesTestItem,
		description,
		prerequisites,
		price
	} = props.testItem;

	const branchOptions = branchesList.map((item, sl_no) => {
		return { key: sl_no, text: item.name, value: item.name };
	});
	branchOptions.unshift({ key: 'all', text: 'All Branches', value: 'all' });
	updateState = (name, value) => {
		//console.log(name, value)
		props.updateDescriptionState(name, value);
	};

	return (
		<Modal
			header='Reminder!'
			open={props.visibility}
			actions={['Ok', 'Cancel']}
		>
			<Modal.Header>Diagnostic Test Details</Modal.Header>
			<Modal.Content>
				<Form>
					<Form.Field>
						<label>Diagostic Test Name</label>
						<input
							placeholder='Diagostic Test Name'
							value={name}
							onChange={v =>
								props.updateStateTestItem({ name: v.target.value })
							}
						/>
					</Form.Field>
					<Form.Group inline>
						<label>Test Type</label>
						<Form.Radio
							label='Single Test'
							checked={type == 'single'}
							onClick={() => props.updateStateTestItem({ type: 'single' })}
						/>
						<Form.Radio
							label='Package Test'
							checked={type == 'package'}
							onClick={() => props.updateStateTestItem({ type: 'package' })}
						/>
					</Form.Group>
					<Form.Field>
						<label>Price</label>
						<input
							placeholder='Price'
							value={price}
							onChange={v =>
								props.updateStateTestItem({ price: v.target.value })
							}
						/>
					</Form.Field>
					<Form.Field>
						<Form.Select
							fluid
							search
							multiple
							label='Select Branch'
							options={branchOptions}
							value={branches}
							onChange={(event, data) => {
								props.updateStateArray('branches', data.value);
							}}
							placeholder='Branch'
						/>
					</Form.Field>
					<Form.Field>
						<Form.Select
							fluid
							search
							multiple
							label='Select Category'
							value={categories}
							options={categoriesList.map((item, sl_no) => {
								return { key: sl_no, text: item.name, value: item.name };
							})}
							placeholder='Category'
							allowAdditions={true}
							additionLabel='Create :  '
							onAddItem={(event, data) => {
								props.addCategory(data.value);
							}}
							onChange={(event, data) => {
								props.updateStateArray('categories', data.value);
							}}
						/>
					</Form.Field>
					<Form.Field>
						<label>Description of Test </label>
						{/* <TextArea
              placeholder="Description"
              onChange={v => props.updateState({ description: v.target.value })}
            /> */}
						<div className='draft-design'>
							<EditorComponent
								updateDescriptionState={this.updateStateTestItem}
							/>
						</div>
						{/* <pre>{editorContentHtml}</pre> */}
					</Form.Field>
					<Form.Field>
						<Form.Select
							fluid
							search
							multiple
							selection
							label='Select Requirements'
							value={prerequisites}
							options={requirementsList.map((item, sl_no) => {
								return { key: sl_no, text: item.name, value: item.name };
							})}
							placeholder='Requirements'
							allowAdditions={true}
							additionLabel='Create :  '
							onAddItem={(event, data) => {
								console.log(data.value);
								props.addRequirement(data.value);
							}}
							onChange={(event, data) => {
								props.updateStateArray('prerequisites', data.value);
							}}
						/>
					</Form.Field>
				</Form>
			</Modal.Content>
			<Modal.Actions>
				<Button
					basic
					color='red'
					onClick={() => {
						props.updateState({ [props.visibilityname]: false });
					}}
				>
					<Icon name='remove' /> Cancel
				</Button>
				<Button
					color='green'
					onClick={() => {
						props.handleSubmit();
					}}
				>
					<Icon name='checkmark' /> {edit ? 'Update Test' : 'Add Test'}
				</Button>
			</Modal.Actions>
		</Modal>
	);
};

export const ViewModal = props => {
	render(
		<Modal
			header='Reminder!'
			open={props.visibility}
			actions={['Ok', 'Cancel']}
		>
			<Modal.Header>Diagnostic Test Details</Modal.Header>
			<Modal.Content>
				<Form>
					<Form.Field>
						<label>Diagostic Test Name</label>
						<input
							placeholder='Diagostic Test Name'
							onChange={v => props.updateState({ name: v.target.value })}
						/>
					</Form.Field>
					<Form.Field>
						<label>Price</label>
						<input
							placeholder='Price'
							onChange={v => props.updateState({ price: v.target.value })}
						/>
					</Form.Field>
					<Form.Field>
						<Form.Select
							fluid
							search
							multiple
							label='Select Branch'
							options={branchOptions}
							onChange={(event, data) => {
								props.updateState({ branches: data.value });
							}}
							placeholder='Branch'
						/>
					</Form.Field>
					<Form.Field>
						<Form.Select
							fluid
							search
							multiple
							label='Select Category'
							options={categories.map((item, sl_no) => {
								return { key: sl_no, text: item.name, value: item.name };
							})}
							placeholder='Category'
							allowAdditions={true}
							additionLabel='Create :  '
							onAddItem={(event, data) => {
								console.log(data.value);
								props.addCategory(data.value);
							}}
							onChange={(event, data) => {
								props.updateState({ categories: data.value });
							}}
						/>
					</Form.Field>
					<Form.Field>
						<label>Description of Test </label>
						{/* <TextArea
              placeholder="Description"
              onChange={v => props.updateState({ description: v.target.value })}
            /> */}
						<div className='draft-design'>
							<EditorComponent
								updateDescriptionState={props.updateDescriptionState}
							/>
						</div>
					</Form.Field>
					<Form.Field>
						<Form.Select
							fluid
							search
							multiple
							selection
							label='Select Requirements'
							options={requirements.map((item, sl_no) => {
								return { key: sl_no, text: item.name, value: item.name };
							})}
							placeholder='Requirements'
							allowAdditions={true}
							additionLabel='Create :  '
							onAddItem={(event, data) => {
								console.log(data.value);
								props.addRequirement(data.value);
							}}
							onChange={(event, data) => {
								props.updateState({ prerequisites: data.value });
							}}
						/>
					</Form.Field>
				</Form>
			</Modal.Content>
			<Modal.Actions>
				<Button
					basic
					color='red'
					onClick={() => {
						props.updateState({ modalAddTest: false });
					}}
				>
					<Icon name='remove' /> No
				</Button>
				<Button
					color='green'
					onClick={() => {
						props.handleSubmit();
					}}
				>
					<Icon name='checkmark' /> Yes
				</Button>
			</Modal.Actions>
		</Modal>
	);
};
