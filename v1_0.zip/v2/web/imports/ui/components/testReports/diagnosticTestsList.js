import React from 'react';
import { withTracker } from 'meteor/react-meteor-data';
import { Icon, Menu, Table, Header, Label, ItemMeta } from 'semantic-ui-react';
import toastr from 'toastr';

import { Fab, Action } from 'react-tiny-fab';
import { mainButtonStyles, actionButtonStyles } from '../../../const';

import { AddTestModal } from './modals';
import { DiagnosticTests } from '../../../api/diagnosticTests/diagnosticTests';

class DiagnosticTestList extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			modalAddTest: false,
			modalEditTest: false,
			name: undefined,
			branch: undefined,
			category: undefined,
			description: undefined,
			prerequisites: [],

			testItem: {}
		};
	}

	updateState(obj) {
		this.setState(obj);
	}

	updateStateTestItem(obj) {
		this.setState({
			testItem: {
				...this.state.testItem,
				...obj
			}
		});
	}

	updateStateArray(key, arr) {
		console.log(key, arr);
		const { testItem } = this.state;
		testItem[key] = arr;
		this.setState(testItem);
	}
	updateDescriptionState(name, value) {
		this.setState({ [name]: value });
	}

	handleSubmit() {
		const {
			_id,
			name,
			type,
			categories,
			description,
			prerequisites,
			price
		} = this.state.testItem;
		const { modalAddTest } = this.state;
		let { branches } = this.state.testItem;
		if (branches.length == 1 && branches[0] == 'all')
			branches = this.props.branches.map(item => item.name);
		const data = {
			_id,
			name,
			type,
			price,
			branches,
			categories,
			description,
			prerequisites
		};
		Meteor.call(
			modalAddTest ? 'addDiagnosticTest' : 'updateDiagnosticTest',
			data,
			(err, res) => {
				console.log(err, res);
				if (err)
					alert(
						'Sorry! Failed to add Diagnostic Test Item. Please try again later. '
					);
				else if (res) {
					this.setState({
						modalAddTest: false,
						modalEditTest: false,
						testItem: {}
					});
				}
			}
		);
	}

	addCategory(name) {
		Meteor.call(
			'addCategory',
			{ name, type: 'diagnostic_test' },
			(err, res) => {
				// console.log(err, res);
				if (err)
					alert('Sorry! Failled to add Category. Please try again later');
				else if (res) {
					this.props.fetchData();
				}
			}
		);
	}

	addRequirement(name) {
		Meteor.call('addRequirement', { name }, (err, res) => {
			// console.log(err, res);
			if (err)
				alert('Sorry! Failled to add Reqirement. Please try again later');
			else if (res) {
				this.props.fetchData();
			}
		});
	}

	removeTest(id) {
		Meteor.call('removeDiagnosticTest', id, (err, res) => {
			if (err)
				toastr.error('Sorry! Failed to remove item. Please try again later');
			else if (res) toastr.info(res);
		});
	}

	render() {
		const { type, description } = this.state;
		// console.log(description);
		const { list, branches, categories, requirements } = this.props;

		const { modalAddTest, modalEditTest } = this.state;
		const { testItem } = this.state;

		// console.log(testItem);

		return (
			<React.Fragment>
				{/* <pre>{description}</pre> */}
				{modalAddTest && (
					<AddTestModal
						visibility={modalAddTest}
						visibilityname='modalAddTest'
						branchesList={branches}
						categoriesList={categories}
						requirementsList={requirements}
						testItem={testItem}
						updateState={this.updateState.bind(this)}
						handleSubmit={this.handleSubmit.bind(this)}
						addCategory={this.addCategory.bind(this)}
						addRequirement={this.addRequirement.bind(this)}
						updateDescriptionState={this.updateDescriptionState.bind(this)}
						updateStateTestItem={this.updateStateTestItem.bind(this)}
						updateStateArray={this.updateStateArray.bind(this)}
					/>
				)}
				{modalEditTest && (
					<AddTestModal
						edit={true}
						visibility={modalEditTest}
						visibilityname='modalEditTest'
						branchesList={branches}
						categoriesList={categories}
						requirementsList={requirements}
						testItem={testItem}
						updateState={this.updateState.bind(this)}
						handleSubmit={this.handleSubmit.bind(this)}
						addCategory={this.addCategory.bind(this)}
						addRequirement={this.addRequirement.bind(this)}
						updateDescriptionState={this.updateDescriptionState.bind(this)}
						updateStateTestItem={this.updateStateTestItem.bind(this)}
						updateStateArray={this.updateStateArray.bind(this)}
					/>
				)}
				<Table celled selectable>
					<Table.Header>
						<Table.Row>
							<Table.HeaderCell>Sl. No.</Table.HeaderCell>
							<Table.HeaderCell>Test Name</Table.HeaderCell>
							<Table.HeaderCell> Branch Name </Table.HeaderCell>
							<Table.HeaderCell>Category</Table.HeaderCell>
							<Table.HeaderCell>Cost</Table.HeaderCell>
							<Table.HeaderCell>Actions</Table.HeaderCell>
						</Table.Row>
					</Table.Header>

					<Table.Body>
						{list &&
							list.length &&
							list.map((item, sl_no) => {
								return (
									<Table.Row>
										<Table.Cell>{sl_no + 1}</Table.Cell>
										<Table.Cell>{item.name}</Table.Cell>
										<Table.Cell>
											{item.branches.map(item => (
												<Label basic size='tiny' as='a'>
													{item}
												</Label>
											))}
										</Table.Cell>
										<Table.Cell>
											{item.categories.map(item => (
												<Label tag as='a'>
													{item}
												</Label>
											))}
										</Table.Cell>
										<Table.Cell>{item.price}</Table.Cell>
										<Table.Cell>
											<Icon
												style={{ cursor: 'pointer', marginRight: '7px' }}
												name='pencil'
												circular
												onClick={() => {
													this.setState({ testItem: item }, () =>
														this.setState({
															modalEditTest: true,
															testItem: item
														})
													);
												}}
											/>
											<Icon
												style={{ cursor: 'pointer' }}
												name='remove'
												circular
												onClick={() => this.removeTest(item._id)}
											/>
										</Table.Cell>
									</Table.Row>
								);
							})}
					</Table.Body>

					{/* {list && list.length >= 5 && (
            <Table.Footer>
              <Table.Row>
                <Table.HeaderCell colSpan="7">
                  <Menu floated="right" pagination>
                    <Menu.Item as="a" icon>
                      <Icon name="chevron left" />
                    </Menu.Item>
                    <Menu.Item as="a">1</Menu.Item>
                    <Menu.Item as="a">2</Menu.Item>
                    <Menu.Item as="a">3</Menu.Item>
                    <Menu.Item as="a">4</Menu.Item>
                    <Menu.Item as="a" icon>
                      <Icon name="chevron right" />
                    </Menu.Item>
                  </Menu>
                </Table.HeaderCell>
              </Table.Row>
            </Table.Footer>
          )} */}
				</Table>
				{/* </div> */}
				<div onClick={() => this.setState({ modalAddTest: true })}>
					<Fab
						mainButtonStyles={mainButtonStyles}
						icon={<Icon name='plus' />}
					/>
				</div>
			</React.Fragment>
		);
	}
}

export default withTracker(props => {
	const handle = Meteor.subscribe(
		'fetch.diagnosticTests',
		props.type,
		props.searchQuery
	);

	return {
		ready: !handle.ready(),
		list: DiagnosticTests.find().fetch()
	};
})(DiagnosticTestList);
