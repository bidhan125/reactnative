import React from 'react';
import { withTracker } from 'meteor/react-meteor-data';
import { Icon, Menu, Table, Header } from 'semantic-ui-react';
import { Branches } from '../../../api/doctors/branches';

class TestHomeCollectionRequests extends React.Component {
  render() {
    console.log(this.props);
    const { list } = this.props;

    return (
      <Table celled selectable>
        <Table.Header>
          <Table.Row>
            <Table.HeaderCell>Sl. No.</Table.HeaderCell>
            <Table.HeaderCell>Branch Name</Table.HeaderCell>
            <Table.HeaderCell>Phone Number</Table.HeaderCell>
            <Table.HeaderCell>Address</Table.HeaderCell>
            <Table.HeaderCell>District</Table.HeaderCell>
          </Table.Row>
        </Table.Header>

        <Table.Body>
          {list &&
            list.length &&
            list.map((item, sl_no) => {
              return (
                <Table.Row>
                  <Table.Cell>{sl_no + 1}</Table.Cell>
                  <Table.Cell>{item.name}</Table.Cell>
                  <Table.Cell>{item.phone}</Table.Cell>
                  {/* <Table.Cell>
                      {item.createdAt && item.createdAt.toLocaleDateString()}
                    </Table.Cell> */}
                  <Table.Cell>{item.address}</Table.Cell>
                  <Table.Cell>{item.district}</Table.Cell>
                </Table.Row>
              );
            })}
        </Table.Body>

        {list && list.length >= 5 && (
          <Table.Footer>
            <Table.Row>
              <Table.HeaderCell colSpan="7">
                <Menu floated="right" pagination>
                  <Menu.Item as="a" icon>
                    <Icon name="chevron left" />
                  </Menu.Item>
                  <Menu.Item as="a">1</Menu.Item>
                  <Menu.Item as="a">2</Menu.Item>
                  <Menu.Item as="a">3</Menu.Item>
                  <Menu.Item as="a">4</Menu.Item>
                  <Menu.Item as="a" icon>
                    <Icon name="chevron right" />
                  </Menu.Item>
                </Menu>
              </Table.HeaderCell>
            </Table.Row>
          </Table.Footer>
        )}
      </Table>
    );
  }
}

export default withTracker(props => {
  // console.log(props);
  const handle = Meteor.subscribe('fetch.branches');

  return {
    ready: !handle.ready(),
    list: Branches.find().fetch(),
  };
})(TestHomeCollectionRequests);
