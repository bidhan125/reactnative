import React from 'react';
import { Icon, Menu, Table, Header } from 'semantic-ui-react';

import DiagnosticTestList from './diagnosticTestsList';
import ReportHomeDelliveryRequests from './reportHomeDelliveryRequests';
import TestHomeCollectionRequests from './testHomeCollectionRequests';
import { Meteor } from 'meteor/meteor';

export default class TestReports extends React.Component {
	constructor(props) {
		super(props);

		this.state = {
			activeItem: 'single_test',
			branches: [],
			categories: [],
			requirements: [],
			searchQuery: ''
		};

		this.fetchData();
	}

	fetchData() {
		this.fetchBranches();
		this.fetchCategories();
		this.fetchRequirements();
	}

	fetchBranches() {
		Meteor.call('fetchBranches', (err, res) => {
			// console.log(err, res);
			this.setState({ branches: res });
		});
	}
	fetchCategories() {
		Meteor.call('fetchCategories', 'diagnostic_test', (err, res) => {
			// console.log(err, res);
			this.setState({ categories: res });
		});
	}
	fetchRequirements() {
		Meteor.call('fetchRequirements', (err, res) => {
			// console.log(err, res);
			this.setState({ requirements: res });
		});
	}

	render() {
		const {
			activeItem,
			branches,
			categories,
			requirements,
			searchQuery
		} = this.state;
		return (
			<div>
				<div className='infoTopBar'>
					<div
						className='ui transparent left icon input patientSrc left floated'
						onChange={v => {
							const x = v.target.value;

							this.setState({ searchQuery: x }, () => {
								if (x.length > 2) this.setState({ searchQuery: x });
							});
						}}
					>
						<input
							type='text'
							placeholder='Search Diagnostic Test'
							value={this.state.searchQuery}
						/>
						<i className='search icon' />
					</div>

					<div className='filterContainer'>
						<ul>
							<li style={{ marginLeft: '15px' }}>
								<button
									className='ui teal small button'
									style={{ margin: '0' }}
									onClick={() =>
										this.setState({ searchQuery: '', form: undefined }, () =>
											this.fetchData(true)
										)
									}
								>
									Clear Filter
								</button>
								{/* <button className="ui small basic red button">Delete</button> */}
							</li>
						</ul>
					</div>
				</div>

				<Menu tabular>
					<Menu.Item
						name='Single Tests'
						active={activeItem === 'single_test'}
						onClick={() => this.setState({ activeItem: 'single_test' })}
					/>
					<Menu.Item
						name='Package Test'
						active={activeItem === 'package_test'}
						onClick={() => this.setState({ activeItem: 'package_test' })}
					/>
				</Menu>
				{activeItem == 'single_test' && (
					<DiagnosticTestList
						fetchData={this.fetchData.bind(this)}
						branches={branches}
						categories={categories}
						requirements={requirements}
						type='single'
						searchQuery={searchQuery}
					/>
				)}
				{activeItem == 'package_test' && (
					<DiagnosticTestList
						fetchData={this.fetchData.bind(this)}
						branches={branches}
						categories={categories}
						requirements={requirements}
						type='package'
						searchQuery={searchQuery}
					/>
				)}
				{/* {activeItem == 'homeCollection' && <TestHomeCollectionRequests />} */}
				{/* {activeItem == 'homeDelivery' && <ReportHomeDelliveryRequests />} */}
			</div>
		);
	}
}
