import React from 'react';
import { withTracker } from 'meteor/react-meteor-data';
import {
  Button,
  Dimmer,
  Header,
  Icon,
  Image,
  Loader,
  Menu,
  Pagination,
  Placeholder,
  Segment,
  Table
} from 'semantic-ui-react';
import { Session } from 'meteor/session';
import moment from 'moment';
import toastr from 'toastr'

import { Appointments } from '../../../api/appointments/appointments';
import { titleCase } from '../../../const';

import { DetailsModal } from '../utils/modals';

page_size = 10;

class AppointmentsPage extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      activePage: 1,
      boundaryRange: 1,
      siblingRange: 3,
      showEllipsis: true,
      showFirstAndLastNav: true,
      showPreviousAndNextNav: true,
      totalPages: 0,
      appointmentItem: {},

      visibilityDetailsModal: false
    };
    Session.setDefault('activePage', 1);

    this.fetchTotalCount();
  }

  fetchTotalCount() {
    Meteor.call('fetchTotalAppointmentCount', (err, res) => {
      if (err) {
        console.log('Sorry! Failed to fetch total count of appointments.');
      } else if (res) {
        console.log(res);
        this.setState({ totalPages: parseInt(res / page_size) + 1 });
      }
    });
  }

  handleUpdateStatus(id, status) {
    Meteor.call('updateAppointment', { id, status }, (err, res) => {
      if (err) {
        alert(
          'Sorry! Failed to update the appointment status at this moment. Please try again after sometime'
        );
      } else if (res) {
        status == 'approved' ? 
          toastr.success('Appointment request approved successfully!') 
          : 
          toastr.error('Appointment request rejected successfully!')
      }
    });
  }

  handlePaginationChange = (e, { activePage }) => {
    Session.set('activePage', activePage);
    this.setState({ activePage });
  };

  parseTime(t) {
    const m = new moment(t);
    return m.format('DD-MM-YY, HH:mm');
  }

  updateState(obj) {
    this.setState(obj);
  }

  handleClick(item) {
    const { doctor, patient, time, branch, status } = item;
    const obj = {
      'Doctor Name': doctor.name,
      'Doctor Phone': doctor.phone,
      'Patient Name': patient.name,
      'Patient Gender': patient.gender,
      'Patient Age': patient.age,

      time,
      branch,
      status
    };
    this.setState({ appointmentItem: obj }, () =>
      this.setState({ visibilityDetailsModal: true })
    );
  }

  render() {
    // console.log(this.props);
    const {
      activePage,
      boundaryRange,
      siblingRange,
      totalPages,
      showEllipsis,
      showFirstAndLastNav,
      showPreviousAndNextNav,
      appointmentItem,
      visibilityDetailsModal
    } = this.state;

    // console.log(this.state);

    const { isReady } = this.props;
    return (
      <React.Fragment>
        <DetailsModal
          heading="Appointment Details"
          item={appointmentItem}
          visibility={visibilityDetailsModal}
          visibilityname="visibilityDetailsModal"
          updateState={this.updateState.bind(this)}
        />
        <Header as="h3">Appointment List</Header>
        <Table celled selectable>
          <Table.Header>
            <Table.Row>
              <Table.HeaderCell>Sl. No.</Table.HeaderCell>
              <Table.HeaderCell>Patient's Name</Table.HeaderCell>
              <Table.HeaderCell>Patient's Phone</Table.HeaderCell>
              <Table.HeaderCell>Doctor's Name</Table.HeaderCell>
              <Table.HeaderCell>Time</Table.HeaderCell>
              <Table.HeaderCell> Branch </Table.HeaderCell>
              <Table.HeaderCell> Status </Table.HeaderCell>
              <Table.HeaderCell> Action </Table.HeaderCell>
            </Table.Row>
          </Table.Header>

          {/* TODO :: Loader not appearing  */}
          {!isReady && (
            <Table.Body>
              <Table.Row>
                <Table.Cell colSpan={5}>
                  <Loader inverted content="Loading" />
                  <Placeholder>
                    <Placeholder.Line />
                    <Placeholder.Line />
                    <Placeholder.Line />
                    <Placeholder.Line />
                    <Placeholder.Line />
                  </Placeholder>
                </Table.Cell>
              </Table.Row>
            </Table.Body>
          )}

          {isReady && (
            <Table.Body>
              {this.props.list.map((item, sl_no) => {
                return (
                  <Table.Row>
                    <Table.Cell>{sl_no + 10 * (activePage - 1) + 1}</Table.Cell>
                    <Table.Cell
                      style={{ cursor: 'pointer' }}
                      onClick={() => this.handleClick(item)}
                    >
                      {' '}
                      {(item.patient && item.patient.name) || 'Not Given'}{' '}
                    </Table.Cell>
                    <Table.Cell
                      style={{ cursor: 'pointer' }}
                      onClick={() => this.handleClick(item)}
                    >
                      {' '}
                      {(item.patient && item.patient.phone) || 'Not Given'}{' '}
                    </Table.Cell>
                    <Table.Cell
                      style={{ cursor: 'pointer' }}
                      onClick={() => this.handleClick(item)}
                    >
                      {item.doctor && item.doctor.name}
                    </Table.Cell>
                    <Table.Cell
                      style={{ cursor: 'pointer' }}
                      onClick={() => this.handleClick(item)}
                    >
                      {item.time && this.parseTime(item.time)}
                    </Table.Cell>
                    <Table.Cell
                      style={{ cursor: 'pointer' }}
                      onClick={() => this.handleClick(item)}
                    >
                      {' '}
                      {(item.branch && item.branch) || 'Not Given'}{' '}
                    </Table.Cell>
                    <Table.Cell
                      style={{ cursor: 'pointer' }}
                      onClick={() => this.handleClick(item)}
                    >
                      {' '}
                      {(item.status && titleCase(item.status)) ||
                        'Not Given'}{' '}
                    </Table.Cell>
                    <Table.Cell>
                      <Button.Group size="mini"  >
                        <Button
                          basic={!(item.status == 'rejected')}
                          color="red"
                          disabled={ item.status == 'cancelled' }
                          onClick={() =>
                            this.handleUpdateStatus(item._id, 'rejected')
                          }
                        >
                          Reject
                        </Button>
                        <Button.Or />
                        <Button
                          basic={!(item.status == 'approved')}
                          positive
                          disabled={ item.status == 'cancelled' }
                          onClick={() =>
                            this.handleUpdateStatus(item._id, 'approved')
                          }
                        >
                          Approve
                        </Button>
                      </Button.Group>
                    </Table.Cell>
                  </Table.Row>
                );
              })}
            </Table.Body>
          )}

          <Table.Footer>
            <Table.Row>
              <Table.HeaderCell colSpan="8">
                <Menu floated="right" pagination>
                  <Pagination
                    floated="right"
                    activePage={activePage}
                    boundaryRange={boundaryRange}
                    onPageChange={this.handlePaginationChange}
                    size="small"
                    siblingRange={siblingRange}
                    totalPages={totalPages}
                    // Heads up! All items are powered by shorthands, if you want to hide one of them, just pass `null` as value
                    ellipsisItem={showEllipsis ? undefined : null}
                    firstItem={showFirstAndLastNav ? undefined : null}
                    lastItem={showFirstAndLastNav ? undefined : null}
                    prevItem={showPreviousAndNextNav ? undefined : null}
                    nextItem={showPreviousAndNextNav ? undefined : null}
                  />
                </Menu>
              </Table.HeaderCell>
            </Table.Row>
          </Table.Footer>
        </Table>
      </React.Fragment>
    );
  }
}

export default withTracker(props => {
  const activePage = Session.get('activePage');
  const handle = Meteor.subscribe('fetch.all.appointments', activePage);

  return {
    currentUser: Meteor.user(),
    isReady: handle.ready(),
    list: Appointments.find().fetch()
  };
})(AppointmentsPage);
