import React from 'react';
import {
  Modal,
  Header,
  Image,
  Icon,
  Segment,
  Card,
  Button,
  Select,
  Table,
  Menu,
} from 'semantic-ui-react';

import { Fab, Action } from 'react-tiny-fab';

import { AddMedicineModal } from './modals';
import MedAccessoriesMain from './medAccessoriesMain';
import CategoriesList from './categories';

import { mainButtonStyles, actionButtonStyles } from '../../../const';

export default class MedAccessories extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      list: [],
      activeItem: 'medAccessories',
    };

    this.fetchData();
  }

  fetchData() {
    Meteor.call('fetchCategories', 'medical_accessory', (err, res) => {
      // console.log(err, res);
      if (err) {
        console.log('Failed to fetch category list');
      } else if (res) {
        this.setState({ list: res });
      }
    });
  }

  updateState(obj) {
    this.setState(obj);
  }

  render() {
    const { list, activeItem } = this.state;
    // console.log(list);
    return (
      <React.Fragment>
        <Menu tabular>
          <Menu.Item
            name="Medical Accessories"
            active={activeItem === 'medAccessories'}
            onClick={() => this.setState({ activeItem: 'medAccessories' })}
          />
          <Menu.Item
            name="Categories"
            active={activeItem === 'categories'}
            onClick={() => this.setState({ activeItem: 'categories' })}
          />
        </Menu>

        {activeItem == 'medAccessories' && (
          <MedAccessoriesMain categories={list} />
        )}
        {activeItem == 'categories' && (
          <CategoriesList fetchData={this.fetchData.bind(this)} list={list} />
        )}
      </React.Fragment>
    );
  }
}
