import React from 'react';
import { Button, Modal, Icon, Form, TextArea } from 'semantic-ui-react';

import EditorComponent from '../editor/editor';

export const AddAccessoryModal = props => {
  // console.log(props);
  const { types } = props;
  const typeOptions = types.map((item, sl_no) => {
    return { key: sl_no, text: item.name, value: item.name };
  });

  return (
    <Modal
      header="Reminder!"
      open={props.visibility}
      actions={['Ok', 'Cancel']}
    >
      <Modal.Header>Add New Medical Accessory</Modal.Header>
      <Modal.Content>
        <Form>
          <Form.Field>
            <label>Accessory Name</label>
            <input
              placeholder="Accessory Name"
              onChange={v => props.updateState({ name: v.target.value })}
            />
          </Form.Field>
          <Form.Field>
            <Form.Select
              fluid
              search
              label="Select Type"
              options={typeOptions}
              onChange={(event, data) => {
                props.updateState({ type: data.value });
              }}
              placeholder="Type"
            />
          </Form.Field>

          <Form.Field>
            <label>Description of Accessory </label>
            <div className="draft-design">
              <EditorComponent updateState={props.updateState} />
            </div>
          </Form.Field>
          <Form.Field>
            <label>Manufacturer</label>
            <input
              placeholder="Manufacturer"
              onChange={v => props.updateState({ mfg: v.target.value })}
            />
          </Form.Field>
          <Form.Field>
            <label>Unit</label>
            <input
              placeholder="Unit"
              onChange={v => props.updateState({ unit: v.target.value })}
            />
          </Form.Field>
          <Form.Field>
            <label>Available Quantity</label>
            <input
              placeholder="Available Quantity"
              onChange={v =>
                props.updateState({ available_quantity: v.target.value })
              }
            />
          </Form.Field>
          <Form.Field>
            <label>Price</label>
            <input
              placeholder="Price"
              onChange={v => props.updateState({ price: v.target.value })}
            />
          </Form.Field>
        </Form>
      </Modal.Content>
      <Modal.Actions>
        <Button
          basic
          color="red"
          onClick={() => {
            props.updateState({ [props.visibilityname]: false });
          }}
        >
          <Icon name="remove" /> Cancel
        </Button>
        <Button
          color="green"
          onClick={() => {
            props.handleSubmit();
          }}
        >
          <Icon name="checkmark" /> Add Accessory
        </Button>
      </Modal.Actions>
    </Modal>
  );
};

export const AddCategoryModal = props => {
  return (
    <Modal
      header="Reminder!"
      open={props.visibility}
      actions={['Ok', 'Cancel']}
    >
      <Modal.Header>Add New Category</Modal.Header>
      <Modal.Content>
        <Form>
          <Form.Field>
            <label>Category Name</label>
            <input
              placeholder="Category Name"
              onChange={v => props.updateState({ name: v.target.value })}
            />
          </Form.Field>

          <Form.Field>
            <label>Note</label>
            <input
              placeholder="Note"
              onChange={v => props.updateState({ note: v.target.value })}
            />
          </Form.Field>
        </Form>
      </Modal.Content>
      <Modal.Actions>
        <Button
          basic
          color="red"
          onClick={() => {
            props.updateState({ [props.visibilityname]: false });
          }}
        >
          <Icon name="remove" /> Cancel
        </Button>
        <Button
          color="green"
          onClick={() => {
            props.handleSubmit();
          }}
        >
          <Icon name="checkmark" /> Add Category
        </Button>
      </Modal.Actions>
    </Modal>
  );
};
