import React from 'react';
import {
	Modal,
	Header,
	Image,
	Icon,
	Segment,
	Card,
	Button,
	Dropdown,
	Table,
	Menu,
	Pagination
} from 'semantic-ui-react';

import { Fab, Action } from 'react-tiny-fab';

import { AddAccessoryModal } from './modals';

import { mainButtonStyles, actionButtonStyles } from '../../../const';

page_size = 10;

export default class MedAccessoriesMain extends React.Component {
	constructor(props) {
		super(props);

		this.state = {
			list: [],
			activePage: 1,
			boundaryRange: 1,
			siblingRange: 3,
			showEllipsis: true,
			showFirstAndLastNav: true,
			showPreviousAndNextNav: true,
			totalPages: 1,
			searchType: undefined,
			searchQuery: ''
		};

		this.fetchData();
		this.fetchTotalAccCount();
	}

	fetchData() {
		const { activePage: page_no, searchType: type, searchQuery } = this.state;
		Meteor.call(
			'fetchMedAccessories',
			{ page_no, type, searchQuery },
			(err, res) => {
				// console.log(err, res);
				if (err) {
					console.log('Failed to fetch Medical Accessories list');
				} else if (res) {
					this.setState({ list: res });
				}
			}
		);
	}

	fetchTotalAccCount() {
		const { searchType: type, searchQuery } = this.state;
		Meteor.call(
			'fetchTotalAccCount',
			{ src: 'web', searchQuery, type },
			(err, res) => {
				// console.log(err, res);
				if (err)
					alert('Failed to fetch medicine count, please try again later');
				else if (res) this.setState({ totalPages: Math.ceil(res / page_size) });
			}
		);
	}

	updateState(obj) {
		this.setState(obj);
	}

	handlePaginationChange = (e, { activePage }) => {
		this.setState({ activePage }, () => this.fetchData());
	};

	handleSubmit() {
		// console.log(this.state);
		const { name, type, mfg, unit, price, available_quantity } = this.state;

		const data = {
			name,
			type,
			mfg,
			unit,
			price,
			available_quantity
		};

		Meteor.call('addMedAccessories', data, (err, res) => {
			if (err) {
				alert(
					'Sorry! Failed to add medicine at this moment. Please try again after sometime'
				);
				this.setState({ medAccessoryModalVisibility: false });
			} else if (res) {
				const { name, type, mfg, unit, price, available_quantity } = {};
				const data = {
					name,
					type,
					mfg,
					unit,
					price,
					available_quantity
				};
				this.setState({ ...data, medAccessoryModalVisibility: false });
				this.fetchData();
			}
		});
	}

	render() {
		const {
			list,
			activePage,
			boundaryRange,
			siblingRange,
			totalPages,
			showEllipsis,
			showFirstAndLastNav,
			showPreviousAndNextNav,
			searchType,
			searchQuery
		} = this.state;

		const { categories } = this.props;
		const categoryOptions = categories.map((item, sl_no) => {
			return { key: sl_no, text: item.name, value: item.name };
		});

		return (
			<Segment basic>
				<AddAccessoryModal
					types={this.props.categories}
					visibility={this.state.medAccessoryModalVisibility}
					visibilityname='medAccessoryModalVisibility'
					updateState={this.updateState.bind(this)}
					handleSubmit={this.handleSubmit.bind(this)}
				/>
				<Header as='h3'>Medical Accessories List</Header>
				<div className='infoTopBar'>
					<div
						className='ui transparent left icon input patientSrc left floated'
						onChange={v => {
							const x = v.target.value;

							this.setState({ searchQuery: x }, () => {
								if (x.length > 2) this.setState({ searchQuery: x });
							});
						}}
					>
						<input
							type='text'
							placeholder='Search Medical Accessories'
							value={searchQuery}
						/>
						<i className='search icon' />
					</div>
					<div className='filterContainer'>
						<ul>
							<li>
								<Dropdown
									selection={true}
									options={categoryOptions}
									placeholder='Select Type'
									value={searchType ? searchType : null}
									onChange={(e, data) =>
										this.setState({ searchType: data.value })
									}
								/>
							</li>
							<li style={{ marginLeft: '15px' }}>
								<button
									className='ui basic small button'
									style={{ margin: '0' }}
									onClick={() =>
										this.setState(
											{
												searchQuery: '',
												searchType: undefined
											},
											() => {
												this.fetchTotalAccCount();
												this.fetchData();
											}
										)
									}
								>
									Clear Filter
								</button>
							</li>
							<li style={{ marginLeft: '15px' }}>
								<button
									className='ui teal small button'
									style={{ margin: '0' }}
									onClick={() => {
										this.fetchTotalAccCount();
										this.fetchData();
									}}
								>
									Apply Filter
								</button>
							</li>
						</ul>
					</div>
				</div>

				<Table celled selectable>
					<Table.Header>
						<Table.Row>
							<Table.HeaderCell>Sl. No.</Table.HeaderCell>
							<Table.HeaderCell>Name</Table.HeaderCell>
							<Table.HeaderCell>Type</Table.HeaderCell>
							<Table.HeaderCell>Manufacturer</Table.HeaderCell>
							<Table.HeaderCell>Unit</Table.HeaderCell>
							<Table.HeaderCell>Price</Table.HeaderCell>
							{/* <Table.HeaderCell>Available Quantity</Table.HeaderCell> */}
						</Table.Row>
					</Table.Header>

					<Table.Body>
						{list &&
							!!list.length &&
							list.map((item, sl_no) => {
								return (
									<Table.Row>
										<Table.Cell>{sl_no + 1}</Table.Cell>
										<Table.Cell>{item.name}</Table.Cell>
										<Table.Cell>{item.type}</Table.Cell>
										<Table.Cell>{item.mfg}</Table.Cell>
										<Table.Cell>{item.unit}</Table.Cell>
										<Table.Cell>{item.price}</Table.Cell>
										{/* <Table.Cell>{item.available_quantity}</Table.Cell> */}
									</Table.Row>
								);
							})}
					</Table.Body>

					<Table.Footer>
						<Table.Row>
							<Table.HeaderCell colSpan='9'>
								<Menu floated='right' pagination>
									<Pagination
										floated='right'
										activePage={activePage}
										boundaryRange={boundaryRange}
										onPageChange={this.handlePaginationChange}
										size='small'
										siblingRange={siblingRange}
										totalPages={totalPages}
										// Heads up! All items are powered by shorthands, if you want to hide one of them, just pass `null` as value
										ellipsisItem={showEllipsis ? undefined : null}
										firstItem={showFirstAndLastNav ? undefined : null}
										lastItem={showFirstAndLastNav ? undefined : null}
										prevItem={showPreviousAndNextNav ? undefined : null}
										nextItem={showPreviousAndNextNav ? undefined : null}
									/>
								</Menu>
							</Table.HeaderCell>
						</Table.Row>
					</Table.Footer>
				</Table>

				<div
					onClick={() => this.setState({ medAccessoryModalVisibility: true })}
				>
					<Fab
						mainButtonStyles={mainButtonStyles}
						icon={<Icon name='plus' />}
					/>
				</div>
			</Segment>
		);
	}
}
