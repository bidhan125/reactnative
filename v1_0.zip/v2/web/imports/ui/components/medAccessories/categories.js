import React from 'react';
import { withTracker } from 'meteor/react-meteor-data';
import { Icon, Menu, Table, Header } from 'semantic-ui-react';
import { Fab, Action } from 'react-tiny-fab';
import { mainButtonStyles, actionButtonStyles } from '../../../const';

import { AddCategoryModal } from './modals';

export default class CategoriesList extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      visibilityCategoryModal: false,
      name: undefined,
      note: undefined,
    };
  }

  updateState(obj) {
    this.setState(obj);
  }

  handleSubmit() {
    const { name, note } = this.state;

    const data = {
      name,
      note,
      type: 'medical_accessory',
    };

    Meteor.call('addMedAccessoriesCategory', data, (err, res) => {
      console.log(err, res);
      if (err) alert('Sorry! Failled to add Category. Please try again later');
      else if (res) {
        this.props.fetchData();
        this.setState({ visibilityCategoryModal: false });
      }
    });
  }

  render() {
    console.log(this.props);
    const { list } = this.props;
    const { visibilityCategoryModal } = this.state;

    return (
      <React.Fragment>
        {visibilityCategoryModal && (
          <AddCategoryModal
            visibility={visibilityCategoryModal}
            visibilityname="visibilityCategoryModal"
            updateState={this.updateState.bind(this)}
            handleSubmit={this.handleSubmit.bind(this)}
          />
        )}
        <Table celled selectable>
          <Table.Header>
            <Table.Row>
              <Table.HeaderCell>Sl. No.</Table.HeaderCell>
              <Table.HeaderCell>Category Name</Table.HeaderCell>
              <Table.HeaderCell> Note </Table.HeaderCell>
              <Table.HeaderCell> Creadtion Date </Table.HeaderCell>
            </Table.Row>
          </Table.Header>
          <Table.Body>
            {list &&
              list.length &&
              list.map((item, sl_no) => {
                return (
                  <Table.Row>
                    <Table.Cell>{sl_no + 1}</Table.Cell>
                    <Table.Cell>{item.name}</Table.Cell>
                    <Table.Cell>{item.note}</Table.Cell>
                    <Table.Cell>
                      {item.createdAt && item.createdAt.toLocaleDateString()}
                    </Table.Cell>
                  </Table.Row>
                );
              })}
          </Table.Body>
        </Table>
        <div onClick={() => this.setState({ visibilityCategoryModal: true })}>
          <Fab
            mainButtonStyles={mainButtonStyles}
            icon={<Icon name="plus" />}
          />
        </div>
      </React.Fragment>
    );
  }
}
