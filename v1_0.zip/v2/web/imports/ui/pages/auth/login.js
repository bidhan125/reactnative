import React from 'react';
import {
  Button,
  Checkbox,
  Form,
  Input,
  Radio,
  Image,
  Grid,
  Header,
} from 'semantic-ui-react';

import { FlowRouter } from 'meteor/kadira:flow-router';

class Login extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      username: '',
      password: '',
    };
  }

  handleSubmit() {
    const { username, password } = this.state;

    Meteor.loginWithPassword(username, password, (error, success) => {
      if (error) {
        console.log('error', error);
        alert(error.message);
      } else {
        FlowRouter.go('/home');
      }
    });
  }

  render() {
    return (
      <div className="login">
        <Grid columns={3}>
          <Grid.Row>
            <Grid.Column />
            <Grid.Column>
              <div className="login-page">
                <Image centered src="logo.png" size="small" />
                <Form>
                  <Form.Group unstackable widths="equal">
                    <Form.Input
                      label="Phone"
                      placeholder="Phone Number"
                      onChange={v =>
                        this.setState({ username: v.target.value })
                      }
                    />
                    {/* <Form.Input label='ID' placeholder='ID' /> */}
                  </Form.Group>

                  <Form.Group widths="equal">
                    <Form.Input
                      label="Password"
                      placeholder="Password"
                      type="password"
                      onChange={v =>
                        this.setState({ password: v.target.value })
                      }
                    />
                  </Form.Group>
                  <Form.Group className="forgetPass">
                    <Checkbox label="Remember Me" />
                    <a
                      href="/forgot-password"
                      style={{ color: '#000', marginLeft: 60 }}
                    >
                      FORGOT PASSWORD
                    </a>
                  </Form.Group>
                  <Form.Field>
                    <Button primary fluid onClick={() => this.handleSubmit()}>
                      <a href="/" style={{ color: '#fff' }}>
                        Login
                      </a>
                    </Button>
                  </Form.Field>

                  <a href="/register" style={{ color: '#000' }}>
                    Or Register Now!
                  </a>
                </Form>
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    );
  }
}

export default Login;
