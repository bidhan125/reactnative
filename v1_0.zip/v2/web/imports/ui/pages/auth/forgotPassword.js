import React from 'react';
import {
  Button,
  Checkbox,
  Form,
  Input,
  Radio,
  Menu,
  Grid,
  Image,
} from 'semantic-ui-react';
class ForgotPassword extends React.Component {
  state = { checked: false };
  checkVerificationCode = () => {
    this.setState({ checked: !this.state.checked });
  };
  render() {
    return (
      <div className="login">
        <Grid columns={3}>
          <Grid.Row>
            <Grid.Column />
            <Grid.Column>
              <div className="login-page">
                <Image centered src="logo.png" size="small" />
                <Form>
                  <Form.Group unstackable widths="equal">
                    <Form.Input
                      label="Phone Number"
                      placeholder="Enter Phone Number"
                    />
                    {/* <Form.Input label='ID' placeholder='ID' /> */}
                  </Form.Group>
                  {this.state.checked && (
                    <Form.Group widths="equal">
                      <Form.Input
                        label="Verification Code"
                        placeholder="Enter Verification Code"
                      />
                    </Form.Group>
                  )}
                  <Form.Group>
                    <Checkbox
                      onChange={this.checkVerificationCode}
                      label="Already have a verification code"
                    />
                  </Form.Group>
                  <Form.Field>
                    <Button primary fluid>
                      <a href="/reset-password" style={{ color: '#fff' }}>
                        Submmit Verification Code
                      </a>
                    </Button>
                  </Form.Field>

                  <a href="/login" style={{ color: '#000' }}>
                    Or Login
                  </a>
                </Form>
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    );
  }
}

export default ForgotPassword;
