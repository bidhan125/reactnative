import React from 'react';
import {
  Button,
  Checkbox,
  Form,
  Input,
  Radio,
  Menu,
  Grid,
  Image,
} from 'semantic-ui-react';
class ResetPassword extends React.Component {
  state = {
    verify: false,
  };
  verifyAccount = () => {
    this.setState({ verify: true });
  };
  render() {
    if (!this.state.verify) {
      return (
        <div className="login">
          <Grid columns={3}>
            <Grid.Row>
              <Grid.Column />
              <Grid.Column>
                <div className="login-page">
                  <Image centered src="logo.png" size="tiny" />
                  <Form>
                    <Form.Group widths="equal">
                      <Form.Input placeholder="Phone" type="text" />
                    </Form.Group>
                    <Form.Group widths="equal">
                      <Form.Input placeholder="OTP" type="password" />
                    </Form.Group>
                    <Form.Field>
                      <Button onClick={this.verifyAccount} primary fluid>
                        Verify Account
                      </Button>
                    </Form.Field>
                    <div style={{ textAlign: 'center' }}>Or</div>
                    <br />
                    <Form.Field>
                      <Button primary fluid>
                        Resend OTP
                      </Button>
                    </Form.Field>
                  </Form>
                </div>
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </div>
      );
    }
    return (
      <div className="login">
        <Grid columns={3}>
          <Grid.Row>
            <Grid.Column />
            <Grid.Column>
              <div className="login-page">
                <Image centered src="logo.png" size="small" />
                <Form>
                  <Form.Group widths="equal">
                    <Form.Input placeholder="Password" type="password" />
                  </Form.Group>
                  <Form.Group widths="equal">
                    <Form.Input
                      placeholder="Confirm Password"
                      type="password"
                    />
                  </Form.Group>
                  <Form.Field>
                    <Button primary fluid>
                      <a href="/login" style={{ color: '#fff' }}>
                        Reset Password
                      </a>
                    </Button>
                  </Form.Field>
                </Form>
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    );
  }
}

export default ResetPassword;
