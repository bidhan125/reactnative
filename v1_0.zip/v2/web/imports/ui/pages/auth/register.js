import React from 'react';
import { Meteor } from 'meteor/meteor';
import { FlowRouter } from 'meteor/kadira:flow-router';
import {
  Button,
  Checkbox,
  Form,
  Input,
  Radio,
  Select,
  Icon,
  Grid,
  Image,
  Dropdown,
} from 'semantic-ui-react';

const options = [
  {
    key: 'user',
    text: (
      <span>
        Please select your <strong>gender</strong>
      </span>
    ),
    disabled: true,
  },
  { key: 'female', text: 'Female' },
  { key: 'male', text: 'Male' },
];

const trigger = (
  <span>
    <Icon name="user" /> Hello, Bob
  </span>
);

class Registration extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      name: '',
      email: '',
      address: '',
      gender: undefined,
      phone: '',
      password: '',
      password1: '',
      aggreed: false,
    };
  }

  handleSubmit() {
    console.log(this.state);
    if (!this.state.aggreed) {
      alert('Please accept the terms and conditions.');
      return;
    }
    const {
      name,
      phone,
      email,
      address,
      gender,
      password,
      password1,
    } = this.state;

    if (password != password1) {
      alert("Passwords don't match");
      return;
    } else
      Meteor.call(
        'create.admin',
        {
          name,
          email,
          phone,
          address,
          gender,
          password,
        },
        (err, res) => {
          console.log(err, res);
          if (err) {
            alert(err.message);
          } else if (res) {
            FlowRouter.go('/home');
          }
        },
      );
  }

  render() {
    return (
      <div className="login">
        <Grid columns={3}>
          <Grid.Row>
            <Grid.Column />
            <Grid.Column>
              <div className="registration-page">
                <Image centered src="logo.png" size="small" />
                <br />
                <Form>
                  <Form.Group unstackable widths="equal">
                    <Form.Input
                      placeholder="Name"
                      onChange={v => this.setState({ name: v.target.value })}
                    />
                    {/* <Form.Input label='ID' placeholder='ID' /> */}
                  </Form.Group>
                  <Form.Group unstackable widths="equal">
                    <Form.Input
                      placeholder="Email(joe@schmoe.com)"
                      onChange={v => this.setState({ email: v.target.value })}
                    />
                    {/* <Form.Input label='ID' placeholder='ID' /> */}
                  </Form.Group>
                  <Form.Group widths="equal">
                    <Form.Input
                      placeholder="Address"
                      onChange={v => this.setState({ address: v.target.value })}
                    />
                  </Form.Group>
                  <Form.Group widths="equal">
                    <Dropdown trigger={trigger} options={options} />
                  </Form.Group>
                  <Form.Group widths="equal">
                    <Form.Input
                      placeholder="Phone Number"
                      onChange={v => this.setState({ phone: v.target.value })}
                    />
                  </Form.Group>
                  <Form.Group widths="equal">
                    <Form.Input
                      placeholder="Password"
                      type="password"
                      onChange={v =>
                        this.setState({ password: v.target.value })
                      }
                    />
                  </Form.Group>
                  <Form.Group widths="equal">
                    <Form.Input
                      placeholder="Confirm Password"
                      type="password"
                      onChange={v =>
                        this.setState({ password1: v.target.value })
                      }
                    />
                  </Form.Group>
                  <Form.Field
                    control={Checkbox}
                    checked={this.state.aggreed}
                    onClick={() =>
                      this.setState({ aggreed: !this.state.aggreed })
                    }
                    label="I agree to the Terms and Conditions"
                  />

                  <Form.Field>
                    <Button primary fluid onClick={() => this.handleSubmit()}>
                      Create New Account
                    </Button>
                  </Form.Field>
                  <a href="/login">Or Login!</a>
                </Form>
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    );
  }
}

export default Registration;
