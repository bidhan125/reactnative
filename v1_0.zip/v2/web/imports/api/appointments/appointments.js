import { Meteor } from 'meteor/meteor';
import { Mongo } from 'meteor/mongo';
import SimpleSchema from 'simpl-schema';

class CollectionSchema extends Mongo.Collection {
  insert(doc, callback) {
    doc.createdAt = new Date();
    doc.createdBy = Meteor.userId();
    doc.status = 'pending';
    return super.insert(doc, callback);
  }

  update(doc, callback) {
    return super.update(doc, callback);
  }

  remove(doc, callback) {
    return super.remove(doc, callback);
  }
}

export const Appointments = new CollectionSchema('Appointments');

const schema = {};
schema.patientSchema = new SimpleSchema({
  id: { type: String },
  name: { type: String },
  address: { type: String },
  phone: { type: String },
  gender: { type: String },
  age: { type: Number },
});
schema.doctorSchema = new SimpleSchema({
  id: { type: String },
  name: { type: String },
});
schema.branchSchema = new SimpleSchema({
  id: { type: String },
  name: { type: String },
});

Appointments.schema = new SimpleSchema({
  createdAt: { type: Date },
  createdBy: { type: Date },

  time: { type: Date },
  isBeneficiary: { type: Boolean },
  branch: { type: schema.branchSchema },

  patient: {
    type: schema.patientSchema,
  },
  doctor: {
    type: schema.doctorSchema,
  },
  status: { type: String },

  note: { type: String },
});
