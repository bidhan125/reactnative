import { Meteor } from 'meteor/meteor';
import { Appointments } from '../appointments';

Meteor.publish('fetch.my.appointments', (page_no = 1) => {
  const page_size = 10;
  const skip = (page_no - 1) * page_size;
  return Appointments.find(
    {
      createdBy: Meteor.userId(),
      isBeneficiary: false,
    },
    { sort: { createdAt: -1 }, skip, limit: page_size },
  );
});
Meteor.publish('fetch.b.appointments', (page_no = 1) => {
  const page_size = 10;
  const skip = (page_no - 1) * page_size;
  return Appointments.find(
    { createdBy: Meteor.userId(), isBeneficiary: true },
    { sort: { createdAt: -1 }, skip, limit: page_size },
  );
});
Meteor.publish('fetch.all.appointments', (page_no = 1) => {
  const page_size = 10;
  const skip = (page_no - 1) * page_size;
  return Appointments.find(
    {},
    { sort: { createdAt: -1 }, skip, limit: page_size },
  );
});
