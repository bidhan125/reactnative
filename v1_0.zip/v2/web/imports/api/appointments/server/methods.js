import { Meteor } from 'meteor/meteor';
import { Appointments } from '../appointments';
import { sendSMS } from '../../utils/server/methods';

Meteor.methods({
	'add.appointment': data => {
		return Appointments.insert(data);
	},

	updateAppointment({ id, status, time }) {
		const ap = Appointments.findOne(id);
		const phone = ap.patient.phone;
		sendSMS(
			'Dear LifePlus user, your appointment for ' +
				ap.doctor.name +
				' is ' +
				status +
				'. Thank you for using LifePlus!',
			phone
		);
		return Appointments.update(id, { $set: { status, time } });
	},

	fetchTotalAppointmentCount() {
		return Appointments.find().count();
	},
	fetchMyAppointmentCount() {
		return Appointments.find({
			createdBy: Meteor.userId(),
			isBeneficiary: false
		}).count();
	},
	fetchBAppointmentCount() {
		return Appointments.find({
			createdBy: Meteor.userId(),
			isBeneficiary: true
		}).count();
	},

	fetchAppointment({ uid, isBeneficiary, page_no = 1 }) {
		const page_size = 10;
		const skip = (page_no - 1) * page_size;

		return Appointments.find(
			{ createdBy: uid, isBeneficiary },
			{ sort: { createdAt: -1 }, skip, limit: page_size }
		).fetch();
	}
});
