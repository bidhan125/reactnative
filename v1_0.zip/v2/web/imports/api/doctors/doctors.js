import { Meteor } from 'meteor/meteor';
import { Mongo } from 'meteor/mongo';
import SimpleSchema from 'simpl-schema';

class CollectionSchema extends Mongo.Collection {
  insert(doc, callback) {
    doc.createdAt = new Date();
    doc.createdBy = this.userId;
    return super.insert(doc, callback);
  }

  update(doc, callback) {
    return super.update(doc, callback);
  }

  remove(doc, callback) {
    return super.remove(doc, callback);
  }
}

export const Doctors = new CollectionSchema('Doctors');

Doctors.schema = new SimpleSchema({
  bmdcNo: { type: String },
  name: { type: String },
  phone: { type: String },
  gender: { type: String },
  avatar: { type: String, optional: true },
  availablity: { type: Boolean, optional: true },

  titles: { type: Array, optional: true },
  'titles.$': { type: String, optional: true },
  degrees: { type: Array, optional: true },
  'degrees.$': { type: String, optional: true },
  researches: { type: Array, optional: true },
  'researches.$': { type: String, optional: true },
  affiliations: { type: Array, optional: true },
  'affiliations.$': { type: String, optional: true },
  recognitions: { type: Array, optional: true },
  'recognitions.$': { type: String, optional: true },

  website: { type: String, optional: true },
  fees: { type: Number, optional: true },
  discount: { type: Number, optional: true },
  workingHours: { type: Array, optional: true },
  'workingHours.$': { type: Array, optional: true },
  'workingHours.$.$': { type: Number, optional: true },
  offDays: { type: Array, optional: true },
  'offDays.$': { type: Boolean, optional: true },
  Note: { type: String, optional: true },
});
