import { Meteor } from 'meteor/meteor';
import { Branches } from '../branches';
import { Specialities } from '../specialities';
import { Doctors } from '../doctors';

Meteor.publish('fetch.doctors', params => {
	// console.log(params);
	return Doctors.find(params, { sort: { createdAt: -1 } });
});

Meteor.publish('fetch.specialities', () => {
	return Specialities.find();
});

Meteor.publish('fetch.branches', () => {
	return Branches.find();
});
