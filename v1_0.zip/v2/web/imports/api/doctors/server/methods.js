import { Meteor } from 'meteor/meteor';
import { Branches } from '../branches';
import { Specialities } from '../specialities';
import { Doctors } from '../doctors';

Meteor.methods({
	'add.branch': data => {
		return Branches.insert(data);
	},
	'add.speciality': data => {
		return Specialities.insert(data);
	},
	'add.doctor': data => {
		return Doctors.insert(data);
	},

	fetchBranchNSpecialities() {
		const branchList = Branches.find().fetch();
		const specialitiesList = Specialities.find().fetch();

		return {
			branchList,
			specialitiesList
		};
	},

	fetchBranches() {
		return Branches.find().fetch();
	},

	fethcDoctorsList(branch, speciality) {
		return Doctors.find({ branch, speciality, availability: true }).fetch();
	}
});
