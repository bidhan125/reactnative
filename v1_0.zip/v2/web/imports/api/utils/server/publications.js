import { Meteor } from 'meteor/meteor';
import { Categories, Requirements, Feedback } from '../utilSchemas';

// Meteor.publish('fetch.diagnosticTests', () => {
//   return DiagnosticTests.find();
// });

Meteor.publish('fetchFeedbacks', (page_no = 1) => {
  const page_size = 5;
  const skip = (page_no - 1) * page_size;
  return Feedback.find({}, { sort: { createdAt: -1 }, skip, limit: page_size });
});
