import { Meteor } from 'meteor/meteor';
import { HTTP } from 'meteor/http';
import { Categories, Requirements, Feedback } from '../utilSchemas';
import { Appointments } from '../../appointments/appointments';
import { Doctors } from '../../doctors/doctors';
import { Branches } from '../../doctors/branches';
import { Orders } from '../../orders/orders';
import { Medicines } from '../../medicines/medicines';
import { AmbulanceFare } from '../utilSchemas';

Meteor.methods({
	addCategory: data => {
		return Categories.insert(data);
	},
	addRequirement: data => {
		return Requirements.insert(data);
	},
	fetchCategories(type) {
		return Categories.find({ type }).fetch();
	},
	fetchRequirements() {
		return Requirements.find().fetch();
	},
	addMedAccessoriesCategory(data) {
		return Categories.insert(data);
	},

	addFeedback(data) {
		data['status'] = 'Unread';
		return Feedback.insert(data);
	},

	fetchFeedback(page_no = 1) {
		const page_size = 10;
		const skip = (page_no - 1) * page_size;
		return Feedback.find(
			{},
			{ sort: { createdAt: -1 }, skip, limit: page_size }
		).fetch();
	},

	fetchFeedbackCount() {
		return Feedback.find().count();
	},

	updateFeedbackStatus(_id, status) {
		return Feedback.update({ _id }, { $set: { status } });
	},

	async fetchDashboardData() {
		const pipeline = [
			{
				$group: {
					_id: {
						$add: [
							{ $dayOfYear: '$createdAt' },
							{ $multiply: [367, { $year: '$createdAt' }] }
						]
					},
					count: { $sum: 1 },
					first_occurred: { $min: '$createdAt' }
				}
			},
			{ $sort: { _id: -1 } },
			{ $limit: 7 },
			{ $project: { date: '$first_occurred', count: 1, _id: 0 } }
		];

		const appointments = await Appointments.rawCollection()
			.aggregate(pipeline)
			.toArray();
		const medicines = await Orders.rawCollection()
			.aggregate(pipeline)
			.toArray();

		const total_doctors = Doctors.find().count();
		const total_users = Meteor.users.find().count();
		const total_branches = Branches.find().count();
		const total_appointments = Appointments.find().count();
		const total_orders = Orders.find().count();
		const total_medicines = Medicines.find().count();

		// console.log(total_branches, total_doctors, total_users, total_appointments);
		return {
			total_branches,
			total_doctors,
			total_users,
			total_appointments,
			total_orders,
			total_medicines,
			appointments,
			medicines
		};
	},

	fetchAmbulanceFare() {
		return {
			regular: AmbulanceFare.findOne({ type: 'regular' }),
			icu: AmbulanceFare.findOne({ type: 'icu' })
		};
	},

	updateAmbulanceFare(data) {
		return (
			AmbulanceFare.update({ type: data.type }, { $set: { ...data } }) &&
			'Successfully updated ambulance fare'
		);
	}
});

export function sendSMS(message, number) {
	// let auth = 'Basic ' + Buffer('durbinlabs:Durbin@1').toString('base64');

	const SMS_CREDENTIALS = {
		URL: 'http://api.infobip.com/sms/1/text/single',
		USERNAME: 'durbinlabs',
		PASSWORD: 'Durbin@1'
	};

	let dataJ = {
		headers: {
			'content-type': 'application/json',
			accept: 'application/json'
			// Authorization: auth,
		},
		auth: SMS_CREDENTIALS.USERNAME + ':' + SMS_CREDENTIALS.PASSWORD,
		data: {
			from: '8804445677778', // don't put +880 only 880 works
			to: number.charAt(0) == '+' ? number : '+88' + number,
			text: message
		}
	};
	HTTP.call('POST', SMS_CREDENTIALS.URL, dataJ, (error, result) => {});
}
