import { Mongo } from 'meteor/mongo';
import SimpleSchema from 'simpl-schema';

class CollectionSchema extends Mongo.Collection {
  insert(doc, callback) {
    doc.createdAt = new Date();
    doc.createdBy = this.userId;
    return super.insert(doc, callback);
  }

  update(doc, callback) {
    return super.update(doc, callback);
  }

  remove(doc, callback) {
    return super.remove(doc, callback);
  }
}

export const Categories = new CollectionSchema('Categories');
export const Requirements = new CollectionSchema('Requirements');
export const Feedback = new CollectionSchema('Feedback');
export const AmbulanceFare = new CollectionSchema('AmbulanceFare');
export const SoftDeleted = new CollectionSchema('SoftDeleted');
