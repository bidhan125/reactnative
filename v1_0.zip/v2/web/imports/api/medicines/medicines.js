import { Mongo } from 'meteor/mongo';
import SimpleSchema from 'simpl-schema';

class CollectionSchema extends Mongo.Collection {
  insert(doc, callback) {
    doc.createdAt = new Date();
    doc.createdBy = this.userId;
    return super.insert(doc, callback);
  }

  update(doc, callback) {
    return super.update(doc, callback);
  }

  remove(doc, callback) {
    return super.remove(doc, callback);
  }
}

export const Medicines = new CollectionSchema('Medicines');
export const DrugGenerics = new CollectionSchema('DrugGenerics');
export const DrugCompanies = new CollectionSchema('DrugCompanies');

const schema = {};

schema.description = new SimpleSchema({
  blocks: { type: Array },
  'blocks.$': { type: String },
  entityMap: { type: Object },
});

Medicines.schema = new SimpleSchema({
  createdAt: { type: Date },
  createdBy: { type: Date },

  name: { type: String },
  generic_name: { type: String },
  type: { type: String },
  description: { type: schema.description },
  strength: { type: String },
  pharma: { type: String },
  unit: { type: String },
  price: { type: String },
  available_quantity: { type: String },

  note: { type: String },
});
