import { Meteor } from 'meteor/meteor';
import { Medicines } from '../medicines';

Meteor.publish('fetch.medicines', () => {
  return Medicines.find();
});
