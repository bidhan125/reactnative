import { Meteor } from 'meteor/meteor';
import { Medicines, DrugCompanies, DrugGenerics } from '../medicines';

const findC = (id, companies) => {
  const idx = companies.map(e => e.company_id).indexOf(id);
  return companies[idx].company_name;
};

const findG = (id, generics) => {
  const idx = generics.map(e => e.generic_id).indexOf(id);
  // console.log(idx);
  if (idx == -1) return {};
  return generics[idx];
};

Meteor.methods({
  addMedicine: data => {
    return Medicines.insert(data);
  },

  fetchMedicines({ src, page_no = 1, form = undefined, searchQuery = '' }) {
    const page_size = 10;
    const skip = (page_no - 1) * page_size;
    searchQuery = searchQuery.replace(/\s\s+/g, ' ');
    searchQuery = searchQuery.replace(new RegExp(' ', 'g'), '.*');

    // TODO :: replace with Aggregation
    const storePresence = src == 'web' ? {} : { storePresence: true };
    const cursor = Medicines.find(
      {
        ...storePresence,
        form,
        brand_name: {
          $regex: searchQuery,
          $options: '-i',
        },
      },
      { sort: { brand_name: 1 }, skip, limit: page_size },
    );

    const medicines = cursor.fetch();

    const cIds = medicines.map(m => m.company_id);
    const gIds = medicines.map(m => m.generic_id);

    const companies = DrugCompanies.find({ company_id: { $in: cIds } }).fetch();
    const generics = DrugGenerics.find({ generic_id: { $in: gIds } }).fetch();

    const ret = medicines.map(m => {
      const g = findG(m.generic_id, generics);
      const { generic_name, administration, indication, interaction } = g;
      return {
        ...m,
        generic_name,
        administration,
        indication,
        interaction,
        pharma: findC(m.company_id, companies),
      };
    });
    // console.log(ret);
    return ret;
  },

  fetchTotalMedicineCount({ src, form = undefined, searchQuery = '' }) {
    searchQuery = searchQuery.replace(/\s\s+/g, ' ');
    searchQuery = searchQuery.replace(new RegExp(' ', 'g'), '.*');

    // TODO :: replace with Aggregation
    const storePresence = src == 'web' ? {} : { storePresence: true };
    return Medicines.find({
      ...storePresence,
      form,
      brand_name: {
        $regex: searchQuery,
        $options: '-i',
      },
    }).count();
  },

  toggleStorePresence(_id, val) {
    return Medicines.update(_id, { $set: { storePresence: val } });
  },
});
