import { Meteor } from 'meteor/meteor';
import { Mongo } from 'meteor/mongo';
import SimpleSchema from 'simpl-schema';

class CollectionSchema extends Mongo.Collection {
  insert(doc, callback) {
    doc.createdAt = new Date();
    return super.insert(doc, callback);
  }

  update(doc, callback) {
    return super.update(doc, callback);
  }

  remove(doc, callback) {
    return super.remove(doc, callback);
  }
}

export const SecurityCodes = new CollectionSchema('SecurityCodes');

SecurityCodes.schema = new SimpleSchema({
  code: { type: String },
  uid: { type: String },
  type: { type: String },
});
