import { Meteor } from 'meteor/meteor';
import { Mongo } from 'meteor/mongo';
import SimpleSchema from 'simpl-schema';

class CollectionSchema extends Mongo.Collection {
  insert(doc, callback) {
    doc.createdAt = new Date();
    doc.createdBy = this.userId;
    return super.insert(doc, callback);
  }

  update(doc, callback) {
    return super.update(doc, callback);
  }

  remove(doc, callback) {
    return super.remove(doc, callback);
  }
}

export const Beneficiary = new CollectionSchema('Beneficiary');

Beneficiary.schema = new SimpleSchema({
  name: { type: String },
  uid: { type: String },
  phone: { type: String, optional: true },
  address: { type: String, optional: true },
  gender: { type: String },
  avatar: { type: String, optional: true },
  relation: { type: String, optional: true },
  height: { type: String },
  weight: { type: String },
  blood_group: { type: String },
  dob: { type: Date },
});
