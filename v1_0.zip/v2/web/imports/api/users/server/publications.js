import { Meteor } from 'meteor/meteor';

Meteor.publish('fetchUsers', data => {
  const page_size = 10;
  const { activePage = 1 } = data;
  const skip = (activePage - 1) * page_size;

  if (data.searchQuery) {
    let search = data.searchQuery;
    search = search.replace(/\s\s+/g, ' ');
    search = search.replace(new RegExp(' ', 'g'), '.*');
    return Meteor.users.find(
      {
        'profile.type': data.type,
        $or: [
          {
            'profile.name': {
              $regex: search,
              $options: '-i'
            }
          },
          {
            'profile.email': {
              $regex: search,
              $options: '-i'
            }
          },
          {
            username: {
              $regex: search,
              $options: '-i'
            }
          }
        ]
      },
      { sort: { createdAt: -1 }, skip, limit: page_size }
    );
  } else
    return Meteor.users.find(
      {
        'profile.type': data.type
      },
      { sort: { createdAt: -1 }, skip, limit: page_size }
    );
});
