import { Meteor } from 'meteor/meteor';
import { Accounts } from 'meteor/accounts-base';
import { Beneficiary } from '../beneficiary';
import { Doctors } from '../../doctors/doctors';
import { SecurityCodes } from '../securityCode';

import { sendSMS } from '../../utils/server/methods';

Meteor.methods({
	'create.admin': function(data) {
		var userObject = {
			username: data.phone,
			password: data.password,
			profile: {
				name: data.name,
				phone: data.phone,
				email: data.email,
				gender: data.gender,
				employeeId: data.employeeId,
				type: 'admin',
				roles: ['']
			}
		};

		return Accounts.createUser(userObject);
	},
	'create.appUser': function(data) {
		console.log(data);
		var userObject = {
			username: data.phone,
			password: data.password,
			profile: {
				name: data.name,
				phone: data.phone,
				email: data.email,
				address: data.address,
				gender: data.gender,
				type: 'app',
				dob: data.dob,
				roles: ['']
			}
		};

		return Accounts.createUser(userObject);
	},

	fetchAppUserCount({ type, searchQuery }) {
		if (searchQuery) {
			searchQuery = searchQuery.replace(/\s\s+/g, ' ');
			searchQuery = searchQuery.replace(new RegExp(' ', 'g'), '.*');
			return Meteor.users
				.find({
					'profile.type': type,
					$or: [
						{
							'profile.name': {
								$regex: searchQuery,
								$options: '-i'
							}
						},
						{
							'profile.email': {
								$regex: searchQuery,
								$options: '-i'
							}
						},
						{
							username: {
								$regex: searchQuery,
								$options: '-i'
							}
						}
					]
				})
				.count();
		}
		return Meteor.users.find({ 'profile.type': type }).count();
	},

	updateProfile(data) {
		const profile = { ...Meteor.user().profile, ...data };
		delete profile.id;
		return Meteor.users.update({ _id: data.id }, { $set: { profile } });
	},

	updateDoctor(data) {
		return Doctors.update(data._id, { ...data });
	},

	addBeneficiary(data) {
		data.uid = this.userId;
		return Beneficiary.insert(data);
	},

	fetchBeneficiary(uid) {
		return Beneficiary.find({ uid }).fetch();
	},

	updateBeneficiary(data) {
		if (!data.id)
			return Meteor.Error('Update Failed.', 'Beneficiary ID missing');

		return Beneficiary.update({ _id: data.id }, { $set: { ...data } });
	},

	removeBeneficiary(id) {
		return Beneficiary.remove({ _id: id });
	},

	forgotPasswordRequest(phone) {
		const user = Meteor.users.findOne({ username: phone });
		if (!user)
			throw new Meteor.Error(
				'Incorrect Phone Number, No user found with given phone number.'
			);

		const code = Math.random()
			.toString(21)
			.substr(2, 4);

		const message = 'Dear LifePlus user, your verification code is: ' + code;
		sendSMS(message, user.username);

		return SecurityCodes.insert({
			code,
			uid: user._id,
			type: 'forgotPasssword'
		});
	},

	forgotPasswordSubmit({ code, phone, password }) {
		const user = Meteor.users.findOne({ username: phone });

		if (!user)
			throw new Meteor.Error(
				'Incorrect Phone Number, No user found with given phone number.'
			);
		const securityCode = SecurityCodes.findOne({ code });
		// console.log(user, securityCode, code, phone);
		if (!securityCode) throw new Meteor.Error('Incorrect security code.');
		if (securityCode.uid != user._id)
			throw new Meteor.Error("Phone Number and Security Code don't match");

		return Accounts.setPassword(user._id, password);
	},

	sendAccountVerificationCode(phone) {
		const user = Meteor.users.findOne({ username: phone });
		if (!user)
			throw new Meteor.Error(
				'Sorry! Incorrect Phone Number, No user found with given phone number.'
			);

		const code = Math.random()
			.toString(21)
			.substr(2, 4);

		const message = 'Dear LifePlus user, your verification code is: ' + code;
		sendSMS(message, user.username);

		return (
			SecurityCodes.insert({
				code,
				uid: user._id,
				type: 'verifyAccount'
			}) &&
			'Account verification code successfully sent. Please check the verification code sent to the phone number.'
		);
	},

	verifyAccount({ phone, code }) {
		const user = Meteor.users.findOne({ username: phone });

		if (!user)
			throw new Meteor.Error(
				'Sorry! Incorrect Phone Number, No user found with given phone number.'
			);
		if (user.profile.isVerified) return 'User is already verified';

		const securityCode = SecurityCodes.findOne({ code });
		// console.log(user, securityCode, code, phone);
		if (!securityCode)
			throw new Meteor.Error('Sorry! Incorrect security code.');
		if (securityCode.isUsed)
			throw new Meteor.Error('Sorry! Security code already used.');
		if (securityCode.uid != user._id)
			throw new Meteor.Error(
				"Sorry! Phone Number and Security Code don't match"
			);

		return (
			SecurityCodes.update(
				{ _id: securityCode._id },
				{ $set: { isUsed: true } }
			) &&
			Meteor.users.update(
				{ _id: user._id },
				{ $set: { 'profile.isVerified': true } }
			) &&
			'Your account is successfully verified.'
		);
	}
});
