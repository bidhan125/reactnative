import { Mongo } from 'meteor/mongo';
import SimpleSchema from 'simpl-schema';

class CollectionSchema extends Mongo.Collection {
  insert(doc, callback) {
    doc.createdAt = new Date();
    doc.createdBy = this.userId;
    doc.status = 'Processing';
    return super.insert(doc, callback);
  }

  update(doc, callback) {
    return super.update(doc, callback);
  }

  remove(doc, callback) {
    return super.remove(doc, callback);
  }
}

export const Reports = new CollectionSchema('Reports');

Reports.schema = new SimpleSchema({
  createdAt: { type: Date },
  createdBy: { type: Date },

  name: { type: String },
  date: { type: Date },
  patientId: { type: String },
  reportId: { type: String },
  patient_name: { type: String },
  category: { type: String, optional: true },
  status: { type: String },
  description: { type: String }
});
