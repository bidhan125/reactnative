import { Meteor } from 'meteor/meteor';
import { Reports } from '../reports';

Meteor.methods({
	addReport: data => {
		return Reports.insert(data);
	},

	fetchReport({ patientId, page_no = 1 }) {
		const page_size = 10;
		const skip = (page_no - 1) * page_size;

		return Reports.find(
			{ patientId },
			{ sort: { name: 1 }, skip, limit: page_size }
		).fetch();
	},

	fetchReportbyOrderId(orderId) {
		return Reports.find({ orderId }).fetch();
	},

	fetchTotalReportCount() {
		return Reports.find().count();
	}
});
