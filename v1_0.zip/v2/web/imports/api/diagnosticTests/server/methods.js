import { Meteor } from 'meteor/meteor';
import { DiagnosticTests } from '../diagnosticTests';
import { SoftDeleted } from '../../utils/utilSchemas';

Meteor.methods({
	addDiagnosticTest: data => {
		return DiagnosticTests.insert(data);
	},

	updateDiagnosticTest(data) {
		return (
			DiagnosticTests.update({ _id: data._id }, { $set: data }) &&
			'Test updated successfylly'
		);
	},

	removeDiagnosticTest(id) {
		const data = DiagnosticTests.findOne(id);
		DiagnosticTests.remove(id);
		return SoftDeleted.insert(data) && 'Removed successfully!';
	},

	fetchDiagnosticCount({ searchQuery = '', type = 'single' }) {
		searchQuery = searchQuery.replace(/\s\s+/g, ' ');
		searchQuery = searchQuery.replace(new RegExp(' ', 'g'), '.*');

		console.log(searchQuery, type);

		return DiagnosticTests.find({
			name: {
				$regex: searchQuery,
				$options: '-i'
			},
			type
		}).count();
	},

	fetchDiagnosticTest({ searchQuery = '', type = 'single', page_no = 1 }) {
		const page_size = 10;
		const skip = (page_no - 1) * page_size;

		searchQuery = searchQuery.replace(/\s\s+/g, ' ');
		searchQuery = searchQuery.replace(new RegExp(' ', 'g'), '.*');

		return DiagnosticTests.find(
			{
				type,
				name: {
					$regex: searchQuery,
					$options: '-i'
				}
			},
			{ sort: { name: 1 }, skip, limit: page_size }
		).fetch();
	}
});
