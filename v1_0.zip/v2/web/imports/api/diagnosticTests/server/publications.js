import { Meteor } from 'meteor/meteor';
import { DiagnosticTests } from '../diagnosticTests';

Meteor.publish('fetch.diagnosticTests', (type, searchQuery = '') => {
  console.log(type, searchQuery)
  searchQuery = searchQuery.replace(/\s\s+/g, ' ');
  searchQuery = searchQuery.replace(new RegExp(' ', 'g'), '.*');
  return DiagnosticTests.find({ type, name: {
    $regex: searchQuery,
    $options: '-i',
  }, });
});
