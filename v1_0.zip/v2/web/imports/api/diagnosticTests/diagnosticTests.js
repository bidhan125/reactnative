import { Mongo } from 'meteor/mongo';
import SimpleSchema from 'simpl-schema';

class CollectionSchema extends Mongo.Collection {
  insert(doc, callback) {
    doc.createdAt = new Date();
    doc.createdBy = this.userId;
    return super.insert(doc, callback);
  }

  update(doc, callback) {
    return super.update(doc, callback);
  }

  remove(doc, callback) {
    return super.remove(doc, callback);
  }
}

export const DiagnosticTests = new CollectionSchema('DiagnosticTests');

const schema = {};

schema.branchSchema = new SimpleSchema({
  id: { type: String },
  name: { type: String },
});

DiagnosticTests.schema = new SimpleSchema({
  createdAt: { type: Date },
  createdBy: { type: Date },

  name: { type: String },
  branch: { type: schema.branchSchema },
  category: { type: String },
  description: { type: Array },
  'description.$': { type: String },
  prerequisites: { type: Array },
  'prerequisites.$': { type: String },

  note: { type: String },
});
