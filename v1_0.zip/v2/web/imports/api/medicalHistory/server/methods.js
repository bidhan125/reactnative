import { Meteor } from 'meteor/meteor';
import { MedicalHistory } from '../medicalHistory';

Meteor.methods({
	addMedicalHistory({ name, patientId, patientName, fileUrl }) {
		return MedicalHistory.insert({ name, patientId, patientName, fileUrl });
	},

	fetchMedicalHistories({ patientId, page_no = 1 }) {
		const page_size = 10;
		const skip = (page_no - 1) * page_size;

		return MedicalHistory.find(
			{ patientId },
			{ sort: { createdAt: -1 }, skip, limit: page_size }
		).fetch();
	},

	fetchTotalMedicalHistoryCount(patientId) {
		return MedicalHistory.find({ patientId }).count();
	}
});
