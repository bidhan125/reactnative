import { Mongo } from 'meteor/mongo';
import SimpleSchema from 'simpl-schema';

class CollectionSchema extends Mongo.Collection {
  insert(doc, callback) {
    doc.createdAt = new Date();
    doc.status = 'Pending';
    doc.createdBy = Meteor.userId();
    return super.insert(doc, callback);
  }

  update(doc, callback) {
    return super.update(doc, callback);
  }

  remove(doc, callback) {
    return super.remove(doc, callback);
  }
}

export const Orders = new CollectionSchema('Orders');

const schema = {};

schema.patientSchema = new SimpleSchema({
  id: { type: String },
  name: { type: String },
  address: { type: String },
  phone: { type: String },
  gender: { type: String },
  age: { type: Number },
});

schema.branchSchema = new SimpleSchema({
  id: { type: String },
  name: { type: String },
});

schema.testSchema = new SimpleSchema({
  id: { type: String },
  name: { type: String },
  price: { type: Number },
});

Orders.schema = new SimpleSchema({
  createdAt: { type: Date },
  createdBy: { type: Date },

  isBeneficiary: { type: Boolean },
  orderType: { type: String },
  status: { type: String },
  branch: { type: schema.branchSchema },
  tests: { type: Array },
  'tests.$': { type: schema.testSchema },
  address: { type: String },
  time: { type: Date },

  note: { type: String },
});
