import { Meteor } from 'meteor/meteor';
import { Orders } from '../orders';

Meteor.publish('fetch.orders', (orderType, page_no = 1) => {
  const page_size = 10;
  const skip = (page_no - 1) * page_size;
  return Orders.find(
    { orderType },
    { sort: { createdAt: -1 }, skip, limit: page_size },
  );
});
