import { Meteor } from 'meteor/meteor';
import { HTTP } from 'meteor/http';
var crypto = require('crypto');

import { Orders } from '../orders';
import { payment_gateway } from '../../../const';
import { sendSMS } from '../../utils/server/methods';

Meteor.methods({
	addOrder: data => {
		return Orders.insert(data);
	},

	// fetchOrder(type, page_no = 1) {
	//   const page_size = 10;
	//   const skip = (page_no - 1) * page_size;
	//   return Orders.find(
	//     { type },
	//     { sort: { createdAt: -1 }, skip, limit: page_size },
	//   ).fetch();
	// },

	fetchMyOrders({ uid, orderType, page_no }) {
		const page_size = 10;
		const skip = (page_no - 1) * page_size;

		if (orderType == 'test')
			orderType = {
				$in: ['single_test', 'package_test']
			};
		return Orders.find(
			{ orderType, createdBy: uid },
			{ sort: { createdAt: -1 }, skip, limit: page_size }
		).fetch();
	},

	fetchOrderCount(orderType) {
		return Orders.find({ orderType }).count();
	},

	fetchMyOrderCount({ orderType, uid }) {
		if (orderType == 'test')
			orderType = {
				$in: ['single_test', 'package_test']
			};
		return Orders.find({ orderType, createdBy: uid }).count();
	},

	updateOrderStatus(_id, status) {
		const ap = Orders.findOne(_id);
		if (ap.orderType == 'single_test' || ap.orderType == 'package_test') {
			const phone = ap.patient.phone;
			sendSMS(
				'Dear LifePlus user, your sample collection request ' +
					' is ' +
					status +
					'. Thank you for using LifePlus!',
				phone
			);
		}
		if (ap.orderType == 'medicine') {
			const phone = ap.phone;
			sendSMS(
				'Dear LifePlus user, your order request ' +
					' is ' +
					status +
					'. Thank you for using LifePlus!',
				phone
			);
		}
		return Orders.update({ _id }, { $set: { status } });
	},

	generateInvoice({ order, product, billing }) {
		const url = payment_gateway + '/payment/v2/invoice';
		const key = 'f7267c61edafb510d17043c64d501423';
		const app_id = '443cf9d99ade8cf1e604d55bcf27ebc9';
		const t = parseInt(Date.now() / 1000);

		const hash = crypto
			.createHash('md5')
			.update(key + t)
			.digest('hex');

		const str = app_id + ':' + hash;

		let dataJ = {
			headers: {
				'content-type': 'application/json',
				accept: 'application/json',
				Authorization: 'Bearer ' + Buffer.from(str).toString('base64')
			},
			data: {
				order,
				product,
				billing
			}
		};

		const response = HTTP.call('POST', url, dataJ);
		const resObj = JSON.parse(response.content);
		// console.log(resObj);
		if (resObj.result == 'success')
			return { invId: resObj.data.invoice_id, url: resObj.data.action.url };
		else
			throw Meteor.Error(
				'Sorry! Failed to generate invoice. PLease try again later'
			);
	},

	addInvoiceOrder({ orderId, invId }) {
		return (
			Orders.update({ _id: orderId }, { $set: { payment: { invId } } }) &&
			'Invoice successfully added to the order.'
		);
	},

	updateOrderPaymentStatus({ orderId, invId }) {
		const order = Orders.findOne(orderId);
		// console.log(order);
		if (order && order.payment && order.payment.invId != invId)
			throw new Meteor.Error('Sorry! Wrong order Id or inovice Id');

		const url = payment_gateway + '/payment/v2/invoice/' + invId;
		const key = 'f7267c61edafb510d17043c64d501423';
		const app_id = '443cf9d99ade8cf1e604d55bcf27ebc9';
		const t = parseInt(Date.now() / 1000);

		const hash = crypto
			.createHash('md5')
			.update(key + t)
			.digest('hex');

		const str = app_id + ':' + hash;

		let dataJ = {
			headers: {
				'content-type': 'application/json',
				accept: 'application/json',
				Authorization: 'Bearer ' + Buffer.from(str).toString('base64')
			}
		};

		const response = HTTP.call('GET', url, dataJ);
		const resObj = JSON.parse(response.content);
		// console.log(resObj);
		if (resObj.result == 'success') {
			const status = resObj.data.order.status;
			Orders.update(
				{ _id: orderId },
				{ $set: { payment: { ...order.payment, status } } }
			);
		}
	}
});
