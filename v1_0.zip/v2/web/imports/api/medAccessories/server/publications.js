import { Meteor } from 'meteor/meteor';
import { MedAccessories } from '../medAccessories';

Meteor.publish('fetch.medAccessories', () => {
  return MedAccessories.find();
});
