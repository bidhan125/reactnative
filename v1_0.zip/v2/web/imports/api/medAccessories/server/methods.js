import { Meteor } from 'meteor/meteor';
import { MedAccessories } from '../medAccessories';

Meteor.methods({
  addMedAccessories: data => {
    return MedAccessories.insert(data);
  },

  fetchMedAccessories({ page_no = 1, searchQuery = '', type }) {
    const page_size = 10;
    const skip = (page_no - 1) * page_size;

    searchQuery = searchQuery.replace(/\s\s+/g, ' ');
    searchQuery = searchQuery.replace(new RegExp(' ', 'g'), '.*');

    return MedAccessories.find(
      {
        name: {
          $regex: searchQuery,
          $options: '-i'
        },
        type
      },
      { sort: { name: 1 }, skip, limit: page_size }
    ).fetch();
  },

  fetchTotalAccCount({ src, form = undefined, searchQuery = '', type }) {
    searchQuery = searchQuery.replace(/\s\s+/g, ' ');
    searchQuery = searchQuery.replace(new RegExp(' ', 'g'), '.*');
    return MedAccessories.find({
      form,
      type,
      name: {
        $regex: searchQuery,
        $options: '-i'
      }
    }).count();
  }
});
