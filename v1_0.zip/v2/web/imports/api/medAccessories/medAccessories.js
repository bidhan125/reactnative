import { Mongo } from 'meteor/mongo';
import SimpleSchema from 'simpl-schema';

class CollectionSchema extends Mongo.Collection {
  insert(doc, callback) {
    doc.createdAt = new Date();
    doc.createdBy = this.userId;
    return super.insert(doc, callback);
  }

  update(doc, callback) {
    return super.update(doc, callback);
  }

  remove(doc, callback) {
    return super.remove(doc, callback);
  }
}

export const MedAccessories = new CollectionSchema('MedAccessories');

const schema = {};

schema.description = new SimpleSchema({
  blocks: { type: Array },
  'blocks.$': { type: String },
  entityMap: { type: Object },
});

MedAccessories.schema = new SimpleSchema({
  createdAt: { type: Date },
  createdBy: { type: Date },

  name: { type: String },
  category: { type: String },
  description: { type: schema.description },
  unit: { type: String },
  price: { type: String },
  available_quantity: { type: String },

  note: { type: String },
});
