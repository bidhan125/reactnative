import { createSwitchNavigator } from 'react-navigation';

import { AuthStack } from './stackNavigators';
import { drawerNavigator } from './drawerNavigator';
import Splashscreen from '../components/splashscreen/splashscreen';
import IntroSlider from '../components/auth/intro';

export const switchNavigator = createSwitchNavigator(
  {
    Splashscreen: { screen: Splashscreen },
    Intro: { screen: IntroSlider },
    App: drawerNavigator,
    Auth: AuthStack
  },
  {
    initialRouteName: 'Splashscreen'
  }
);
