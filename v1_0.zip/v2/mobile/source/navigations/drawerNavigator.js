import { Dimensions } from 'react-native';
import { createDrawerNavigator } from 'react-navigation';
import DrawerContentComponents from '../components/Drawer/drawer';
import { AppStack } from './stackNavigators';

const { width } = Dimensions.get('window');

export const drawerNavigator = createDrawerNavigator(
  {
    App: AppStack
  },
  {
    drawerWidth: width * 0.8,
    drawerPosition: 'left',
    contentComponent: DrawerContentComponents
  }
);
