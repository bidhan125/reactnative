import { createStackNavigator } from 'react-navigation';
import { stackNavigatorConfig } from '../configs/navigationConfig';

import Splashscreen from '../components/splashscreen/splashscreen';
import LogIn from '../components/auth/logIn';
import Home from '../components/home/home';
import Pharmacy from '../components/pharmacy/pharmacy';
import HomeCare from '../components/HomeCare/homeCare';
import CreateAppointment from '../components/Appointments/createAppointment';
import AppointmentChoice from '../components/Appointments/appointmentChoice';
import Appointments from '../components/Appointments/appointments';
import HealthCareAccessories from '../components/Healthcare/healthCareAccessories';
import Diagnostics from '../components/Diagnostics/diagnostics';
import Ambulance from '../components/Ambulance/ambulance';
import DiagnosticTest from '../components/Diagnostics/diagnosticTest';
import DiagnosticTestInfo from '../components/Diagnostics/diagnosticTestInfo';
import SignUp from '../components/auth/signUp';
import DiagnosticsRequest from '../components/Diagnostics/diagnosticsRequest';
import AboutUs from '../components/Drawer/aboutUs';
import MyBeneficiaries from '../components/Beneficiaries/myBeneficiaries';
import Emergency from '../components/Drawer/emergency';
import Faq from '../components/Drawer/faq';
import Feedback from '../components/Drawer/feedback';
import NursingCare from '../components/Nursing/nursingCare';
import ReportHomeDelivery from '../components/reports/reportHomeDelivery';
import PortableECG from '../components/HomeCare/portableECG';
import Ultrasonogram2D from '../components/HomeCare/ultrasonogram2D';
import Physiotherapy from '../components/HomeCare/physiotherapy';
import ProfileUpdate from '../components/Profile/profileUpdate';
import HealthCareAccessoriesDeliveryInfo from '../components/Healthcare/healthCareAccessoriesDeliveryInfo';
import BeneficiaryCreate from '../components/Beneficiaries/beneficiaryCreate';
import OTP from '../components/auth/otp';
import History from '../components/history/history';
import ForgotPass from '../components/auth/forgotPass';
import Cart from '../components/Cart/cartView';
import Checkout from '../components/Cart/checkout';
import BillAndShipment from '../components/Cart/billAndShipment';
import ChangePass from '../components/auth/changePass';
import MedicineDelivery from '../components/pharmacy/medicineDelivery';
import TermsAndConditions from '../components/auth/termsAndConditions';
import ProfileInfo from '../components/Profile/profileInfo';
import DiagnosticsTabControl from '../components/Diagnostics/diagnosticsTabControl';
import MedicalTourism from '../components/Drawer/medicalTourism';
import MedicalReport from '../components/Drawer/medicalReport';
import PrivacyPolicy from '../components/Drawer/privacyPolicy';
import BillingInfo from '../components/common/billingInfo';
import PaymentGateway from '../components/Cart/paymentGateway';
import MedicalHistory from '../components/Drawer/medicalHistory';

export const AppStack = createStackNavigator(
  {
    Splashscreen: {
      screen: Splashscreen
    },
    Home: {
      screen: Home
    },
    Pharmacy: {
      screen: Pharmacy
    },
    HomeCare: {
      screen: HomeCare
    },
    Appointments: {
      screen: Appointments
    },
    CreateAppointment: {
      screen: CreateAppointment
    },
    AppointmentChoice: {
      screen: AppointmentChoice
    },
    Diagnostics: {
      screen: Diagnostics
    },
    Ambulance: {
      screen: Ambulance
    },
    Diagnostics: {
      screen: Diagnostics
    },
    DiagnosticTestInfo: {
      screen: DiagnosticTestInfo
    },
    DiagnosticTest: {
      screen: DiagnosticTest
    },
    HealthCareAccessories: {
      screen: HealthCareAccessories
    },
    DiagnosticsRequest: {
      screen: DiagnosticsRequest
    },
    PrivacyPolicy: {
      screen: PrivacyPolicy
    },
    AboutUs: {
      screen: AboutUs
    },
    MyBeneficiaries: {
      screen: MyBeneficiaries
    },
    Emergency: {
      screen: Emergency
    },
    Faq: {
      screen: Faq
    },
    Feedback: {
      screen: Feedback
    },
    NursingCare: {
      screen: NursingCare
    },
    ReportHomeDelivery: {
      screen: ReportHomeDelivery
    },
    PortableECG: {
      screen: PortableECG
    },
    Physiotherapy: {
      screen: Physiotherapy
    },
    Ultrasonogram2D: {
      screen: Ultrasonogram2D
    },
    ProfileUpdate: {
      screen: ProfileUpdate
    },
    HealthCareAccessoriesDeliveryInfo: {
      screen: HealthCareAccessoriesDeliveryInfo
    },
    BeneficiaryCreate: {
      screen: BeneficiaryCreate
    },
    History: {
      screen: History
    },
    Cart: {
      screen: Cart
    },
    Checkout: {
      screen: Checkout
    },
    BillAndShipment: {
      screen: BillAndShipment
    },
    MedicineDelivery: {
      screen: MedicineDelivery
    },
    ProfileInfo: {
      screen: ProfileInfo
    },
    DiagnosticsTabControl: {
      screen: DiagnosticsTabControl
    },
    MedicalTourism: {
      screen: MedicalTourism
    },
    MedicalReport: {
      screen: MedicalReport
    },
    BillingInfo: {
      screen: BillingInfo
    },
    PaymentGateway: {
      screen: PaymentGateway
    },
    MedicalHistory: {
      screen: MedicalHistory
    }
  },
  {
    ...stackNavigatorConfig,
    initialRouteName: 'Home'
  }
);

export const AuthStack = createStackNavigator(
  {
    LogIn: {
      screen: LogIn
    },
    SignUp: {
      screen: SignUp
    },
    OTP: {
      screen: OTP
    },
    ForgotPass: {
      screen: ForgotPass
    },
    ChangePass: {
      screen: ChangePass
    },
    TermsAndConditions: {
      screen: TermsAndConditions
    }
  },

  {
    ...stackNavigatorConfig,
    initialRouteName: 'LogIn'
  }
);
