import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Dimensions,
  Image
} from 'react-native';

export default class SplashThree extends Component {
  render() {
    const displayWidth = Dimensions.get('window').width;
    const displayHeight = Dimensions.get('window').height;
    w = displayWidth * 0.7;
    h = (w * 228) / 264;

    return (
      <View style={styles.container}>
        <View style={styles.imageView}>
          <Image
            source={require('../assets/customicons/Group545.png')}
            style={{ width: w, height: h }}
          />
        </View>

        <View style={styles.textView}>
          <Text>
            This is splash screen number two which will be used in the Lifeplus
            project of Labaid
          </Text>
        </View>

        <View style={styles.bottomView} />
      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center'
  },
  imageView: {
    flex: 0.6,
    justifyContent: 'flex-end',
    alignItems: 'center',
    width: '88%'
  },
  textView: {
    flex: 0.25,
    justifyContent: 'center',
    alignItems: 'center',
    width: '88%'
  },
  bottomView: {
    flex: 0.15,
    justifyContent: 'center',
    alignItems: 'center',
    width: '88%'
  }
});
