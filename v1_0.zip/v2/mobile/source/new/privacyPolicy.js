import React, { Component } from 'react';
import { Platform, StyleSheet, Text, ScrollView, View } from 'react-native';
import Header from '../templates/lifeplusHeader';

export default class PrivacyPolicy extends Component {
  render() {
    return (
      <View style={styles.container}>
        <Header
          text="Privacy Policy"
          iconLeft="arrowleft"
          navigation={this.props.navigation}
        />

        <ScrollView
          style={styles.scrollingView}
          contentContainerStyle={{
            justifyContent: 'flex-start',
            alignItems: 'flex-start'
          }}
        >
          <Text style={{ paddingBottom: 20, paddingTop: 30 }}>Lorem Ipsum</Text>
          <Text style={{ paddingBottom: 20 }}>
            The story is set in Paris in 1482 during the reign of Louis XI. The
            gypsy Esmeralda (born as Agnes) captures the hearts of many men,
            including those of Captain Phoebus and Pierre Gringoire, but
            especially Quasimodo and his guardian Archdeacon Claude Frollo.
            Frollo is torn between his obsessive lust for Esmeralda and the
            rules of Notre Dame Cathedral. He orders Quasimodo to kidnap her,
            but Quasimodo is captured by Phoebus and his guards, who save
            Esmeralda.{' '}
          </Text>
          <Text style={{ paddingBottom: 50 }}>
            Les Misérables (French pronunciation: ​[le mizeʁabl(ə)]) is a French
            historical novel by Victor Hugo, first published in 1862, that is
            considered one of the greatest novels of the 19th century. In the
            English-speaking world, the novel is usually referred to by its
            original French title. However, several alternatives have been used,
            including The Miserables, The Wretched, The Miserable Ones, The Poor
            Ones, The Wretched Poor, The Victims and The Dispossessed.[1]
            Beginning in 1815 and culminating in the 1832 June Rebellion in
            Paris, the novel follows the lives and interactions of several
            characters, particularly the struggles of ex-convict Jean Valjean
            and his experience of redemption.[2]Hugo was at the forefront of the
            Romantic literary movement with his play Cromwell and drama Hernani.
            Many of his works have inspired music, both during his lifetime and
            after his death, including the musicals Notre-Dame de Paris and Les
            Misérables. He produced more than 4,000 drawings in his lifetime,
            and campaigned for social causes such as the abolition of capital
            punishment.
          </Text>
        </ScrollView>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'flex-start',
    alignItems: 'center',
    backgroundColor: '#ffffff'
  },
  scrollingView: {
    flexDirection: 'column',
    flex: 0.9,
    paddingHorizontal: 20
  }
});
