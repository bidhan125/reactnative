import React, { Component } from 'react';
import { View, ScrollView, Text, StyleSheet, SafeAreaView } from 'react-native';

import { CheckBox } from 'react-native-elements';
import Modal from 'react-native-modal';

import NavButton from '../common/navigationButton';

export default ReportDeliveryConditionsModal = props => {
  return (
    <Modal
      isVisible={props.isConditionModalVisible}
      onBackButtonPress={() =>
        props.updateState({
          [props.visibilityStateName]: !props.isConditionModalVisible
        })
      }
      onBackdropPress={() =>
        props.updateState({
          [props.visibilityStateName]: !props.isConditionModalVisible
        })
      }
    >
      <View style={styles.container}>
        <ScrollView>
          <View>
            <Text style={{ fontSize: 20 }}>
              Please read the below terms and conditions to confirm:
            </Text>
          </View>

          <View style={{ paddingTop: 20 }}>
            <Text style={styles.text}>
              1. Medical Reports in Labaid Envelop will be delivered through
              Home Delivery service with a certain fee
            </Text>
            <Text style={styles.text}>
              2. Reports will be delivered only in registered address and the
              recipient has to produce the Original Invoice during receive.
            </Text>
            <Text style={styles.text}>
              3. Communication with the patient will be done only through
              registered mobile number mentioned above.
            </Text>
            <Text style={styles.text}>
              4. Home Delivery Service Person will contact the recipient through
              registered mobile number and if the recipient does not answer, the
              Service Person will call again in next day to ensure the delivery.
            </Text>
            <Text style={styles.text}>
              5. If there is a failure to comply with the conditions mentioned
              in clause 2, 3 and 4 by the Patient, the package will be returned
              to the Labaid premises.
            </Text>
            <Text style={styles.text}>
              6. If the registered address is correct and the recipient is
              agreed through mobile communication, within Dhaka City, Medical
              Reports will be delivered within one working day; however,
              unpredictable traffic in Dhaka may cause little delay. Outside
              Dhaka city, Home delivery will be happened in 3 to 5 working days,
              very remote area in rural Bangladesh may take little longer time.
            </Text>
            <Text style={styles.text}>
              7. For any unavoidable situation if the delivery fails, Labaid
              will arrange the delivery of Second Copy of Medical Reports, and
              in that case, Delivery Time will be longer than the normal
              delivery time.
            </Text>
          </View>

          <View style={{ paddingTop: 10 }}>
            <CheckBox
              checked={props.agreed}
              onPress={() => props.updateState({ agreed: !props.agreed })}
              containerStyle={{
                padding: 0,
                marginLeft: 0,
                borderWidth: 0,
                backgroundColor: 'transparent'
              }}
              title="I, hereby, confirm my consent for Home Delivery of Medical
              Reports, which are invoiced in the date mention above."
              textStyle={{ fontStyle: 'italic' }}
            />
          </View>

          <View
            style={{
              justifyContent: 'center',
              alignItems: 'center',
              marginTop: 20
            }}
          >
            <NavButton
              buttonText={'Confirm'}
              buttonLength={'100%'}
              buttonFont={22}
              nav="Home"
              onPressFunc={props.handleSubmit.bind(this)}
            />
          </View>
        </ScrollView>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  container: {
    marginTop: 20,
    padding: 10,
    backgroundColor: 'white',
    borderRadius: 6
  },

  text: {
    fontSize: 15,
    paddingBottom: 6,
    textAlign: 'justify'
  }
});
