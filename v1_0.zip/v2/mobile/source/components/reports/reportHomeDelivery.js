import React, { Component } from 'react';
import {
  Alert,
  Platform,
  StyleSheet,
  Text,
  View,
  Dimensions,
  Image,
  TextInput,
  TouchableOpacity,
  Picker,
  ScrollView,
  KeyboardAvoidingView
} from 'react-native';
import { CheckBox, Button } from 'react-native-elements';
import { Picker as PickerNative, Icon as IconNative } from 'native-base';

import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import call from 'react-native-phone-call';
import Meteor from 'react-native-meteor';

import Header from '../common/header';
import PaymentModal from '../Modal/paymentModal';
import ReportDeliveryConditionsModal from './reportDeliveryConditionsModal';
import SpinView from '../common/spinner';

import { districtList } from '../../constants/const_strings';
import {
  scale,
  verticalScale,
  moderateScale,
  validation
} from '../../constants/const_functions';

export default class NursingCare extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isPaymentModalVisible: false,
      isConditionModalVisible: false,
      paymentMethod: 'Cash on Delivery',
      chosenValueCity: 'key0',
      processing: false,
      agreed: false
    };
  }

  updateState(obj) {
    this.setState(obj);
  }

  updatePayment(string) {
    this.setState({ paymentMethod: string });
  }

  handleValidation() {
    const {
      name,
      chosenValueCity,
      gender,
      invoiceId,
      reportId,
      phone,
      paymentMethod
    } = this.state;

    const address = this.state.address || Meteor.user().profile.address;

    if (chosenValueCity === undefined) {
      alert('Please select a city!');
      return;
    }

    if (validation(name, 'isName') !== true) return;

    if (gender === undefined) {
      alert('Please select gender!');
      return;
    }

    // if (address === undefined || address.length <= 0) {
    //   alert('Please give valid address!');
    //   return;
    // }

    if (validation(phone, 'isPhone') !== true) return;

    if (invoiceId === undefined || invoiceId.length <= 0) {
      alert('Please give your Invoice ID');
      return;
    }

    if (invoiceId === undefined || invoiceId.length <= 0) {
      alert('Please give your Invoice ID');
      return;
    }

    if (reportId === undefined || reportId.length <= 0) {
      alert('Please give your Report ID');
      return;
    }

    this.setState({
      isConditionModalVisible: !this.state.isConditionModalVisible
    });
  }

  modalMethod() {
    const {
      name,
      chosenValueCity,
      gender,
      invoiceId,
      reportId,
      phone,
      paymentMethod,
      agreed
    } = this.state;

    const address = this.state.address || Meteor.user().profile.address;

    data = {
      name,
      address,
      gender,
      invoiceId,
      reportId,
      phone,
      district: chosenValueCity,
      orderType: 'report_delivery',
      paymentMethod
    };

    if (!agreed) {
      alert('Please agree to the terms and conditions to continue!');
      return;
    }

    if (chosenValueCity === undefined) {
      alert('Please select a city!');
      return;
    }

    if (validation(name, 'isName') !== true) return;

    if (gender === undefined) {
      alert('Please select gender!');
      return;
    }

    // if (address === undefined || address.length <= 0) {
    //   alert('Please give valid address!');
    //   return;
    // }

    if (validation(phone, 'isPhone') !== true) return;

    if (invoiceId === undefined || invoiceId.length <= 0) {
      alert('Please give your Invoice ID');
      return;
    }

    if (invoiceId === undefined || invoiceId.length <= 0) {
      alert('Please give your Invoice ID');
      return;
    }

    if (reportId === undefined || reportId.length <= 0) {
      alert('Please give your Report ID');
      return;
    }

    this.setState({ processing: true, isConditionModalVisible: false });

    Meteor.call('addOrder', data, (err, res) => {
      console.log(err, res);
      this.setState({ processing: false });
      if (err) {
        alert(
          'Sorry! Failed to submit your request at this moment. Please try again later'
        );
      } else if (res) {
        Alert.alert(
          'Success',
          'Congratulations! Your request has been received successfully! Thank you!',
          [
            {
              text: 'Ok',
              onPress: () => this.props.navigation.navigate('Home')
            }
          ],
          { cancelable: false }
        );
      }
    });
  }

  render() {
    const args = {
      number: '999',
      prompt: false
    };

    const distOptions = [];
    // distOptions.push(<PickerNative.Item label="Select City" value="key0" />);
    districtList.map(item =>
      distOptions.push(<Picker.Item label={item.name} value={item.name} />)
    );

    if (this.state.processing) {
      return <SpinView />;
    }

    return (
      <KeyboardAvoidingView style={styles.container}>
        <Header
          text='Report Delivery'
          iconLeft='arrowleft'
          iconRight='shoppingcart'
          navigation={this.props.navigation}
        />
        <PaymentModal
          visibilityStateName='isPaymentModalVisible'
          visibility={this.state.isPaymentModalVisible}
          updateState={this.updateState.bind(this)}
          updatePayment={this.updatePayment.bind(this)}
        />
        <ReportDeliveryConditionsModal
          isConditionModalVisible={this.state.isConditionModalVisible}
          visibilityStateName='isConditionModalVisible'
          updateState={this.updateState.bind(this)}
          handleSubmit={this.modalMethod.bind(this)}
          agreed={this.state.agreed}
        />

        <ScrollView
          style={{ width: '100%' }}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{
            justifyContent: 'flex-start',
            alignItems: 'center'
          }}
        >
          <View style={styles.viewStyle}>
            <View
              style={{
                flex: 20,
                elevation: 2,
                backgroundColor: 'white',
                marginTop: verticalScale(10),
                borderRadius: 10
              }}
            >
              <View
                style={{
                  flex: 4,
                  paddingLeft: moderateScale(10),
                  alignItems: 'flex-start',
                  justifyContent: 'flex-start'
                }}
              >
                <Text
                  style={{
                    flex: 1,
                    fontSize: 16,
                    fontWeight: 'bold',
                    // color: "#707070",
                    paddingTop: 16,
                    height: verticalScale(50)
                  }}
                >
                  {' '}
                  Patient's Address
                </Text>
              </View>

              <View
                style={{
                  borderBottomWidth: 0.5,
                  borderBottomColor: '#BCBDC0'
                }}
              />
              <View style={styles.dropDownViewStyle}>
                <View
                  style={{
                    flex: 1,
                    width: '98%',
                    elevation: 1,
                    height: verticalScale(45),
                    borderRadius: 10,
                    shadowOffset: { width: 5, height: 5 },
                    shadowColor: 'grey',
                    shadowOpacity: 0.5,
                    shadowRadius: 10,
                    backgroundColor: '#ffffff'
                  }}
                >
                  {(Platform.OS == 'android' && (
                    <Picker
                      style={{ flex: 1, width: '98%' }}
                      selectedValue={this.state.chosenValueCity}
                      mode='dropdown'
                      onValueChange={(itemValue, itemIndex) =>
                        this.setState({ chosenValueCity: itemValue })
                      }
                    >
                      <Picker.Item label='Select City' value='key0' />
                      {distOptions}
                    </Picker>
                  )) || (
                    <PickerNative
                      style={{
                        // justifyContent: 'center',
                        width: '100%'
                      }}
                      placeholder='Select your city'
                      iosHeader='Select your city'
                      iosIcon={<IconNative name='arrow-down' />}
                      selectedValue={this.state.chosenValueCity}
                      mode='dropdown'
                      onValueChange={(itemValue, itemIndex) =>
                        this.setState({ chosenValueCity: itemValue })
                      }
                    >
                      {/* <PickerNative.Item label="Select City" value="key0" /> */}
                      {distOptions}
                    </PickerNative>
                  )}
                </View>
              </View>
              <View style={styles.addressInputStyle}>
                <TextInput
                  placeholder="Type patient's address, (Your profile address will be used if left Empty!)"
                  multiline={true}
                  editable={true}
                  onChangeText={address => this.setState({ address })}
                  value={this.state.address}
                  style={{ backgroundColor: '#F4F4F5', height: '100%' }}
                  numberOfLines={4}
                  textAlignVertical='top'
                />
              </View>
            </View>

            <View style={styles.patientInfoViewStyle}>
              <View
                style={{
                  flex: 8,
                  alignSelf: 'flex-start',
                  width: '100%',
                  borderBottomWidth: 0.5,
                  borderBottomColor: '#BCBDC0',
                  paddingLeft: moderateScale(10),
                  marginBottom: 5
                }}
              >
                <Text
                  style={{
                    flex: 1,
                    fontSize: 16,
                    fontWeight: 'bold',
                    // color: "#707070",
                    paddingTop: 16,
                    height: verticalScale(50)
                  }}
                  alignSelf='flex-start'
                >
                  Patient's Details
                </Text>
              </View>

              <View style={styles.nameViewStyle} flex={7}>
                <TextInput
                  style={{
                    height: verticalScale(45),
                    borderColor: '#BCBDC0',
                    borderBottomWidth: 1,
                    fontSize: 18,
                    fontSize: 16
                  }}
                  value={this.state.name}
                  onChangeText={name => this.setState({ name })}
                  placeholder="Type patient's name"
                  onSubmitEditing={() => this.refs.reportId.focus()}
                  returnKeyType='next'
                />
              </View>
              <View style={styles.genderViewStyle} flex={7}>
                <Text
                  style={{ fontSize: 16, fontWeight: 'bold', color: '#777777' }}
                >
                  Gender
                </Text>
                <CheckBox
                  title='Male'
                  checked={this.state.gender == 'male'}
                  containerStyle={styles.checkBoxStyle}
                  onPress={() => this.setState({ gender: 'male' })}
                />

                <CheckBox
                  title='Female'
                  checked={this.state.gender == 'female'}
                  containerStyle={styles.checkBoxStyle}
                  onPress={() => this.setState({ gender: 'female' })}
                />
              </View>

              <View style={styles.nameViewStyle} flex={7}>
                <TextInput
                  ref='reportId'
                  style={{
                    height: verticalScale(45),
                    borderColor: '#BCBDC0',
                    borderBottomWidth: 1,
                    fontSize: 18,
                    fontSize: 16
                  }}
                  value={this.state.reportId}
                  onChangeText={reportId => this.setState({ reportId })}
                  placeholder='Type Report ID'
                  onSubmitEditing={() => this.refs.invoiceId.focus()}
                  returnKeyType='next'
                />
              </View>

              <View style={styles.nameViewStyle} flex={7}>
                <TextInput
                  ref='invoiceId'
                  style={{
                    height: verticalScale(45),
                    borderColor: '#BCBDC0',
                    borderBottomWidth: 1,
                    fontSize: 18,
                    fontSize: 16
                  }}
                  value={this.state.invoiceId}
                  onChangeText={invoiceId => this.setState({ invoiceId })}
                  placeholder='Type Invoice ID'
                  onSubmitEditing={() => this.refs.phone.focus()}
                  returnKeyType='next'
                />
              </View>

              <View style={styles.nameViewStyle} flex={7}>
                <TextInput
                  ref='phone'
                  style={{
                    height: verticalScale(45),
                    borderColor: '#BCBDC0',
                    borderBottomWidth: 1,
                    fontSize: 18,
                    fontSize: 16
                  }}
                  value={this.state.phone}
                  onChangeText={phone => this.setState({ phone })}
                  placeholder='Enter your phone number'
                  keyboardType='phone-pad'
                />
              </View>
            </View>

            <View style={styles.payCashViewStyle}>
              <Text
                style={{
                  fontSize: 16,
                  fontWeight: 'bold',
                  paddingLeft: moderateScale(10)
                }}
              >
                Payment Method
              </Text>
              <TouchableOpacity
                disabled
                onPress={() =>
                  this.setState({
                    isPaymentModalVisible: !this.state.isPaymentModalVisible
                  })
                }
              >
                <View
                  style={{
                    flexDirection: 'row',
                    paddingRight: moderateScale(10)
                  }}
                >
                  <Text style={{ fontSize: 16, color: '#1285ff' }}>
                    {this.state.paymentMethod + ' '}
                  </Text>
                  <Icon name='arrow-right' size={20} color='#1285ff' />
                </View>
              </TouchableOpacity>
            </View>

            <View style={styles.button}>
              <Button
                title='Send Request'
                containerStyle={{ width: '100%' }}
                buttonStyle={{ backgroundColor: '#60BB46', borderRadius: 10 }}
                titleStyle={{ fontSize: moderateScale(20) }}
                onPress={() =>
                  // this.setState({
                  //   isConditionModalVisible: !this.state
                  //     .isConditionModalVisible
                  // })
                  this.handleValidation()
                }
              />
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    );
  }
}

const height = Dimensions.get('window').height;
const width = Dimensions.get('window').width;

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    flex: 1,
    alignItems: 'center'
  },
  viewStyle: {
    flex: 1,
    width: '95%'
  },
  textViewStyle: {
    flex: 5,
    fontSize: 16,
    fontWeight: 'bold',
    paddingTop: 16,
    height: verticalScale(40)
  },
  dropDownViewStyle: {
    flex: 4,
    flexDirection: 'row',
    paddingRight: moderateScale(10),
    paddingLeft: moderateScale(10),
    alignItems: 'center',
    height: moderateScale(80)
  },
  addressInputStyle: {
    flex: 12,
    paddingLeft: moderateScale(10),
    paddingRight: moderateScale(10),
    height: verticalScale(95),
    paddingBottom: moderateScale(5)
  },
  patientInfoViewStyle: {
    flex: 35,
    backgroundColor: '#ffffff',
    elevation: 2,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 15,
    height: verticalScale(350)
  },
  button: {
    flex: 15,
    justifyContent: 'center',
    alignItems: 'center',
    height: (height * 15) / 100
  },
  nameViewStyle: {
    flex: 18,
    width: '92%',
    justifyContent: 'center',
    paddingBottom: moderateScale(10)
  },
  genderViewStyle: {
    flex: 15,
    width: '92%',
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    alignItems: 'center'
  },
  phoneNumberViewStyle: {
    flex: 17,
    width: '92%',
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    marginBottom: 10
  },
  numberHolderStyle: {
    position: 'absolute',
    bottom: 20,
    fontSize: 15,
    left: 4
  },
  numberPrefixStyle: {
    position: 'absolute',
    bottom: 20,
    left: 105,
    fontSize: 15,
    fontWeight: 'bold'
  },
  numberInputStyle: {
    height: 40,
    borderColor: 'gray',
    borderBottomWidth: 1,
    fontSize: 16,
    position: 'absolute',
    bottom: 10,
    left: 150
  },
  checkBoxStyle: {
    backgroundColor: '#ffffff',
    width: '36%'
  },
  specsViewStyle: {
    flex: 10,
    width: '92%',
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center'
  },
  smallViewStyle: {
    flex: 0.5,
    alignItems: 'center'
  },
  modalStyle: {
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1
  },
  modalInsideViewStyle: {
    flex: 0.5,
    justifyContent: 'flex-start',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    width: '100%',
    borderRadius: 10
  },
  modalChildStyle: {
    flex: 0.33,
    width: '100%',
    alignItems: 'center'
  },
  modalButtonView: {
    flex: 0.33,
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center'
  },
  payCashViewStyle: {
    flex: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: (height * 5) / 100,
    marginTop: 10
  }
});
