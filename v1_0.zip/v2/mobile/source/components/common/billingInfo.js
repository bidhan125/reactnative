import React, { Component } from 'react';
import {
  View,
  Text,
  KeyboardAvoidingView,
  ScrollView,
  StyleSheet,
  TextInput
} from 'react-native';
import { Button } from 'react-native-elements';

import Header from './header';
import { moderateScale, verticalScale } from '../../constants/const_functions';

export default class BillingInfo extends Component {
  constructor(props) {
    super(props);
    const navigation = this.props.navigation;
    this.state = {
      name: navigation.getParam('name'),
      email: navigation.getParam('email'),
      phone: navigation.getParam('phone'),
      city: navigation.getParam('city')
    };
  }

  render() {
    console.log(this.props.navigation.getParam('name'));
    return (
      <View style={styles.container}>
        <Header
          text='Billing Address'
          iconLeft='arrowleft'
          navigation={this.props.navigation}
        />
        <ScrollView>
          <View style={styles.body}>
            <View style={styles.rowStyle}>
              <View style={{ flex: 0.3 }}>
                <Text style={styles.text}>Name</Text>
              </View>
              <View style={{ flex: 0.7 }}>
                <TextInput
                  value={this.state.name}
                  multiline={false}
                  editable={true}
                  onChangeText={name => this.setState({ name })}
                  style={{
                    borderColor: '#bcbdc0',
                    textAlign: 'left',
                    borderBottomWidth: 1
                  }}
                  placeholder='Name'
                />
              </View>
            </View>
            <View style={styles.rowStyle}>
              <View style={{ flex: 0.3 }}>
                <Text style={styles.text}>Email</Text>
              </View>
              <View style={{ flex: 0.7 }}>
                <TextInput
                  value={this.state.email}
                  multiline={false}
                  editable={true}
                  onChangeText={email => this.setState({ email })}
                  style={{
                    borderColor: '#bcbdc0',
                    textAlign: 'left',
                    borderBottomWidth: 1
                  }}
                  placeholder='Email'
                />
              </View>
            </View>
            <View style={styles.rowStyle}>
              <View style={{ flex: 0.3 }}>
                <Text style={styles.text}>Phone</Text>
              </View>
              <View style={{ flex: 0.7 }}>
                <TextInput
                  value={this.state.phone}
                  multiline={false}
                  editable={true}
                  onChangeText={phone => this.setState({ phone })}
                  style={{
                    borderColor: '#bcbdc0',
                    textAlign: 'left',
                    borderBottomWidth: 1
                  }}
                  placeholder='Phone'
                />
              </View>
            </View>
            <View style={styles.rowStyle}>
              <View style={{ flex: 0.3 }}>
                <Text style={styles.text}>Street</Text>
              </View>
              <View style={{ flex: 0.7 }}>
                <TextInput
                  multiline={false}
                  editable={true}
                  onChangeText={street => this.setState({ street })}
                  style={{
                    borderColor: '#bcbdc0',
                    textAlign: 'left',
                    borderBottomWidth: 1
                  }}
                  placeholder='Street'
                />
              </View>
            </View>
            <View style={styles.rowStyle}>
              <View style={{ flex: 0.3 }}>
                <Text style={styles.text}>City</Text>
              </View>
              <View style={{ flex: 0.7 }}>
                <TextInput
                  value={this.state.city}
                  multiline={false}
                  editable={true}
                  onChangeText={city => this.setState({ city })}
                  style={{
                    borderColor: '#bcbdc0',
                    textAlign: 'left',
                    borderBottomWidth: 1
                  }}
                  placeholder='City'
                />
              </View>
            </View>
            <View style={styles.rowStyle}>
              <View style={{ flex: 0.3 }}>
                <Text style={styles.text}>Zip Code</Text>
              </View>
              <View style={{ flex: 0.7 }}>
                <TextInput
                  multiline={false}
                  editable={true}
                  onChangeText={zip => this.setState({ zip })}
                  style={{
                    borderColor: '#bcbdc0',
                    textAlign: 'left',
                    borderBottomWidth: 1
                  }}
                  placeholder='Zip Code'
                />
              </View>
            </View>

            <View
              style={{
                flex: 0.1,
                justifyContent: 'center',
                alignItems: 'center',
                paddingTop: verticalScale(20),
                paddingBottom: verticalScale(10)
              }}
            >
              <Button
                title='Confirm'
                containerStyle={{ width: '100%' }}
                buttonStyle={{ borderRadius: 10, backgroundColor: '#60BB46' }}
                titleStyle={{ fontSize: moderateScale(18) }}
                // onPress={() => this.handleSubmit()}
              />
            </View>
          </View>
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  body: {
    flex: 1,
    margin: 20
  },
  rowStyle: {
    flex: 0.2,
    marginTop: moderateScale(15),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  text: {
    fontSize: moderateScale(15),
    color: '#707070',
    paddingBottom: moderateScale(10),
    fontWeight: '500'
  }
});
