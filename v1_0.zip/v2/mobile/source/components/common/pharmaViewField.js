import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Dimensions,
  Image,
  TouchableOpacity
} from 'react-native';

import { Icon as IconEl, Badge, Avatar } from 'react-native-elements';
import Icon from 'react-native-vector-icons/AntDesign';
//props: medicineName,medicineDesc,imgComponentAsProp

import {
  moderateScale,
  verticalScale,
  scale
} from '../../constants/const_functions';

import { medicine_types } from '../../constants/const_strings';

export default class PharmaViewField extends Component {
  render() {
    const displayWidth = Dimensions.get('window').width;
    const displayHeight = Dimensions.get('window').height;
    let fieldHeight = moderateScale(80);
    let imageDiameter = moderateScale(60);

    var path = { path: '' };

    const type = this.props.medicineType;

    if (type === 'Liquid') {
      path = { path: require('../../assets/medicineIcon/liquid.png') };
    } else if (type === 'Syrup') {
      path = { path: require('../../assets/medicineIcon/liquid.png') };
    } else if (type === 'Suspension') {
      path = { path: require('../../assets/medicineIcon/liquid.png') };
    } else if (type === 'Powder for Suspension') {
      path = { path: require('../../assets/medicineIcon/liquid.png') };
    } else if (type === 'Tablet') {
      path = { path: require('../../assets/medicineIcon/tablet.png') };
    } else if (type === 'Capsule') {
      path = { path: require('../../assets/medicineIcon/capsules.png') };
    } else if (type === 'Topical medicines') {
      path = { path: require('../../assets/medicineIcon/topical.png') };
    } else if (type === 'Gel') {
      path = { path: require('../../assets/medicineIcon/topical.png') };
    } else if (type === 'Eye gel') {
      path = { path: require('../../assets/medicineIcon/topical.png') };
    } else if (type === 'Topical Solution') {
      path = { path: require('../../assets/medicineIcon/topical.png') };
    } else if (type === 'Cream') {
      path = { path: require('../../assets/medicineIcon/topical.png') };
    } else if (type === 'Ointment') {
      path = { path: require('../../assets/medicineIcon/topical.png') };
    } else if (type === 'Suppository') {
      path = { path: require('../../assets/medicineIcon/suppositories.png') };
    } else if (type === 'Eye Drops') {
      path = { path: require('../../assets/medicineIcon/drops.png') };
    } else if (type === 'Paediatric Drops') {
      path = { path: require('../../assets/medicineIcon/drops.png') };
    } else if (type === 'Inhaler') {
      path = { path: require('../../assets/medicineIcon/inhalers.png') };
    } else if (type === 'Mouthwash') {
      path = { path: require('../../assets/medicineIcon/inhalers.png') };
    } else if (type === 'Injection') {
      path = { path: require('../../assets/medicineIcon/injection.png') };
    } else if (type === 'Implants or patches') {
      path = { path: require('../../assets/medicineIcon/implants.png') };
    } else if (type === 'Buccal or sublingual tablets or liquids') {
      path = { path: require('../../assets/medicineIcon/buccal.png') };
    } else {
      path = { path: require('../../assets/customIcons/drug.png') };
    }

    const { medicinePrice } = this.props;

    return (
      <TouchableOpacity onPress={this.props.onPress} style={styles.container}>
        {/* <View
          style={styles.container}
          height={fieldHeight}
          width={displayWidth * 0.95}
        > */}
        <View style={styles.smallView} alignItems="center">
          <View
            style={styles.imageViewStyle}
            width={imageDiameter}
            height={imageDiameter}
          >
            <Image source={path.path} style={{ width: 35, height: 35 }} />
          </View>
        </View>

        <View style={styles.textView}>
          <View
            style={{
              flex: 0.5,
              justifyContent: 'center',
              alignItems: 'flex-start'
            }}
          >
            <Text style={{ fontSize: 15, fontWeight: 'bold' }}>
              {this.props.medicineName}
            </Text>
          </View>

          <View
            style={{
              flex: 0.5,
              justifyContent: 'flex-start',
              alignItems: 'flex-start',
              flexDirection: 'row'
            }}
          >
            {this.props.medicineStrength && (
              <View
                style={{
                  flex: 1.2,
                  flexDirection: 'row',
                  alignItems: 'center'
                }}
              >
                <Image
                  source={require('../../assets/medicineStrength.png')}
                  style={{ height: 16, width: 16, opacity: 0.5 }}
                />
                <Text>
                  {' '}
                  {this.props.medicineStrength === ' '
                    ? 'Not given'
                    : displayWidth < 360
                    ? this.props.medicineStrength.substring(0, 8)
                    : this.props.medicineStrength.length > 16
                    ? this.props.medicineStrength.substring(0, 17)
                    : this.props.medicineStrength}
                </Text>
              </View>
            )}
            {this.props.mfg && (
              <View
                style={{
                  flex: 1,
                  flexDirection: 'row',
                  alignItems: 'center'
                }}
              >
                <Image
                  source={require('../../assets/manfu.png')}
                  style={{ height: 15, width: 15, opacity: 0.5 }}
                />
                <Text>{' '} {this.props.mfg}</Text>
              </View>
            )}
            <View
              style={{ flex: 0.8, flexDirection: 'row', alignItems: 'center' }}
            >
              <Image
                source={require('../../assets/price_tag.png')}
                style={{
                  width: moderateScale(15),
                  height: moderateScale(15),
                  opacity: 0.5
                }}
              />

              <Text>
                {' '}
                {medicinePrice !== undefined && medicinePrice.length > 6
                  ? medicinePrice.substring(0, 6) + ' BDT'
                  : medicinePrice + ' BDT'}
              </Text>
            </View>
          </View>
        </View>

        {this.props.isOrdered && (
          <TouchableOpacity
            style={styles.cartView}
            onPress={() => this.props.removeItemFromCart(this.props.item._id)}
          >
            <View
              style={{
                flex: 1,
                alignItems: 'center',
                backgroundColor: '#0076BE',
                justifyContent: 'center',
                borderTopLeftRadius: 20,
                borderBottomLeftRadius: 20
              }}
            >
              <Avatar
                icon={{
                  name: 'shoppingcart',
                  type: 'antdesign',
                  size: moderateScale(25),
                  color: 'white'
                }}
                overlayContainerStyle={{ backgroundColor: 'transparent' }}
              />

              <Badge
                containerStyle={{
                  position: 'absolute',
                  top: verticalScale(15),
                  right: moderateScale(7)
                }}
                value={this.props.quantity}
                textStyle={{ color: 'blue' }}
                badgeStyle={{ backgroundColor: 'white' }}
              />
            </View>
          </TouchableOpacity>
        )}
        {!this.props.isOrdered && (
          <View style={styles.cartView} alignItems="center">
            <Icon name="shoppingcart" size={25} color="#1285ff" />
          </View>
        )}
        {/* </View> */}
      </TouchableOpacity>
    );
  }
}

const displayWidth = Dimensions.get('window').width;
const displayHeight = Dimensions.get('window').height;
let fieldHeight = moderateScale(80);
let imageDiameter = moderateScale(60);

var styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    elevation: 1.5,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    borderRadius: 15,
    marginLeft: moderateScale(10),
    marginRight: moderateScale(10),
    marginBottom: moderateScale(10),
    height: fieldHeight,
    width: displayWidth * 0.95,
    shadowOffset: { width: 3, height: 3 },
    shadowColor: 'grey',
    shadowOpacity: 0.25,
    shadowRadius: 7
  },
  smallView: {
    flex: 0.18,
    justifyContent: 'center',
    padding: moderateScale(10)
  },
  cartView: {
    flex: 0.15,
    justifyContent: 'center',
    opacity: 5,
    borderTopLeftRadius: 20,
    borderBottomLeftRadius: 20
  },
  imageViewStyle: {
    backgroundColor: '#ffffff',
    borderRadius: 200,
    justifyContent: 'center',
    alignItems: 'center'
  },
  textView: {
    flex: 0.67,
    justifyContent: 'center',
    alignItems: 'flex-start',
  }
});

PharmaViewField.defaultProps = {
  medicineName: 'Name not given',
  medicinePrice: 'Not given'
};
