import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  TouchableOpacity
} from 'react-native';

//props: buttonFont,buttonText,buttonLength,passFunction

export default class NavigationButton extends Component {
  handleMethod() {
    this.props.navigation.navigate(this.props.nav);
  }
  render() {
    return (
      <View style={styles.buttonViewStyle} width={this.props.buttonLength}>
        <TouchableOpacity
          style={styles.buttonStyle}
          activeOpacity={0.4}
          onPress={() => {
            this.props.onPressFunc
              ? this.props.onPressFunc()
              : this.handleMethod();
          }}
        >
          <Text style={{ color: 'white', fontSize: this.props.buttonFont }}>
            {' '}
            {this.props.buttonText}{' '}
          </Text>
        </TouchableOpacity>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  buttonViewStyle: {
    height: 45,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 50,
    backgroundColor: '#60BB46',
    elevation: 1
  },
  buttonStyle: {
    width: '100%',
    height: '100%',
    borderRadius: 50,
    paddingHorizontal: 10,
    justifyContent: 'center',
    alignItems: 'center'
  }
});
