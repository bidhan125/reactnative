import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Dimensions,
  TextInput,
} from 'react-native';
import { Icon } from 'react-native-elements';
import { Header, Item, Input, Button } from 'native-base';
import { moderateScale } from '../../constants/const_functions';

/**
 * PROPS:
 *  phaceholder (string)
 *  handleSearch (function)
 */

export const SearchField = props => {
  const { value, updateState, handleSearch } = props;
  return (
    <View style={styles.container}>
      <View
        searchBar
        rounded
        navigation={props.navigation}
        style={{
          backgroundColor: 'white',
          marginLeft: moderateScale(10),
          marginRight: moderateScale(10),
          borderRadius: 15,
          elevation: 1,
          height: moderateScale(45),
          shadowOffset: { width: 3, height: 3 },
          shadowColor: 'grey',
          shadowOpacity: 0.25,
          shadowRadius: 7,
          justifyContent: 'center'
        }}
      >
        <Item style={{ backgroundColor: 'transparent', borderBottomWidth: 0}}>
          <Icon name="search" type="octicons" color="#707070" />
          <Input
            placeholder={props.placeholderText}
            editable={true}
            style={{ height: '100%', }}
            value={value}
            multiline={false}
            onChangeText={searchQuery => updateState({ searchQuery })}
            onSubmitEditing={() => handleSearch()}
            returnKeyType="search"
          />
        </Item>
      </View>
    </View>
  );
};

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    width: '100%',
  },
});
