import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
} from 'react-native';
/* props in this code: imgAsComponent,height,flexLeft,flexRight,bottomMargin and imageText  */

export default class RectangleViewHomeCare extends Component {
  render() {
    return (
      <TouchableOpacity
        style={styles.viewStyle}
        onPress={() =>
          this.props.navigation.navigate('NursingCare', {
            title: this.props.title,
          })
        }
      >
        {/* <View
          style={styles.viewStyle}
          height={this.props.rectangleHeight}
          marginBottom={this.props.bottomMargin}
        > */}
        <View style={styles.imageView} flex={this.props.flexLeft}>
          {this.props.imgAsComponent}
        </View>
        <View style={styles.textImageView} flex={this.props.flexRight}>
          <Text style={{ color: '#1285ff', fontSize: 20 }}>
            {this.props.imageText}
          </Text>
        </View>
        {/* </View> */}
      </TouchableOpacity>
    );
  }
}

var styles = StyleSheet.create({
  viewStyle: {
    width: '94%',
    backgroundColor: '#ffffff',
    elevation: 1.5,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    borderRadius: 8,
    height: 98,
    marginBottom: 8,
    shadowOffset: { width: 3, height: 3 },
    shadowColor: 'grey',
    shadowOpacity: 0.25,
    shadowRadius: 5,
  },

  imageView: {
    justifyContent: 'center',
    alignItems: 'center',
    height: '100%',
  },

  textImageView: {
    height: '100%',
    alignItems: 'flex-start',
    justifyContent: 'center',
  },
});
