import React, { Component } from 'react';
import { View, Text } from 'react-native';

export class Placeholder extends Component {
  render() {
    console.log('placeholder');
    return (
      <View>
        <Text>{this.props.header}</Text>
        <Text>{this.props.details}</Text>
      </View>
    );
  }
}
