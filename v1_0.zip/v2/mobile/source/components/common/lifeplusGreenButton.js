import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Linking,
} from 'react-native';

//props: buttonFont,buttonText,buttonLength,passFunction

export default class LifeplusGreenButton extends Component {
  render() {
    return (
      <View style={styles.buttonViewStyle} width={this.props.buttonLength}>
        <TouchableOpacity
          style={styles.buttonStyle}
          activeOpacity={0.4}
          onPress={() => this.props.passFunction()}
        >
          <Text style={{ color: 'white', fontSize: this.props.buttonFont }}>
            {' '}
            {this.props.buttonText}{' '}
          </Text>
        </TouchableOpacity>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  buttonViewStyle: {
    height: 45,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 10,
    backgroundColor: '#60BB46',
    elevation: 1,
    shadowOffset: { width: 3, height: 3 },
    shadowColor: 'grey',
    shadowOpacity: 0.25,
    shadowRadius: 5,
  },
  buttonStyle: {
    width: '100%',
    height: '100%',
    borderRadius: 50,
    paddingHorizontal: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
