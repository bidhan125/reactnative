import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Dimensions,
  TouchableOpacity,
  Platform,
  SafeAreaView
} from 'react-native';
// import Icon from 'react-native-vector-icons/AntDesign';
import { Icon } from 'react-native-elements';
import { DrawerActions } from 'react-navigation-drawer';
import { moderateScale } from '../../constants/const_functions';

const displayHeight = Dimensions.get('window').height;

let headerHeight = displayHeight * (Platform.OS === 'ios' ? 0.099 : 0.094);

export default class Header extends Component {
  constructor(props) {
    super(props);
  }

  handleOnpressLeft() {
    console.log(this.props);
    this.props.iconLeft == 'arrowleft'
      ? this.props.navigation.goBack() || this.props.navigation.navigate('Home')
      : this.props.navigation.dispatch(DrawerActions.toggleDrawer());
  }

  render() {
    return (
      <SafeAreaView style={styles.mainView} height={headerHeight}>
        <View style={styles.iconView}>
          <TouchableOpacity
            activeOpacity={0.6}
            onPress={() => this.handleOnpressLeft()}
          >
            <Icon
              name={this.props.iconLeft}
              type="antdesign"
              size={28}
              color="white"
            />
          </TouchableOpacity>
        </View>

        <View style={styles.textView}>
          <Text style={styles.text}> {this.props.text} </Text>
        </View>

        {this.props.iconRight && (
          <View style={styles.iconView}>
            <TouchableOpacity
              activeOpacity={0.6}
              onPress={() => this.props.navigation.navigate('Cart')}
            >
              <Icon
                name={this.props.iconRight}
                type="antdesign"
                size={28}
                color="white"
              />
            </TouchableOpacity>
          </View>
        )}
      </SafeAreaView>
    );
  }
}

var styles = StyleSheet.create({
  mainView: {
    flexDirection: 'row',
    width: '100%',
    backgroundColor: '#1285ff',
    borderBottomStartRadius: 10,
    borderBottomEndRadius: 10,
    alignItems: 'center',
    // marginTop: Platform.OS === 'ios' ? 20 : 0,
  },
  iconView: {
    flex: 0.15,
    justifyContent: 'center',
    alignItems: 'center',
  },
  textView: {
    flex: 0.7,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: {
    fontSize: moderateScale(20),
    color: '#ffffff',
    justifyContent: 'center',
  },
});
