import React, { Component } from 'react';
import { View, Text, StyleSheet, Dimensions, Image } from 'react-native';

import DatePicker from 'react-native-datepicker';
import Modal from 'react-native-modal';
import { Icon, Button } from 'react-native-elements';
import moment from 'moment';

import {
  scale,
  verticalScale,
  moderateScale
} from '../../constants/const_functions';

const width = Dimensions.get('window').width;
const height = Dimensions.get('window').height;

const statusSize = (width / 2) * 0.5;

export default class AppointmentDetailsModal extends Component {
  render() {
    var status = String(this.props.modalProperty['status']);
    status = status.charAt(0).toUpperCase() + status.slice(1);
    return (
      <Modal
        // style={styles.modal}
        isVisible={this.props.visibility}
        onBackButtonPress={() =>
          this.props.updateState({
            [this.props.visibilityStateName]: !this.props.visibility,
            isDateVisible: false
          })
        }
        onBackdropPress={() =>
          this.props.updateState({
            [this.props.visibilityStateName]: !this.props.visibility,
            isDateVisible: false
          })
        }
      >
        <View style={{ backgroundColor: 'white', borderRadius: 10 }}>
          <View style={styles.headerView}>
            <View
              style={{
                flex: 1,
                paddingBottom: verticalScale(10),
                alignItems: 'center',
                justifyContent: 'center'
              }}
            >
              <View style={styles.docImage}>
                <Image
                  style={{ width: statusSize * 0.7, height: statusSize * 0.7 }}
                  source={require('../../assets/customIcons/doc.png')}
                />
              </View>
              <Text style={{ fontSize: moderateScale(20), color: 'black' }}>
                {this.props.modalProperty['doctorName']}
              </Text>
              <Text style={{ fontSize: moderateScale(15) }}>
                {this.props.modalProperty['speciality']}
              </Text>
            </View>
            <View
              style={{
                height: 1,
                backgroundColor: 'grey',
                width: '100%',
                alignSelf: 'center',
                opacity: 0.3
              }}
            />
          </View>

          <View style={styles.bodyView}>
            <View style={styles.list}>
              <View style={{ flex: 0.4 }}>
                <Text style={styles.textKey}>Branch: </Text>
              </View>
              <View style={{ flex: 0.6 }}>
                <Text style={styles.textValue}>
                  {this.props.modalProperty['branch']}
                </Text>
              </View>
            </View>
            <View style={styles.list}>
              <View style={{ flex: 0.4 }}>
                <Text style={styles.textKey}>Status: </Text>
              </View>
              <View style={{ flex: 0.6, flexWrap: 'wrap' }}>
                <Text style={styles.textValue}>{status}</Text>
              </View>
            </View>
            <View style={styles.list}>
              <View style={{ flex: 0.4 }}>
                <Text style={styles.textKey}>Patient's Name: </Text>
              </View>
              <View style={{ flex: 0.6, flexWrap: 'wrap' }}>
                <Text style={styles.textValue}>
                  {this.props.modalProperty['patientName']}
                </Text>
              </View>
            </View>
            <View style={styles.list}>
              <View style={{ flex: 0.4 }}>
                <Text style={styles.textKey}>Date: </Text>
              </View>
              <View style={{ flex: 0.6, flexWrap: 'wrap' }}>
                {this.props.isDateVisible && (
                  <DatePicker
                    // style={{ flex: 0.7 }}
                    showIcon={false}
                    date={this.props.date}
                    mode='date'
                    confirmBtnText='Confirm'
                    cancelBtnText='Cancel'
                    placeholder='Select Date'
                    format='YYYY-MM-DD'
                    onDateChange={date => {
                      this.props.updateState({ date });
                    }}
                    customStyles={{
                      dateInput: { borderRadius: 10, height: 30 }
                    }}
                  />
                )}
                {!this.props.isDateVisible && (
                  <Text style={styles.textValue}>
                    {this.props.modalProperty['date']}
                  </Text>
                )}
              </View>
            </View>
            <View style={styles.list}>
              <View style={{ flex: 0.4 }}>
                <Text style={styles.textKey}>Visiting hour: </Text>
              </View>
              <View style={{ flex: 0.6, flexWrap: 'wrap' }}>
                {this.props.isDateVisible && (
                  <DatePicker
                    // style={{ flex: 0.7 }}
                    showIcon={false}
                    date={this.props.time}
                    mode='time'
                    confirmBtnText='Confirm'
                    cancelBtnText='Cancel'
                    placeholder='Select time'
                    format='HH:mm'
                    is24Hour={false}
                    onDateChange={time => {
                      this.props.updateState({ time });
                    }}
                    customStyles={{
                      dateInput: { borderRadius: 10, height: 30 }
                    }}
                  />
                )}
                {!this.props.isDateVisible && (
                  <Text style={styles.textValue}>
                    {this.props.modalProperty['time']}
                  </Text>
                )}
              </View>
            </View>
            {this.props.modalProperty['isBeneficiary'] && (
              <View style={styles.list}>
                <View style={{ flex: 0.4 }}>
                  <Text style={styles.textKey}>Relation: </Text>
                </View>
                <View style={{ flex: 0.6, flexWrap: 'wrap' }}>
                  <Text style={styles.textValue}>
                    {this.props.modalProperty['relation']}
                  </Text>
                </View>
              </View>
            )}
          </View>
          <View
            style={{
              height: 1,
              backgroundColor: 'grey',
              width: '100%',
              alignSelf: 'center',
              opacity: 0.3
            }}
          />
          <View
            style={{
              // flex: 1.5,
              margin: 10,
              justifyContent: 'center',
              alignItems: 'center'
            }}
          >
            <Button
              title='Cancel Appointment'
              type='outline'
              onPress={() => this.props.updateAppointment('cancelled')}
              containerStyle={{ width: '100%' }}
              buttonStyle={{
                borderRadius: 30,
                borderColor: 'red',
                padding: moderateScale(10)
                // backgroundColor: '#60BB46'
              }}
              titleStyle={{ color: 'red', fontSize: moderateScale(15) }}
            />
          </View>
          <View
            style={{
              // flex: 1.5,
              margin: 10,
              justifyContent: 'center',
              alignItems: 'center'
            }}
          >
            <Button
              title={
                this.props.isDateVisible ? 'Confirm' : 'Re-schedule Appointment'
              }
              type='outline'
              onPress={() => {
                this.props.isDateVisible
                  ? this.props.updateAppointment('time')
                  : this.props.updateState({
                      isDateVisible: !this.props.isDateVisible
                    });
              }}
              containerStyle={{ width: '100%' }}
              buttonStyle={{
                borderRadius: 30,
                padding: moderateScale(10),
                backgroundColor: '#60BB46'
              }}
              titleStyle={{ color: 'white', fontSize: moderateScale(15) }}
            />
          </View>
        </View>
      </Modal>
    );
  }
}

const styles = StyleSheet.create({
  modal: {
    // flex: 1,
    backgroundColor: 'white'
    // marginTop: height * 0.14,
    // marginBottom: height * 0.14,
    // marginLeft: width * 0.08,
    // marginRight: width * 0.08,
    // borderRadius: 20,
  },

  headerView: {
    // flex: 3.5,
    height: verticalScale(120)
  },

  bodyView: {
    // flex: 4,
    paddingLeft: moderateScale(20),
    marginTop: 10,
    marginBottom: 10
  },

  docImage: {
    width: statusSize * 0.7,
    height: statusSize * 0.7,
    borderRadius: 100,
    padding: moderateScale(20),
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden'
  },

  list: {
    // flex: 1,
    height: verticalScale(30),
    flexDirection: 'row',
    alignItems: 'center'
  },

  textKey: {
    fontSize: moderateScale(14),
    color: 'black'
  },

  textValue: {
    fontSize: moderateScale(17)
  }
});
