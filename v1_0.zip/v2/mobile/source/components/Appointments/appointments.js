import React, { Component } from "react";
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  Picker,
  ScrollView,
  Dimensions
} from "react-native";
import { Fab } from "native-base";
import { TabView, SceneMap } from "react-native-tab-view";
import Icon from "react-native-vector-icons/AntDesign";

import Header from "../common/header";
import MyAppointment from "./myAppointment";
import BeneficiaryAppointment from "./beneficiaryAppointment";
import {
  scale,
  verticalScale,
  moderateScale
} from "../../constants/const_functions";

const { height, width } = Dimensions.get("window");
export default class Appointments extends Component {
  constructor(props) {
    super(props);

    this.state = {
      index: 0,
      routes: [
        { key: "first", title: "My Appointments" },
        { key: "second", title: "Others" }
      ]
    };
  }

  render() {
    return (
      <React.Fragment>
        <Header
          text="Appointments"
          iconLeft="arrowleft"
          iconRight="shoppingcart"
          navigation={this.props.navigation}
        />
        <TabView
          navigationState={this.state}
          renderScene={SceneMap({
            first: MyAppointment,
            second: BeneficiaryAppointment
          })}
          onIndexChange={index => this.setState({ index })}
          initialLayout={{ width }}
          tabStyle={{ height: verticalScale(50) }}
          style={{ height: height / 2 }}
          tabBarPosition="bottom"
        />

        <Fab
          active={this.state.active}
          direction="up"
          containerStyle={{}}
          style={{ backgroundColor: "#5067FF", marginBottom: 50, right: 0 }}
          position="bottomRight"
          onPress={() => this.props.navigation.navigate("AppointmentChoice")}
        >
          <Icon name="plus" />
        </Fab>
      </React.Fragment>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    height: 1000,
    flex: 1,
    justifyContent: "flex-start",
    alignItems: "center"
  }
});
