import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Image,
  Dimensions,
  TouchableOpacity,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {
  scale,
  verticalScale,
  moderateScale,
} from '../../constants/const_functions';

/* props:doctorName,day,time */
export default class AppointmentTextView extends Component {
  render() {
    const { height, width } = Dimensions.get('window');
    const { name, gender } = this.props.doctor;
    const { branch, speciality, doctor } = this.props;

    return (
      <TouchableOpacity
        onPress={() => {
          this.props.navigation.navigate('CreateAppointment', {
            doctor,
            speciality,
            branch,
          });
        }}
        style={{
          height: height * 0.13,
          margin: moderateScale(5),
          width: width - 20,
          flexDirection: 'row',
          backgroundColor: '#ffffff',
          elevation: 2,
          borderRadius: 10,
          shadowOffset: { width: 3, height: 3 },
          shadowColor: 'grey',
          shadowOpacity: 0.25,
          shadowRadius: 5,
        }}
      >
        {/* <View
          style={{
            height: height * 0.16,
            margin: moderateScale(5),
            width: width - 20,
            flexDirection: 'row',
            backgroundColor: '#ffffff',
            elevation: 2,
            borderRadius: 10,
          }}
        > */}
        <View
          style={{
            flex: 0.25,
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          <View
            style={{
              width: height * 0.08,
              height: height * 0.08,
              borderRadius: 100,
              overflow: 'hidden',
            }}
          >
            <Image
              source={require('../../assets/customIcons/doc-mike.png')}
              style={{
                width: height * 0.08,
                height: height * 0.08,
                // borderRadius: 200,
              }}
            />
          </View>
        </View>

        <View
          style={{
            justifyContent: 'center',
            width: width - 70,
            flex: 0.75,
          }}
        >
          <View style={{ flex: 0.5, justifyContent: 'center' }}>
            <Text
              style={{ fontSize: moderateScale(19), paddingTop: scale(20) }}
            >
              {name}
            </Text>
          </View>

          <View
            style={{
              flex: 0.5,
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'flex-start',
              paddingTop: verticalScale(18),
            }}
          >
            <View style={{ flex: 0.75 }}>
              <Text style={{ fontSize: moderateScale(15) }}>{name}</Text>
            </View>

            <View style={{ flexDirection: 'row', flex: 0.25 }}>
              <Icon
                name={'gender-' + (gender ? gender : 'male-female')}
                color={
                  gender == 'male'
                    ? 'blue'
                    : gender == 'female'
                    ? 'pink'
                    : 'green'
                }
                size={20}
                style={{ marginRight: moderateScale(2) }}
              />
              <Text
                style={{
                  fontSize: moderateScale(12),
                  marginRight: moderateScale(5),
                }}
              >
                {gender}
              </Text>
            </View>
          </View>
        </View>
        {/* </View> */}
      </TouchableOpacity>
    );
  }
}
