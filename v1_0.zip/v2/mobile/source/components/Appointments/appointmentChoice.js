import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Dimensions,
  Image,
  ScrollView,
  Platform,
  Picker
} from 'react-native';
import { Picker as PickerNative, Icon } from 'native-base';
import Meteor from 'react-native-meteor';

import Header from '../common/header';
import AppointmentTextView from './appointmentTextView';
import { Placeholder } from '../common/placeholder';
import {
  scale,
  verticalScale,
  moderateScale
} from '../../constants/const_functions';

export default class AppointmentChoice extends Component {
  constructor(props) {
    super(props);

    this.state = {
      doctorList: [],
      specialitiesList: [],
      branchList: [],
      chosenValueBranch: undefined,
      chosenValueSpeciality: undefined
    };

    this.fetchBranchNSpecialities();
  }

  fetchBranchNSpecialities() {
    Meteor.call('fetchBranchNSpecialities', (err, res) => {
      if (err) console.log(err);
      if (res) {
        this.setState(res, () => {
          console.log('branch_list:', res);
        });
      }
    });
  }

  fetchDoctorList() {
    const { chosenValueBranch, chosenValueSpeciality } = this.state;
    Meteor.call(
      'fethcDoctorsList',
      chosenValueBranch,
      chosenValueSpeciality,
      (err, res) => {
        if (err) console.log(err);
        if (res) {
          this.setState({ doctorList: res });
        }
      }
    );
  }

  render() {
    const {
      doctorList,
      branchList,
      specialitiesList,
      chosenValueBranch,
      chosenValueSpeciality
    } = this.state;
    console.log(doctorList);

    return (
      <View style={styles.container}>
        <Header
          text='Appointment'
          iconLeft='arrowleft'
          iconRight='shoppingcart'
          navigation={this.props.navigation}
        />

        <View style={styles.textStyle}>
          <Text style={{ fontSize: moderateScale(15) }}>
            Select your doctor's Speciality
          </Text>
        </View>

        <View style={styles.pickerViewStyle}>
          {(Platform.OS == 'android' && (
            <Picker
              style={styles.dropDownViewStyle}
              selectedValue={this.state.chosenValueSpeciality}
              mode='dropdown'
              onValueChange={(itemValue, itemIndex) => {
                this.setState({ chosenValueSpeciality: itemValue }, () => {
                  if (this.state.chosenValueBranch) this.fetchDoctorList();
                });
              }}
            >
              <Picker.Item label='Select speciality' value={undefined} />
              {specialitiesList.map((sp, sl_no) => {
                return (
                  <Picker.Item key={sl_no} label={sp.name} value={sp.name} />
                );
              })}
            </Picker>
          )) || (
            <PickerNative
              style={{
                justifyContent: 'center'
              }}
              placeholder='Select speciality'
              iosIcon={<Icon name='arrow-down' />}
              selectedValue={this.state.chosenValueSpeciality}
              mode='dropdown'
              onValueChange={(itemValue, itemIndex) => {
                this.setState({ chosenValueSpeciality: itemValue }, () => {
                  if (this.state.chosenValueBranch) this.fetchDoctorList();
                });
              }}
            >
              {/* <PickerNative.Item label="Select item" value={undefined} /> */}
              {specialitiesList.map((sp, sl_no) => {
                return (
                  <PickerNative.Item
                    key={sl_no}
                    label={sp.name}
                    value={sp.name}
                  />
                );
              })}
            </PickerNative>
          )}
        </View>

        <View style={styles.textStyle}>
          <Text style={{ fontSize: moderateScale(15) }}>Select the branch</Text>
        </View>

        <View style={styles.pickerViewStyle}>
          {(Platform.OS == 'android' && (
            <Picker
              style={styles.dropDownViewStyle}
              selectedValue={this.state.chosenValueBranch}
              mode='dropdown'
              onValueChange={(itemValue, itemIndex) => {
                this.setState({ chosenValueBranch: itemValue }, () => {
                  if (this.state.chosenValueSpeciality) this.fetchDoctorList();
                });
              }}
            >
              <Picker.Item label='Select branch' value={undefined} />
              {branchList.map((branch, sl_no) => {
                return (
                  <Picker.Item
                    key={sl_no}
                    label={branch.name}
                    value={branch.name}
                  />
                );
              })}
            </Picker>
          )) || (
            <PickerNative
              style={{
                justifyContent: 'center'
              }}
              placeholder='Select branch'
              iosIcon={<Icon name='arrow-down' />}
              selectedValue={this.state.chosenValueBranch}
              mode='dropdown'
              onValueChange={(itemValue, itemIndex) => {
                this.setState({ chosenValueBranch: itemValue }, () => {
                  if (this.state.chosenValueSpeciality) this.fetchDoctorList();
                });
              }}
            >
              {branchList.map((branch, sl_no) => {
                return (
                  <PickerNative.Item
                    key={sl_no}
                    label={branch.name}
                    value={branch.name}
                  />
                );
              })}
            </PickerNative>
          )}
        </View>

        <View style={styles.iconDoctor}>
          <Image
            source={require('../../assets/customIcons/doctor(1).png')}
            style={{ width: moderateScale(20), height: verticalScale(23) }}
          />
          <Text style={{ fontSize: moderateScale(15), paddingLeft: 10 }}>
            {' '}
            Choose Doctor
          </Text>
        </View>

        <View style={styles.allElementsView}>
          <ScrollView
            style={styles.scrollingView}
            contentContainerStyle={{
              justifyContent: 'flex-start',
              alignItems: 'center'
            }}
          >
            {(doctorList.length > 0 &&
              doctorList.map((doc, sl_no) => {
                return (
                  <AppointmentTextView
                    doctor={doc}
                    key={sl_no}
                    speciality={this.state.chosenValueSpeciality}
                    branch={this.state.chosenValueBranch}
                    navigation={this.props.navigation}
                  />
                );
              })) ||
              (chosenValueBranch && chosenValueSpeciality && doctorList.length === 0 && (
                <View
                  style={{
                    justifyContent: 'center',
                    alignItems: 'center',
                    marginTop: 20
                  }}
                >
                  <Image
                    resizeMode='contain'
                    source={require('../../assets/Group_648.png')}
                    style={{ width: 200, height: 200 }}
                  />
                  <Text
                    style={{
                      fontSize: moderateScale(22),
                      textAlign: 'center',
                      color: 'black'
                    }}
                  >
                    No Doctor is Available!
                  </Text>
                  <Text
                    style={{ fontSize: moderateScale(16), textAlign: 'center' }}
                  >
                    No doctor found with speciality in the selected branch
                  </Text>
                </View>
              ))}
            {(!chosenValueBranch || !chosenValueSpeciality) && (
              <View
                style={{
                  justifyContent: 'center',
                  alignItems: 'center',
                  marginTop: 20
                }}
              >
                <Image
                  resizeMode='contain'
                  source={require('../../assets/Group_649.png')}
                  style={{ width: 200, height: 200 }}
                />
                <Text
                  style={{
                    fontSize: moderateScale(22),
                    textAlign: 'center',
                    color: 'black'
                  }}
                >
                  No Branch & Speciality Selected!
                </Text>
                <Text
                  style={{ fontSize: moderateScale(16), textAlign: 'center' }}
                >
                  Please select branch & speciality
                </Text>
              </View>

              // <Placeholder header={'Please select Branch & Speciality'} />
            )}
          </ScrollView>
        </View>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    flex: 1,
    alignItems: 'center'
  },
  smallViewStyle: {
    width: '100%',
    alignItems: 'center'
  },
  pickerViewStyle: {
    width: '94%',
    flex: 0.08,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    elevation: 1,
    backgroundColor: '#ffffff',
    shadowOffset: { width: 3, height: 3 },
    shadowColor: 'grey',
    shadowOpacity: 0.25,
    shadowRadius: 5
  },
  dropDownViewStyle: {
    width: '92%'
  },
  iconDoctor: {
    flex: 0.1,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    width: '94%'
  },
  allElementsView: {
    flex: 0.58,
    justifyContent: 'flex-start',
    width: '100%'
  },
  scrollingView: {
    width: '100%'
  },
  textStyle: {
    flex: 0.08,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    width: '94%'
  }
});
