import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Dimensions,
  Image,
} from 'react-native';

import {
  scale,
  verticalScale,
  moderateScale,
} from '../../constants/const_functions';

export default class DoctorProfile extends Component {
  render() {
    const { height, width } = Dimensions.get('window');
    const { doctor } = this.props;
    return (
      <View style={styles.container}>
        <View style={styles.viewStyle} width={width - 25}>
          <View
            style={{
              height: verticalScale(60),
              margiTop: verticalScale(20),
              marginBottom: verticalScale(20),
            }}
          >
            <View
              style={{
                width: moderateScale(130),
                height: moderateScale(130),
                borderRadius: 100,
                overflow: 'hidden',
                position: 'absolute',
                top: verticalScale(-60),
                left: moderateScale(-65),
              }}
            >
              <Image
                source={require('../../assets/customIcons/doc-mike.png')}
                style={{
                  width: moderateScale(130),
                  height: moderateScale(130),
                  // borderRadius: 100,
                  // position: 'absolute',
                  // top: verticalScale(-60),
                  // left: moderateScale(-65),
                }}
              />
            </View>
          </View>

          <View
            style={{
              width: '100%',
              justifyContent: 'center',
              alignItems: 'center',
              height: 25,
            }}
          >
            <Text style={{ fontSize: moderateScale(20), fontWeight: 'bold' }}>
              {doctor.name}
            </Text>
          </View>

          <View style={styles.partialView}>
            <View style={styles.leftView}>
              <Text
                style={{
                  fontWeight: 'bold',
                  fontSize: moderateScale(16),
                  color: '#1285ff',
                }}
              >
                Speciality:
              </Text>
            </View>
            <View style={styles.rightView}>
              <Text style={{ fontSize: moderateScale(15) }}>
                {doctor.speciality || 'Not given'}
              </Text>
            </View>
          </View>
          <View style={styles.partialView}>
            <View style={styles.leftView}>
              <Text
                style={{
                  fontWeight: 'bold',
                  fontSize: moderateScale(16),
                  color: '#1285ff',
                }}
              >
                Degrees:
              </Text>
            </View>
            <View style={styles.rightView}>
              <Text style={{ fontSize: moderateScale(15) }}>
                {doctor.degrees ? doctor.degrees.toString() : 'Not given'}
              </Text>
            </View>
          </View>
          <View style={styles.partialView}>
            <View style={styles.leftView}>
              <Text
                style={{
                  fontWeight: 'bold',
                  fontSize: moderateScale(16),
                  color: '#1285ff',
                }}
              >
                Experiences:
              </Text>
            </View>
            <View style={styles.rightView}>
              <Text style={{ fontSize: moderateScale(15) }}>
                {doctor.experiences ? doctor.experiences.toString() : 'Not given'}
              </Text>
            </View>
          </View>
        </View>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    justifyContent: 'flex-start',
    alignItems: 'center',
    // flex: 5,
  },
  viewStyle: {
    justifyContent: 'flex-start',
    alignItems: 'center',
    elevation: 2,
    backgroundColor: '#ffffff',
    borderRadius: 5,
    paddingHorizontal: moderateScale(10),
    paddingTop: verticalScale(10),
    paddingBottom: verticalScale(30),
    shadowOffset: { width: 3, height: 3 },
    shadowColor: 'grey',
    shadowOpacity: 0.25,
    shadowRadius: 5,
  },
  partialView: {
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
  },
  leftView: {
    flex: 0.4,
    justifyContent: 'center',
    alignItems: 'flex-end',
  },
  rightView: {
    flex: 0.6,
    paddingLeft: moderateScale(15),
    justifyContent: 'center',
    alignItems: 'flex-start',
    paddingBottom: verticalScale(5),
  },
});
