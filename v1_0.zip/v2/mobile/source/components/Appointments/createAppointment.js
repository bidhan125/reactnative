import React, { Component } from 'react';
import {
  Alert,
  Platform,
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  Picker,
  ScrollView,
  Dimensions
} from 'react-native';

import { Icon as IconEl } from 'react-native-elements';
import Header from '../common/header';
import DatePicker from 'react-native-datepicker';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Button from '../common/lifeplusGreenButton';
import Profile from './doctorProfile';
import Meteor from 'react-native-meteor';
import moment from 'moment';
import SnackBar from 'react-native-snackbar-component';

import SpinView from '../common/spinner';
import { getUserAsync } from '../../constants/const_functions';
import {
  scale,
  verticalScale,
  moderateScale
} from '../../constants/const_functions';

export default class CreateAppointment extends Component {
  constructor(props) {
    super(props);

    this.state = {
      chosenBeneficiary: undefined,
      date: undefined,
      time: undefined,
      patient: undefined,
      bList: [],
      showSnack: false,
      checked: {},
      beneficiaryList: [],
      processing: false
    };

    this.fetchBeneficiary();

    this.snck = this.showSnack;
  }

  async fetchBeneficiary() {
    const user = JSON.parse(await getUserAsync());
    console.log(user);
    Meteor.call('fetchBeneficiary', user._id, (err, res) => {
      console.log(err, res);
      if (err) {
        alert(
          'Sorry! Failed to fetch beneficiary list. Please try again later'
        );
      }
      if (res) {
        this.setState({ user, bList: res });
        let temp = this.state.bList.unshift(user.profile);
        this.setState({ bList: [...this.state.bList] });
      }
    });
  }

  showSnack() {
    return (
      <SnackBar
        visible={true}
        textMessage='The beneficiary has been added.'
        actionHandler={() => {
          this.setState({ showSnack: !this.state.showSnack });
        }}
        actionText='Ok'
        position='bottom'
        autoHidingTime={1000}
      />
    );
  }

  calculateAge(dob) {
    if (!dob) return undefined;
    const today = moment();
    const dob_m = moment(dob);
    console.log(dob, today.diff(dob_m, 'years'));

    return today.diff(dob_m, 'years');
  }

  handleSubmit() {
    const chosenBeneficiary = this.state.chosenBeneficiary;
    const doctor = this.props.navigation.getParam('doctor', {
      id: undefined,
      name: undefined
    });
    const branch = this.props.navigation.getParam('branch', {
      id: undefined,
      name: undefined
    });
    const speciality = this.props.navigation.getParam('speciality', {});
    let patient = {};
    if (chosenBeneficiary === undefined) {
      alert('Please select beneficiary.');
      return;
    } else if (chosenBeneficiary > 0) {
      const { name, address, phone, gender, dob } = this.state.bList[
        chosenBeneficiary
      ];
      patient = {
        ...patient,
        name,
        address,
        gender,
        phone,
        age: this.calculateAge(dob)
      };
    } else {
      const { name, address, phone, gender, dob } = this.state.user.profile;
      patient = {
        ...patient,
        name,
        address,
        gender,
        phone,
        age: this.calculateAge(dob)
      };
    }

    if (this.state.date === undefined) {
      alert('Please select appointment date!');
      return;
    }
    if (this.state.time === undefined) {
      alert('Please select appointment time!');
      return;
    }

    const phone = Meteor.user().profile.phone;

    const data = {
      doctor,
      branch,
      speciality,
      patient,
      phone,
      isBeneficiary: chosenBeneficiary > 0,
      time: new Date(this.state.date + 'T' + this.state.time)
    };

    if (data.time.getTime() <= new Date().getTime()) {
      alert('Please enter a valid time for appointment');
      return;
    }
    this.setState({ processing: true });

    Meteor.call('add.appointment', data, (err, res) => {
      console.log(err, res);
      this.setState({ processing: false });
      if (err) alert('Unfortunately appointment failed to submit');
      if (res) {
        Alert.alert(
          'Success',
          'Dear lifePlus user, your appointment has been received. We will notify your appointment date and time. ---Please Note, Appointment may very + or - One day',
          [
            {
              text: 'Ok',
              onPress: () => this.props.navigation.navigate('Home'),
              style: 'ok'
            }
          ],
          { cancelable: false }
        );
      }
    });
  }

  handleBeneficiary(item, index, selecTedItems) {
    this.setState(
      (state, props) => {
        return {
          showSnack: true,
          checked: {
            [index]: true
          },
          chosenBeneficiary: index
        };
      },
      () => {
        console.log('index:', this.state.chosenBeneficiary);
        const beneList = [];
        for (let index in this.state.checked) {
          if (this.state.checked[index]) {
            beneList.push(this.state.bList[index]);
          }
        }
        this.setState({ beneficiaryList: [...beneList] });
      }
    );

    setTimeout(() => {
      this.setState({
        showSnack: false
      });
    }, 1500);
  }

  render() {
    const { height, width } = Dimensions.get('window');
    const doctor = this.props.navigation.getParam('doctor', {});

    const { bList, user } = this.state;
    var newList = [
      <TouchableOpacity
        onPress={() => this.props.navigation.navigate('BeneficiaryCreate')}
        style={styles.cardView}
      >
        {/* <View style={styles.cardView}> */}
        <IconEl name='plus' type='font-awesome' color='#707070' />
        <Text style={styles.cardName}>Add New</Text>
        {/* </View> */}
      </TouchableOpacity>
    ];
    bList.map((item, sl_no) => {
      newList.push(
        <TouchableOpacity
          onPress={() => this.handleBeneficiary(item.name, sl_no)}
          style={
            this.state.checked[sl_no]
              ? styles.selectedCardView
              : styles.cardView
          }
        >
          {/* <View
            style={
              this.state.checked[sl_no]
                ? styles.selectedCardView
                : styles.cardView
            }
          > */}
          <Text
            style={
              this.state.checked[sl_no] ? styles.cardSelected : styles.cardName
            }
          >
            {sl_no === 0 ? 'For me' : item.name}
          </Text>
          <Text
            style={
              this.state.checked[sl_no]
                ? styles.selectedRelationText
                : styles.relationText
            }
          >
            {item.relation}
          </Text>
          {/* </View> */}
        </TouchableOpacity>
      );
    });

    if (this.state.processing) {
      return <SpinView />;
    }

    return (
      <View style={styles.container}>
        <Header
          text='Appoinment'
          iconLeft='arrowleft'
          iconRight='shoppingcart'
          navigation={this.props.navigation}
        />
        {this.state.showSnack && this.snck()}
        <View style={styles.mainViewStyle}>
          <ScrollView
            style={styles.scrollStyle}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{
              alignItems: 'center',
              justifyContent: 'flex-start',
              height: verticalScale(650)
            }}
          >
            <View style={styles.textViewStyle}>
              <Text style={{ fontSize: moderateScale(16), fontWeight: 'bold' }}>
                Select the beneficiary:
              </Text>
            </View>

            <View style={styles.pickerViewStyle}>
              <ScrollView
                horizontal={true}
                showsHorizontalScrollIndicator={false}
              >
                {newList}
              </ScrollView>
            </View>

            <View style={styles.datePickerStyle} height={height * 0.15}>
              <DatePicker
                style={{ flex: 0.45 }}
                date={this.state.date}
                mode='date'
                placeholder='Select Date'
                format='YYYY-MM-DD'
                confirmBtnText='Confirm'
                cancelBtnText='Cancel'
                minDate={new Date()}
                onDateChange={date => {
                  this.setState({ date });
                }}
                customStyles={{
                  dateIcon: {
                    position: 'absolute',
                    left: 0,
                    top: 4,
                    marginLeft: 0
                  },
                  dateInput: {
                    marginLeft: moderateScale(36),
                    borderRadius: 10
                  }
                }}
              />

              <View
                style={{
                  flex: 0.48,
                  height: height * 0.15,
                  alignItems: 'center',
                  flexDirection: 'row',
                  justifyContent: 'flex-start'
                }}
              >
                <View style={{ flex: 0.3, alignItems: 'center' }}>
                  <Icon name='clock-outline' color='crimson' size={38} />
                </View>

                <DatePicker
                  style={{ flex: 0.7 }}
                  showIcon={false}
                  date={this.state.time}
                  mode='time'
                  minDate={new Date()}
                  confirmBtnText='Confirm'
                  cancelBtnText='Cancel'
                  placeholder='Select Time'
                  format='HH:mm'
                  is24Hour={false}
                  onDateChange={time => {
                    this.setState({ time });
                  }}
                  customStyles={{
                    dateInput: { borderRadius: 10 }
                  }}
                />
              </View>
            </View>

            <View style={styles.profileViewStyle}>
              <Profile doctor={doctor} />
            </View>
            <Button
              buttonLength='94%'
              buttonText='Confirm'
              buttonFont={20}
              passFunction={() => this.handleSubmit()}
            />
          </ScrollView>
        </View>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center'
  },
  textViewStyle: {
    width: '94%',
    justifyContent: 'center',
    alignItems: 'flex-start',
    marginBottom: verticalScale(10)
  },
  datePickerStyle: {
    flexDirection: 'row',
    width: '94%',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  mainViewStyle: {
    flex: 1,
    width: '100%',
    justifyContent: 'flex-start',
    alignItems: 'center'
  },
  scrollStyle: {
    flex: 1,
    width: '100%',
    marginTop: verticalScale(10),
    paddingTop: verticalScale(10)
  },
  profileViewStyle: {
    paddingTop: verticalScale(30),
    width: '100%',
    paddingBottom: verticalScale(20)
  },
  buttonViewStyle: {
    width: '100%',
    justifyContent: 'flex-start',
    alignItems: 'center',
    paddingTop: verticalScale(40)
  },
  pickerViewStyle: {
    height: verticalScale(90),
    marginLeft: moderateScale(7),
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10
  },

  cardView: {
    flex: 1,
    width: moderateScale(110),
    height: verticalScale(70),
    elevation: 3,
    backgroundColor: 'white',
    marginRight: moderateScale(10),
    marginTop: verticalScale(5),
    marginBottom: verticalScale(5),
    marginLeft: 5,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    shadowOffset: { width: 3, height: 3 },
    shadowColor: 'grey',
    shadowOpacity: 0.25,
    shadowRadius: 5
  },

  cardName: {
    fontWeight: 'bold',
    fontSize: moderateScale(15),
    textAlign: 'center'
  },

  selectedCardView: {
    flex: 1,
    width: moderateScale(110),
    height: verticalScale(70),
    borderWidth: 2,
    borderColor: '#0076BE',
    backgroundColor: 'white',
    marginRight: moderateScale(10),
    marginTop: verticalScale(10),
    marginBottom: verticalScale(10),
    marginLeft: 5,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center'
  },

  cardSelected: {
    color: '#0076BE',
    fontWeight: 'bold',
    fontSize: moderateScale(15),
    textAlign: 'center'
  },

  selectedRelationText: {
    fontSize: moderateScale(13),
    color: '#0076BE'
  },

  relationText: {
    fontSize: moderateScale(13)
  }
});
