import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Image,
  Dimensions,
  TouchableOpacity,
} from 'react-native';
// import Icon from 'react-native-vector-icons';
import { Icon } from 'react-native-elements';

import {
  scale,
  verticalScale,
  moderateScale,
} from '../../constants/const_functions';

export default class AppointmentField extends Component {
  render() {
    var status = this.props.status;
    status = status.charAt(0).toUpperCase() + status.slice(1);
    const displayWidth = Dimensions.get('window').width;
    const displayHeight = Dimensions.get('window').height;
    let h = displayHeight * 0.15;
    let w = displayWidth * 0.94;

    return (
      <TouchableOpacity onPress={this.props.onPress} style={styles.container}>
        {/* <View style={styles.container} height={h} width={w}> */}
        <View style={styles.imageViewStyle}>
          <View
            style={{
              width: moderateScale(50),
              height: moderateScale(50),
              borderRadius: 100,
              overflow: 'hidden',
            }}
          >
            <Image
              source={require('../../assets/customIcons/doc.png')}
              style={{
                width: moderateScale(50),
                height: moderateScale(50),
                // borderRadius: 150,
              }}
            />
          </View>
        </View>
        <View
          style={{
            flex: 0.5,
            justifyContent: 'center',
            alignItems: 'flex-start',
          }}
        >
          <View style={{ flex: 0.36, justifyContent: 'center' }}>
            <Text style={{ fontSize: moderateScale(15), fontWeight: 'bold' }}>
              {this.props.doctorName}
            </Text>
          </View>
          <View style={{ flex: 0.22 }}>
            <Text style={{ fontSize: moderateScale(14) }}>
              {displayWidth < 412
                ? this.props.branch.substring(0, 18)
                : this.props.branch}
            </Text>
          </View>
          <View
            style={{
              flex: 0.22,
              flexDirection: 'row',
              justifyContent: 'flex-start',
              alignItems: 'center',
            }}
          >
            <Icon name="calendar" type="antdesign" size={moderateScale(15)} />
            <Text
              style={{
                fontSize: moderateScale(12),
                paddingLeft: moderateScale(5),
              }}
            >
              {this.props.date}
            </Text>
          </View>
        </View>
        <View
          style={{
            flex: 0.25,
            justifyContent: 'center',
            alignItems: 'flex-start',
            paddingRight: moderateScale(5),
          }}
        >
          <View style={{ flex: 0.36 }} />
          <View
            style={{
              flex: 0.22,
              flexDirection: 'row',
              justifyContent: 'flex-start',
              alignItems: 'center',
            }}
          >
            {this.props.status === 'pending' && (
              <Icon
                name="exclamationcircleo"
                type="antdesign"
                color="blue"
                size={moderateScale(15)}
              />
            )}
            {this.props.status === 'approved' && (
              <Icon
                name="checkcircleo"
                type="antdesign"
                color="green"
                size={moderateScale(15)}
              />
            )}
            {this.props.status === 'rejected' && (
              <Icon
                name="closecircleo"
                type="antdesign"
                color="red"
                size={moderateScale(15)}
              />
            )}
            {this.props.status === 'cancelled' && (
              <Icon
                name="cancel"
                type="material-community"
                color="red"
                size={moderateScale(16)}
              />
            )}
            

            <Text
              style={{
                fontSize: moderateScale(12),
                paddingLeft: moderateScale(5),
              }}
            >
              {status}
            </Text>
          </View>
          <View
            style={{
              flex: 0.22,
              flexDirection: 'row',
              justifyContent: 'flex-start',
              alignItems: 'center',
            }}
          >
            <Icon
              name="clockcircleo"
              type="antdesign"
              size={moderateScale(15)}
            />
            <Text
              style={{
                fontSize: moderateScale(12),
                paddingLeft: moderateScale(5),
              }}
            >
              {this.props.time}
            </Text>
          </View>
        </View>
        {/* </View> */}
      </TouchableOpacity>
    );
  }
}

const displayWidth = Dimensions.get('window').width;
const displayHeight = Dimensions.get('window').height;
let h = displayHeight * 0.15;
let w = displayWidth * 0.94;

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    flexDirection: 'row',
    borderRadius: 10,
    elevation: 2,
    marginTop: moderateScale(5),
    marginBottom: moderateScale(5),
    marginLeft: moderateScale(10),
    marginRight: moderateScale(10),
    width: w,
    height: h,
    shadowOffset: { width: 3, height: 3 },
    shadowColor: 'grey',
    shadowOpacity: 0.25,
    shadowRadius: 5,
  },
  imageViewStyle: {
    justifyContent: 'center',
    alignItems: 'center',
    flex: 0.25,
  },
});
