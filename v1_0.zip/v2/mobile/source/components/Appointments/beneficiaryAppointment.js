import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  Picker,
  ScrollView,
  FlatList,
  Dimensions,
  ToastAndroid
} from 'react-native';
import Meteor, { withTracker } from 'react-native-meteor';
import moment from 'moment';
import Spinner from 'react-native-spinkit';

import SpinView from '../common/spinner';
import AppointmentField from './appointmentField';
import AppointmentDetailsModal from './appointmentDetailsModal';
import {
  scale,
  verticalScale,
  moderateScale,
  getUserAsync
} from '../../constants/const_functions';

page_size = 10;
const { width, height } = Dimensions.get('window');

export default class BeneficiaryAppointment extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isModalVisible: false,
      modalProperty: {},
      isLoaded: false,
      list: [],
      activePage: 1,
      totalPages: 1,
      uid: undefined,
      isDateVisible: false,
      date: undefined,
      time: undefined
    };

    this.fetchUser();
  }

  async fetchUser() {
    const user = JSON.parse(await getUserAsync());
    console.log(user);
    this.setState(
      {
        uid: user._id
      },
      () => {
        this.fetchAppointment();
        this.fetchTotalAppointmentCount();
      }
    );
  }

  fetchTotalAppointmentCount() {
    const { uid } = this.state;
    Meteor.call(
      'fetchBAppointmentCount',
      { uid, isBeneficiary: true },
      (err, res) => {
        // console.log(err, res);
        if (err)
          alert('Failed to fetch appointment count, please try again later');
        else if (res) this.setState({ totalPages: Math.ceil(res / page_size) });
      }
    );
  }

  fetchAppointment() {
    const { activePage, list, uid } = this.state;
    console.log(uid, activePage);
    Meteor.call(
      'fetchAppointment',
      { uid, isBeneficiary: true, page_no: activePage },
      (err, res) => {
        // console.log(err, res);
        if (err) alert('Unfortunately failed to fetch  More Appointment.');
        else if (res) {
          this.setState({
            list: list.concat(res),
            isLoaded: true,
            activePage: activePage + 1,
            isLoadingMore: false
          });
        }
      }
    );
  }

  updateAppointment(param) {
    const { id } = this.state;

    if (param === 'time') {
      var time = new Date(this.state.date + 'T' + this.state.time);
    } else {
      var status = 'cancelled';
    }

    this.setState({ isLoaded: false });
    Meteor.call('updateAppointment', { id, status, time }, (err, res) => {
      console.log(err, res);
      if (err) {
        console.log(err);
      } else {
        this.setState(
          { isModalVisible: false, isLoaded: true, activePage: 1, list: [] },
          () => this.fetchAppointment()
        );
        if (param === 'time') {
          alert('Your appointment updated successfuly!');
        } else alert('Your appointment cancelled successfuly!');
      }
    });
  }

  setModalProperty(sl_no) {
    const { list } = this.state;
    if (list[sl_no].hasOwnProperty('relation')) {
      relation = list[sl_no].hasOwnProperty('relation');
    } else {
      relation = 'not given';
    }
    return this.setState({
      isModalVisible: !this.state.isModalVisible,
      id: list[sl_no]._id,
      status: list[sl_no].status,
      modalProperty: {
        doctorName: list[sl_no].doctor['name'],
        speciality: list[sl_no].doctor['speciality'],
        branch: list[sl_no].branch,
        status: list[sl_no].status,
        patientName: list[sl_no].patient['name'],
        date: moment(list[sl_no].time).format('MMM Do YYYY'),
        time: moment(list[sl_no].time).format('h:mm a'),
        isBeneficiary: list[sl_no].isBeneficiary,
        relation: relation
      }
    });
  }

  updateState(obj) {
    this.setState(obj);
  }

  handlePaginate() {
    const { activePage, totalPages } = this.state;
    this.setState({ isLoadingMore: true });

    if (activePage <= totalPages) {
      this.fetchAppointment();
    } else {
      this.setState({ isLoadingMore: false });
      if (activePage !== 2)
        ToastAndroid.show('You are at the end of list.', ToastAndroid.SHORT);
    }
  }

  render() {
    const { list } = this.state;
    console.log(this.props);
    if (!this.state.isLoaded) return <SpinView />;
    if (this.state.list.length <= 0) {
      return (
        <View
          style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}
        >
          <View
            style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}
          >
            <Image
              source={require('../../assets/empytPageIcon/Group_644.png')}
              style={{ width: 150, height: 150 }}
              resizeMode='contain'
            />
            <Text style={{ fontSize: moderateScale(22) }}>No Appointment!</Text>
            <Text style={{ fontSize: moderateScale(16), textAlign: 'center' }}>
              Lets create your first Beneficiary appointment. Shall we?
            </Text>
          </View>
        </View>
      );
    }
    return (
      <View
        style={{
          flex: 1,
          justifyContent: 'flex-start',
          alignItems: 'center'
        }}
      >
        <AppointmentDetailsModal
          visibilityStateName='isModalVisible'
          visibility={this.state.isModalVisible}
          updateState={this.updateState.bind(this)}
          modalProperty={this.state.modalProperty}
          isDateVisible={this.state.isDateVisible}
          date={this.state.date}
          time={this.state.time}
          updateAppointment={this.updateAppointment.bind(this)}
        />
        <FlatList
          onEndReached={(info: { distanceFromEnd: number }) => {
            this.handlePaginate();
          }}
          onEndReachedThreshold={0.2}
          style={{ width: width }}
          data={list}
          renderItem={({ item, index }) => (
            <AppointmentField
              onPress={() => this.setModalProperty(index)}
              key={index}
              item={item}
              navigation={this.props.navigation}
              doctorName={item.doctor['name']}
              branch={item.branch}
              status={item.status}
              date={moment(item.time).format('MMM Do YYYY')}
              time={moment(item.time).format('h:mm a')}
            />
          )}
        />
        {this.state.isLoadingMore && (
          <View style={{ position: 'relative', bottom: 20 }}>
            <Spinner
              type='ThreeBounce'
              isVisible={this.state.isLoadingMore}
              size={50}
              color='grey'
            />
          </View>
        )}
      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center'
  },
  dropDownViewStyle: {
    flex: 0.1,
    width: '94%'
  },
  textViewStyle: {
    flex: 0.08,
    width: '94%',
    justifyContent: 'center',
    alignItems: 'flex-start'
  },
  mainViewStyle: {
    flex: 1,
    width: '100%',
    justifyContent: 'flex-start',
    alignItems: 'center'
  },
  buttonViewStyle: {
    height: verticalScale(100),
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center'
  }
});
