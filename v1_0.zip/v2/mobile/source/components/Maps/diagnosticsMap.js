import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, Dimensions } from 'react-native';
// import {MapView,Marker, PROVIDER_GOOGLE,  } from 'react-native-maps';

const displayWidth = Dimensions.get('window').width;
const displayHeight = Dimensions.get('window').height;

const ASPECT_RATIO = displayWidth / displayHeight;
const LATITUDE = 37.78825;
const LONGITUDE = -122.4324;
const LATITUDE_DELTA = 0.0922;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;

// export default class DiagnosticsMap extends Component {
//     constructor(props) {
//         super(props);
//         this.state = {
//           region: {
//             latitude: LATITUDE,
//             longitude: LONGITUDE,
//             latitudeDelta: LATITUDE_DELTA,
//             longitudeDelta: LONGITUDE_DELTA,
//           },
//         };
//       }

//     render() {

//         return (

//             <View style={styles.container}>
//                  <MapView
//                         provider={PROVIDER_GOOGLE}
//                         style={styles.map}
//                         scrollEnabled={false}
//                         zoomEnabled={false}
//                         pitchEnabled={false}
//                         rotateEnabled={false}
//                         initialRegion={this.state.region}
//                  >

//                 </MapView>

//             </View>

//         );
//       }
//     }

//     var styles = StyleSheet.create({
//         container:{
//             flex:1,
//         },
//         map: {
//             width: 250,
//             height: 250,
//           },

//       })
