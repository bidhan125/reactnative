import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Dimensions,
  TextInput,
  Picker,
  Keyboard,
  KeyboardAvoidingView,
  ScrollView,
  Alert
} from 'react-native';
import {
  Item,
  Input,
  Picker as PickerNative,
  Icon as IconNative
} from 'native-base';
import Meteor from 'react-native-meteor';
import moment from 'moment';
import DatePicker from 'react-native-datepicker'

import Header from '../common/header';
import { CheckBox, Button, Icon } from 'react-native-elements';

import SpinView from '../common/spinner';
import { relations, blood_group } from '../../constants/const_strings';
import {
  validation,
  moderateScale,
  verticalScale
} from '../../constants/const_functions';

export default class BeneficiaryCreate extends Component {
  constructor(props) {
    super(props);
    const { navigation } = this.props;
    const dob = this.props.navigation.getParam('dob');
    // const day = moment(dob).format('DD');
    // const m = moment(dob).format('Mo');
    // const month = m.slice(0, m.length - 2);
    // const year = moment(dob).format('YYYY');
    console.log(navigation.getParam('name'));
    this.state = {
      id: navigation.getParam('id'),
      name: navigation.getParam('name'),
      gender: navigation.getParam('gender'),
      relation: navigation.getParam('relation'),
      height: navigation.getParam('height'),
      weight: navigation.getParam('weight'),
      bloodGroup: navigation.getParam('bloodGroup'),
      date: this.props.navigation.getParam('dob'),
      isUpdate: navigation.getParam('isUpdate'),
      processing: false,
      // day: day,
      // month: month,
      // year: year
    };

    this.inputs = {};
    this.focusNextField = this.focusNextField.bind(this);
  }

  focusNextField(id) {
    this.inputs[id].wrappedInstance.focus();
  }

  handleSubmit() {
    const {
      name,
      gender,
      relation,
      height,
      weight,
      bloodGroup,
      // day,
      // month,
      // year
      date
    } = this.state;

    const data = {
      name,
      gender,
      relation,
      height,
      weight,
      bloodGroup,
      // dob: new Date(year + '-' + month + '-' + day)
      dob: date
    };

    // console.log(day, month, year);
    // console.log(data.dob);

    if (validation(name, 'isName') !== true) return;

    // if (validation(data.dob, 'isDob') !== true) return;

    if (gender === undefined) {
      alert('Please select gender');
      return;
    }

    if (relation === undefined) {
      alert('Please select your relation with beneficiary!');
      return;
    }

    if (height === undefined) {
      alert('Please give a valid height');
      return;
    }

    if (weight === undefined) {
      alert('Please give a valid weight');
      return;
    }

    if (bloodGroup === undefined) {
      alert('Please select a blood group!');
      return;
    }

    this.setState({ processing: true });

    if (this.state.isUpdate) {
      console.log('update function called');
      const updateData = {
        ...data,
        id: this.state.id
      };
      console.log(updateData);
      Meteor.call('updateBeneficiary', updateData, (error, success) => {
        console.log(error, success);
        this.setState({ processing: false });
        if (error) {
          console.log('error', error);
        }
        if (success) {
          Alert.alert(
            'Success',
            'Congratulations! Beneficiary updated successfully! Thank you!',
            [
              {
                text: 'Ok',
                onPress: () =>
                  this.props.navigation.navigate('MyBeneficiaries', {
                    isReload: true
                  })
              }
            ],
            { cancelable: false }
          );
        }
      });
    } else {
      Meteor.call('addBeneficiary', data, (error, success) => {
        console.log(error, success);
        this.setState({ processing: false });
        if (error) {
          console.log('error', error);
        }
        if (success) {
          Alert.alert(
            'Success',
            'Congratulations! Beneficiary created successfully! Thank you!',
            [
              {
                text: 'Ok',
                onPress: () =>
                  this.props.navigation.navigate('MyBeneficiaries', {
                    isReload: true
                  })
              }
            ],
            { cancelable: false }
          );
        }
      });
    }
  }

  render() {
    const isUpdate = this.state.isUpdate;
    const dob = this.props.navigation.getParam('dob');
    // const month = moment(dob).format('Mo');
    // console.log(month);
    // console.log(month.slice(0, month.length - 2));

    if (this.state.processing) {
      return <SpinView />;
    }
    return (
      <KeyboardAvoidingView style={styles.container}>
        <Header
          text={isUpdate ? 'Update Beneficiary' : 'Create Beneficiary'}
          iconLeft='arrowleft'
          iconRight='shoppingcart'
          navigation={this.props.navigation}
        />
        <ScrollView showsVerticalScrollIndicator={false}>
          <View style={styles.viewStyle}>
            <View style={styles.insideViewStyle}>
              <View style={styles.nameViewStyle}>
                <TextInput
                  style={{
                    height: verticalScale(45),
                    borderColor: 'gray',
                    borderBottomWidth: 1,
                    fontSize: moderateScale(16),
                    marginTop: verticalScale(15)
                  }}
                  value={this.state.name}
                  editable={true}
                  onChangeText={name => this.setState({ name })}
                  placeholder='Name'
                  onSubmitEditing={() => this.refs.height.focus()}
                  returnKeyType='next'
                />
              </View>
              <View style={styles.genderViewStyle}>
                <Text
                  style={{
                    fontSize: moderateScale(16),
                    fontWeight: 'bold',
                    color: '#777777'
                  }}
                >
                  Gender
                </Text>
                <CheckBox
                  title='Male'
                  checked={this.state.gender == 'Male'}
                  containerStyle={styles.checkBoxStyle}
                  onPress={() => this.setState({ gender: 'Male' })}
                />

                <CheckBox
                  title='Female'
                  checked={this.state.gender == 'Female'}
                  containerStyle={styles.checkBoxStyle}
                  onPress={() => this.setState({ gender: 'Female' })}
                />
              </View>
              <View style={styles.relationViewStyle}>
                {(Platform.OS == 'android' && (
                  <Picker
                    style={{ fontSize: moderateScale(16) }}
                    selectedValue={this.state.relation}
                    mode='dropdown'
                    onValueChange={(itemValue, itemIndex) =>
                      this.setState({ relation: itemValue })
                    }
                  >
                    <Picker.Item label='Beneficiary Relation' value='key0' />
                    {relations.map((item, sl) => (
                      <Picker.Item label={item} value={item} />
                    ))}
                  </Picker>
                )) || (
                  <PickerNative
                    style={{ fontSize: moderateScale(16) }}
                    iosIcon={<IconNative name='arrow-down' />}
                    selectedValue={this.state.relation}
                    mode='dropdown'
                    onValueChange={(itemValue, itemIndex) =>
                      this.setState({ relation: itemValue })
                    }
                  >
                    <PickerNative.Item
                      label='Beneficiary Relation'
                      value={undefined}
                    />
                    {relations.map((item, sl) => (
                      <PickerNative.Item label={item} value={item} />
                    ))}
                  </PickerNative>
                )}
              </View>

              <View style={styles.specsViewStyle} flex={18} alignItems='center'>
                <View style={styles.smallViewStyle} justifyContent='flex-start'>
                  <View style={{ flex: 0.76 }}>
                    <TextInput
                      ref='height'
                      style={{
                        height: verticalScale(45),
                        borderColor: 'gray',
                        borderBottomWidth: 1,
                        fontSize: moderateScale(16)
                      }}
                      value={this.state.height}
                      editable={true}
                      onChangeText={height => this.setState({ height })}
                      placeholder='Height'
                      keyboardType='numeric'
                      multiline={false}
                      onSubmitEditing={() => this.refs.weight.focus()}
                      returnKeyType='next'
                    />
                  </View>
                  <View style={{ flex: 0.16 }}>
                    <Text style={{ fontWeight: 'bold', fontSize: 13 }}>FT</Text>
                  </View>
                </View>
                <View style={styles.smallViewStyle} justifyContent='flex-end'>
                  <View style={{ flex: 0.76 }}>
                    <TextInput
                      ref='weight'
                      style={{
                        height: verticalScale(45),
                        borderColor: 'gray',
                        borderBottomWidth: 1,
                        fontSize: moderateScale(16)
                      }}
                      value={this.state.weight}
                      editable={true}
                      onChangeText={weight => this.setState({ weight })}
                      placeholder='Weight'
                      keyboardType='numeric'
                      multiline={false}
                      returnKeyType='done'
                      // onSubmitEditing={() => {
                      //   this.focusNextField('five');
                      // }}
                    />
                  </View>
                  <View style={{ flex: 0.16 }}>
                    <Text style={{ fontWeight: 'bold', fontSize: 13 }}>KG</Text>
                  </View>
                </View>
              </View>

              <View
                style={{
                  flex: 20,
                  width: '100%',
                  borderBottomWidth: 1,
                  alignContent: 'flex-end',
                  borderBottomColor: 'grey',
                  marginTop: verticalScale(5)
                }}
              >
                {(Platform.OS == 'android' && (
                  <Picker
                    // style={{ color: 'blue' }}
                    selectedValue={this.state.bloodGroup}
                    mode='dropdown'
                    onValueChange={(itemValue, itemIndex) =>
                      this.setState({ bloodGroup: itemValue })
                    }
                  >
                    <Picker.Item label='Blood group' value={undefined} />
                    {blood_group.map(item => (
                      <Picker.Item label={item} value={item} />
                    ))}
                  </Picker>
                )) || (
                  <PickerNative
                    // style={{ color: 'blue' }}
                    iosIcon={<IconNative name='arrow-down' />}
                    selectedValue={this.state.bloodGroup}
                    mode='dropdown'
                    onValueChange={(itemValue, itemIndex) =>
                      this.setState({ bloodGroup: itemValue })
                    }
                  >
                    <PickerNative.Item label='Blood group' value={undefined} />
                    {blood_group.map(item => (
                      <PickerNative.Item label={item} value={item} />
                    ))}
                  </PickerNative>
                )}
              </View>

              <View
                style={{
                  width: '100%',
                  height: verticalScale(50),
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  marginBottom: 5
                }}
              >
                <View style={{ justifyContent: 'flex-start' }}>
                  <Text style={styles.appointmentCalendarText}>
                    Date of Birth:
                  </Text>
                </View>
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                  <DatePicker
                    date={this.state.date}
                    mode='date'
                    format='YYYY-MM-DD'
                    placeholder='Select date'
                    maxDate={new Date()}
                    onDateChange={date => {
                      this.setState({ date: date });
                    }}
                    iconComponent={<Icon name='calendar' type='antdesign' />}
                    customStyles={{
                      dateIcon: {
                      },

                      dateInput: {
                        borderWidth: 0
                      }
                    }}
                  />
                  {/* <Item regular style={styles.itemShortDoB}>
                    <Input
                      placeholderTextColor='#B6B2B2'
                      placeholder='DD'
                      value={this.state.day}
                      editable={true}
                      maxLength={2}
                      onChangeText={day => this.setState({ day })}
                      keyboardType='numeric'
                      blurOnSubmit={false}
                      onSubmitEditing={() => {
                        this.focusNextField('six');
                      }}
                      returnKeyType='next'
                      ref={input => {
                        this.inputs['five'] = input;
                      }}
                    />
                  </Item>
                  <Text style={{ fontSize: 20, color: '#464646' }}>-</Text>
                  <Item regular style={[styles.itemShortDoB, { width: 50 }]}>
                    <Input
                      placeholderTextColor='#B6B2B2'
                      placeholder='MM'
                      value={this.state.month}
                      editable={true}
                      maxLength={2}
                      onChangeText={month => this.setState({ month })}
                      keyboardType='numeric'
                      blurOnSubmit={false}
                      onSubmitEditing={() => {
                        this.focusNextField('seven');
                      }}
                      returnKeyType='next'
                      ref={input => {
                        this.inputs['six'] = input;
                      }}
                    />
                  </Item>
                  <Text style={{ fontSize: 20, color: '#464646' }}>-</Text>
                  <Item regular style={[styles.itemShortDoB, { width: 60 }]}>
                    <Input
                      placeholderTextColor='#B6B2B2'
                      placeholder='YYYY'
                      value={this.state.year}
                      editable={true}
                      maxLength={4}
                      onChangeText={year => this.setState({ year })}
                      keyboardType='numeric'
                      blurOnSubmit={false}
                      onSubmitEditing={() => {
                        Keyboard.dismiss();
                      }}
                      returnKeyType='done'
                      ref={input => {
                        this.inputs['seven'] = input;
                      }}
                    />
                  </Item> */}
                </View>
              </View>
            </View>
          </View>

          <View
            style={{
              flex: 0.2,
              width: '100%',
              justifyContent: 'center',
              alignItems: 'center',
              marginTop: verticalScale(3)
            }}
          >
            {(isUpdate && (
              <Button
                title='Update'
                containerStyle={{ width: '93%' }}
                buttonStyle={{ backgroundColor: '#60BB46', borderRadius: 10 }}
                titleStyle={{ fontSize: moderateScale(20) }}
                onPress={() => this.handleSubmit()}
              />
            )) || (
              <Button
                title='Create'
                containerStyle={{ width: '93%' }}
                buttonStyle={{ backgroundColor: '#60BB46', borderRadius: 10 }}
                titleStyle={{ fontSize: moderateScale(20) }}
                onPress={() => this.handleSubmit()}
              />
            )}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    );
  }
}

var styles = StyleSheet.create({
  appointmentCalendarText: {
    color: '#777777',
    fontSize: moderateScale(15),
    margin: 0
  },
  itemShortDoB: {
    width: 45,
    height: 40,
    backgroundColor: 'transparent',
    borderColor: '#FFF',
    marginLeft: 0
  },
  container: {
    backgroundColor: '#ffffff',
    flex: 1
  },
  viewStyle: {
    backgroundColor: '#ffffff',
    elevation: 2,
    flex: 0.8,
    margin: 10,
    alignItems: 'center',
    borderRadius: 10,
    shadowOffset: { width: 3, height: 3 },
    shadowColor: 'grey',
    shadowOpacity: 0.25,
    shadowRadius: 5
  },
  insideViewStyle: {
    flex: 1,
    width: '90%',
    alignItems: 'center'
  },
  nameViewStyle: {
    flex: 22,
    width: '100%',
    justifyContent: 'center'
  },
  genderViewStyle: {
    flex: 15,
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    alignItems: 'center'
  },
  relationViewStyle: {
    flex: 18,
    width: '100%',
    justifyContent: 'center',
    borderBottomWidth: 1,
    borderBottomColor: 'grey',
    marginBottom: moderateScale(10)
  },
  checkBoxStyle: {
    backgroundColor: '#ffffff',
    width: '36%',
    marginTop: moderateScale(10)
  },
  specsViewStyle: {
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-between'
    // borderWidth: 1
  },
  smallViewStyle: {
    flex: 0.5,
    flexDirection: 'row',
    alignItems: 'center'
  }
});
