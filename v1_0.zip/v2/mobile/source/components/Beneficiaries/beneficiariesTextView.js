import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Dimensions,
  TouchableOpacity
} from 'react-native';
import { Icon } from 'react-native-elements';
import { withNavigation } from 'react-navigation';

import {
  scale,
  verticalScale,
  moderateScale
} from '../../constants/const_functions';

class BeneficiariesTextView extends Component {
  render() {
    const { height, width } = Dimensions.get('window');
    let h = height * 0.155;
    let w = width - 20;

    return (
      <TouchableOpacity onPress={this.props.onPress} style={styles.container}>
        {/* <View style={styles.container} elevation={1.5} height={h} width={w}> */}
        <View style={{ flex: 1 }}>
          <View style={{ flex: 0.3 }}>
            <Text style={{ fontSize: moderateScale(17) }}>
              {this.props.name}
            </Text>
          </View>
          <View style={{ flex: 0.7 }}>
            <Text style={{ fontSize: moderateScale(14) }}>
              Age: {this.props.age}
            </Text>
            <Text style={{ fontSize: moderateScale(14) }}>
              Relation: {this.props.relation}
            </Text>
            <Text style={{ fontSize: moderateScale(14) }}>
              Blood Group: {this.props.bloodGroup}
            </Text>
          </View>
        </View>

        <View style={{ flex: 0.8 }}>
          <View style={{ flex: 0.3 }} />
          <View style={{ flex: 0.7 }}>
            <Text style={{ fontSize: moderateScale(14) }}>
              Weight: {this.props.weight}
            </Text>
            <Text style={{ fontSize: moderateScale(14) }}>
              Height: {this.props.height}
            </Text>
            <Text style={{ fontSize: moderateScale(14) }}>
              {this.props.gender}
            </Text>
          </View>
        </View>

        <View style={{ flex: 0.2, alignItems: 'flex-end' }}>
          <TouchableOpacity
            style={{ paddingBottom: 10, paddingRight: 10 }}
            onPress={() => this.props.onEditPress()}
          >
            <Icon
              name='pencil'
              type='evilicon'
              size={moderateScale(22)}
              color='blue'
            />
          </TouchableOpacity>
        </View>
        {/* </View> */}
      </TouchableOpacity>
    );
  }
}

const { height, width } = Dimensions.get('window');
let h = height * 0.155;
let w = width - 20;

var styles = StyleSheet.create({
  container: {
    // flex: 1,
    flexDirection: 'row',
    backgroundColor: '#ffffff',
    justifyContent: 'flex-start',
    borderRadius: 8,
    marginBottom: verticalScale(10),
    paddingLeft: moderateScale(10),
    paddingTop: verticalScale(5),
    paddingBottom: verticalScale(10),
    // paddingRight: moderateScale(10),
    height: h,
    width: w,
    elevation: 1.5,
    shadowOffset: { width: 3, height: 3 },
    shadowColor: 'grey',
    shadowOpacity: 0.25,
    shadowRadius: 5
  }
});

export default BeneficiariesTextView;
