import React, { Component } from 'react';
import { View, Text, StyleSheet, Dimensions, Image } from 'react-native';
import { Button } from 'react-native-elements';
import Modal from 'react-native-modal';
import {
  scale,
  verticalScale,
  moderateScale
} from '../../constants/const_functions';
import RNRearCameraCharacteristicsDisplayMetrics from 'react-native-rear-camera-characteristics-display-metrics';

const width = Dimensions.get('window').width;
const height = Dimensions.get('window').height;

export default class BeneficiaryDetailsModal extends Component {
  render() {
    console.log(width);
    const xInch = width >= 360 ? 2.8 : 2.5;
    // RNRearCameraCharacteristicsDisplayMetrics.DISPLAY_METRICS_WidthPixels /
    // RNRearCameraCharacteristicsDisplayMetrics.DISPLAY_METRICS_Xdpi;
    // const yInch =
    //   RNRearCameraCharacteristicsDisplayMetrics.DISPLAY_METRICS_HeightPixels /
    //   RNRearCameraCharacteristicsDisplayMetrics.DISPLAY_METRICS_Ydpi;
    // console.log(xInch, yInch);

    return (
      <Modal
        // style={styles.modal}
        isVisible={this.props.visibility}
        onBackButtonPress={() =>
          this.props.updateState({
            [this.props.visibilityStateName]: !this.props.visibility
          })
        }
      >
        <View
          style={{ backgroundColor: 'white', marginTop: verticalScale(80), borderRadius: 10 }}
        >
          <View style={styles.headerView}>
            <View style={styles.imageView}>
              <Image
                resizeMode='cover'
                source={require('../../assets/image_placeholder.png')}
                style={styles.image}
              />
            </View>
            <Text style={{ fontSize: 30 }}>{this.props.name}</Text>
            <Text style={{ fontSize: 20 }}>Age: {this.props.age}</Text>
            <Text style={{ fontSize: 20, color: 'green' }}>
              Relation: {this.props.relation}
            </Text>
          </View>
          {xInch >= 2.8 && (
            <View style={styles.bodyView}>
              <View style={styles.relationView}>
                <View style={{ flex: 0.45, flexDirection: 'row' }}>
                  <Image
                    source={require('../../assets/beneficiaryModal/genders.png')}
                    style={styles.imageIcon}
                  />
                  <Text style={styles.text}> Gender:</Text>
                </View>
                <View style={{ flex: 0.55 }}>
                  <Text style={styles.text}>{this.props.gender}</Text>
                </View>
              </View>
              <View style={styles.relationView}>
                <View style={{ flex: 0.45, flexDirection: 'row' }}>
                  <Image
                    source={require('../../assets/beneficiaryModal/weight-scale.png')}
                    style={styles.imageIcon}
                  />
                  <Text style={styles.text}> Weight:</Text>
                </View>
                <View style={{ flex: 0.55 }}>
                  <Text style={styles.text}>{this.props.weight}</Text>
                </View>
              </View>
              <View style={styles.relationView}>
                <View style={{ flex: 0.45, flexDirection: 'row' }}>
                  <Image
                    source={require('../../assets/beneficiaryModal/text-height.png')}
                    style={styles.imageIcon}
                  />
                  <Text style={styles.text}> Height:</Text>
                </View>
                <View style={{ flex: 0.55 }}>
                  <Text style={styles.text}>{this.props.height}</Text>
                </View>
              </View>
              <View style={styles.relationView}>
                <View style={{ flex: 0.45, flexDirection: 'row' }}>
                  <Image
                    source={require('../../assets/beneficiaryModal/blood-drop.png')}
                    style={styles.imageIcon}
                  />
                  <Text style={styles.text}> Blood Group:</Text>
                </View>
                <View style={{ flex: 0.55 }}>
                  <Text style={styles.text}>{this.props.bloodGroup}</Text>
                </View>
              </View>
            </View>
          )}
          {xInch < 2.8 && (
            <View style={styles.bodyView}>
              <View style={styles.relationView}>
                <View style={{ flex: 0.3, flexDirection: 'row' }}>
                  <Image
                    source={require('../../assets/beneficiaryModal/genders.png')}
                    style={styles.imageIcon}
                  />
                </View>
                <View style={{ flex: 0.7 }}>
                  <Text style={styles.text}>{this.props.gender}</Text>
                </View>
              </View>
              <View style={styles.relationView}>
                <View style={{ flex: 0.3, flexDirection: 'row' }}>
                  <Image
                    source={require('../../assets/beneficiaryModal/weight-scale.png')}
                    style={styles.imageIcon}
                  />
                </View>
                <View style={{ flex: 0.7 }}>
                  <Text>{this.props.weight}</Text>
                </View>
              </View>
              <View style={styles.relationView}>
                <View style={{ flex: 0.3, flexDirection: 'row' }}>
                  <Image
                    source={require('../../assets/beneficiaryModal/text-height.png')}
                    style={styles.imageIcon}
                  />
                </View>
                <View style={{ flex: 0.7 }}>
                  <Text style={styles.text}>{this.props.height}</Text>
                </View>
              </View>
              <View style={styles.relationView}>
                <View style={{ flex: 0.3, flexDirection: 'row' }}>
                  <Image
                    source={require('../../assets/beneficiaryModal/blood-drop.png')}
                    style={styles.imageIcon}
                  />
                </View>
                <View style={{ flex: 0.7 }}>
                  <Text style={styles.text}>{this.props.bloodGroup}</Text>
                </View>
              </View>
            </View>
          )}
          <View
            style={{
              flex: 0.01,
              borderColor: 'grey',
              borderBottomWidth: 0.5,
              opacity: 0.5
            }}
          />
          <View style={styles.buttonView}>
            <View
              style={{
                flex: 1,
                justifyContent: 'center',
                alignItems: 'center'
              }}
            >
              <Button
                title='Delete'
                containerStyle={{ width: '90%' }}
                buttonStyle={{ backgroundColor: 'red', borderRadius: 30 }}
                onPress={() => this.props.handleDelete()}
              />
            </View>
            <View
              style={{
                flex: 1,
                justifyContent: 'center',
                alignItems: 'center'
              }}
            >
              <Button
                title='OK'
                containerStyle={{ width: '90%' }}
                buttonStyle={{ backgroundColor: '#60BB46', borderRadius: 30 }}
                onPress={() =>
                  this.props.updateState({
                    [this.props.visibilityStateName]: !this.props.visibility
                  })
                }
              />
            </View>
          </View>
        </View>
      </Modal>
    );
  }
}

const styles = StyleSheet.create({
  // modal: {
  //   flex: 1,
  //   backgroundColor: 'white',
  //   marginTop: verticalScale(80),
  //   marginBottom: verticalScale(70),
  //   marginLeft: moderateScale(40),
  //   marginRight: moderateScale(40),
  //   borderRadius: 20,
  //   padding: moderateScale(10),
  // },

  headerView: {
    // flex: 0.45,
    height: verticalScale(120),
    borderRadius: 10,
    backgroundColor: 'white',
    justifyContent: 'flex-end',
    alignItems: 'center',
    borderBottomColor: '#BCBDC0',
    borderBottomWidth: 1,
    marginTop: verticalScale(-80),
    paddingBottom: verticalScale(10)
  },

  bodyView: {
    // flex: 0.45,
    padding: 10,
    backgroundColor: 'white'
  },

  relationView: {
    // flex: 1,
    height: verticalScale(40),
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: '5%'
  },

  imageIcon: {
    width: moderateScale(20),
    height: moderateScale(20)
  },

  buttonView: {
    // flex: 0.15,
    height: 50,
    marginTop: 5,
    marginBottom: 5,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center'
  },

  text: {
    fontSize: moderateScale(15)
  },

  imageView: {
    alignItems: 'center',
    justifyContent: 'center',
    width: moderateScale(90),
    height: moderateScale(90),
    borderRadius: 100,
    borderColor: 'grey',
    borderWidth: 0.5,
    backgroundColor: 'white'
  },

  image: {
    alignSelf: 'center',
    width: moderateScale(65),
    height: moderateScale(65)
  }
});

BeneficiaryDetailsModal.defaultProps = {
  name: 'Not given',
  age: 'Not given',
  relation: 'Not given',
  gender: 'Not given',
  height: 'Not given',
  weight: 'Not given',
  bloodGroup: 'Not given'
};
