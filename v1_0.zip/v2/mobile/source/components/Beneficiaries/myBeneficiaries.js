import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Dimensions,
  ScrollView,
  Alert,
  Image
} from 'react-native';
import { Fab, Button } from 'native-base';
import Meteor from 'react-native-meteor';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import moment from 'moment';

import Header from '../common/header';
import BeneficiariesTextView from '../Beneficiaries/beneficiariesTextView';
import { getUserAsync } from '../../constants/const_functions';
import BeneficiaryDetailsModal from '../Beneficiaries/beneficiaryDetailsModal';
import {
  scale,
  verticalScale,
  moderateScale
} from '../../constants/const_functions';
import SpinView from '../common/spinner';

export default class MyBeneficiaries extends Component {
  constructor(props) {
    super(props);
    this.state = {
      id: undefined,
      active: 'true',
      bList: [],
      isModalVisible: false,
      name: undefined,
      age: undefined,
      bloodGroup: undefined,
      relation: undefined,
      height: undefined,
      weight: undefined,
      gender: undefined,
      isLoaded: false,
      isUpdate: false,
      reload: false,
      processing: false
    };

    this.fetchBeneficiary();

    this.didFocusSubscription = this.props.navigation.addListener(
      'didFocus',
      payload => this.setState({ reload: false })
    );
  }

  componentWillUnmount() {
    this.didFocusSubscription.remove();
  }

  async fetchBeneficiary() {
    const user = JSON.parse(await getUserAsync());
    console.log(user);
    Meteor.call('fetchBeneficiary', user._id, (err, res) => {
      console.log(err, res);
      if (err) {
        alert(
          'Sorry! Failed to fetch beneficiary list. Please try again later'
        );
      }
      if (res) {
        this.setState({
          bList: res,
          isLoaded: true
        });
      }
    });
  }

  handleFunction() {
    this.setState({ active: !this.state.active });
    this.props.navigation.navigate('BeneficiaryCreate');
  }

  calculateAge(dateString) {
    var age = moment().diff(moment(dateString, 'YYYY-MM-DD'), 'years');
    return age;
  }

  updateState(obj) {
    this.setState({ isModalVisible: obj.isModalVisible });
  }

  handleEdit(sl_no) {
    this.setState({ isUpdate: true });
    const { bList } = this.state;
    this.props.navigation.navigate('BeneficiaryCreate', {
      id: bList[sl_no]._id,
      isUpdate: true,
      name: bList[sl_no].name,
      gender: bList[sl_no].gender,
      relation: bList[sl_no].relation,
      height: bList[sl_no].height,
      weight: bList[sl_no].weight,
      bloodGroup: bList[sl_no].bloodGroup,
      dob: bList[sl_no].dob
    });
  }

  handleDelete() {
    Alert.alert('Delete Beneficiay', 'Are you sure?', [
      { text: 'No', style: 'cancel' },
      {
        text: 'Yes',
        onPress: () => {
          this.setState({processing: true})
          Meteor.call('removeBeneficiary', this.state.id, (err, res) => {
            console.log(err, res);
            this.setState({processing: false})
            if (err) {
              alert('Sorry failed to delete beneficiary');
            } else if (res) {
              this.setState({ isModalVisible: false });
              alert('Deleted successfully');
              this.fetchBeneficiary();
            }
          });
        }
      }
    ]);
  }

  handleReload() {
    this.fetchBeneficiary();
    this.setState({ reload: true });
  }

  render() {
    console.log(
      this.state.reload,
      this.props.navigation.getParam('isReload'),
      this.state.isLoaded
    );
    if (!this.state.reload) {
      if (this.props.navigation.getParam('isReload')) {
        this.handleReload();
      }
    }

    if (this.state.processing) {
      return <SpinView />;
    }

    const { bList } = this.state;

    if (!this.state.isLoaded)
      return (
        <View style={{ flex: 1 }}>
          <Header
            iconLeft='arrowleft'
            text={'My Beneficiaries'}
            iconRight='shoppingcart'
            navigation={this.props.navigation}
          />
          <SpinView />
        </View>
      );
    if (bList.length <= 0) {
      return (
        <View style={{ flex: 1 }}>
          <Header
            iconLeft='arrowleft'
            text={'My Beneficiaries'}
            iconRight='shoppingcart'
            navigation={this.props.navigation}
          />
          <View
            style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}
          >
            <Image
              source={require('../../assets/empytPageIcon/Group_655.png')}
              style={{ width: 150, height: 150 }}
              resizeMode='contain'
            />
            <Text style={{ fontSize: moderateScale(22), textAlign: 'center' }}>
              You have not created any beneficiary!
            </Text>
            <Text style={{ fontSize: moderateScale(16), textAlign: 'center' }}>
              Lets create your first appointment. Shall we?
            </Text>
          </View>
          <Fab
            active={this.state.active}
            direction='up'
            style={{ backgroundColor: '#5067FF' }}
            position='bottomRight'
            containerStyle={{ position: 'absolute', bottom: 15 }}
            onPress={() => this.handleFunction()}
          >
            <Icon name='account-plus' size={moderateScale(35)} />
          </Fab>
        </View>
      );
    }
    return (
      <View style={styles.container}>
        <BeneficiaryDetailsModal
          visibilityStateName='isModalVisible'
          visibility={this.state.isModalVisible}
          updateState={this.updateState.bind(this)}
          handleDelete={this.handleDelete.bind(this)}
          name={this.state.name}
          age={this.state.age}
          bloodGroup={this.state.bloodGroup}
          relation={this.state.relation}
          height={this.state.height}
          weight={this.state.weight}
          gender={this.state.gender}
        />
        <Header
          iconLeft='arrowleft'
          text={'My Beneficiaries'}
          iconRight='shoppingcart'
          navigation={this.props.navigation}
        />
        <View style={styles.mainView}>
          <ScrollView
            style={styles.scrollingView}
            contentContainerStyle={{
              justifyContent: 'space-evenly',
              alignItems: 'center'
            }}
          >
            {!!bList.length &&
              bList.map((item, sl) => (
                <BeneficiariesTextView
                  onPress={() =>
                    this.setState({
                      isModalVisible: !this.state.isModalVisible,
                      id: item._id,
                      name: item.name,
                      age: this.calculateAge(item.dob),
                      bloodGroup: item.bloodGroup,
                      relation: item.relation,
                      height: item.height,
                      weight: item.weight,
                      gender: item.gender
                    })
                  }
                  name={item.name}
                  age={this.calculateAge(item.dob)}
                  bloodGroup={item.bloodGroup}
                  relation={item.relation}
                  height={item.height}
                  weight={item.weight}
                  gender={item.gender}
                  onEditPress={this.handleEdit.bind(this, sl)}
                />
              ))}
          </ScrollView>
        </View>
        <Fab
          active={this.state.active}
          direction='up'
          style={{ backgroundColor: '#5067FF' }}
          position='bottomRight'
          containerStyle={{ position: 'absolute', bottom: 15 }}
          onPress={() => this.handleFunction()}
        >
          <Icon name='account-plus' size={moderateScale(35)} />
        </Fab>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    flex: 1
  },
  mainView: {
    backgroundColor: '#ffffff',
    flex: 1,
    width: '100%',
    justifyContent: 'space-evenly',
    alignItems: 'center',
    paddingTop: 10,
    paddingBottom: 5
  },
  scrollingView: {
    flex: 1,
    width: '100%'
  }
});
