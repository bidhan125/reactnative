import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Dimensions,
  ScrollView,
  Image,
  FlatList,
  ToastAndroid
} from 'react-native';
import Meteor from 'react-native-meteor';
import Spinner from 'react-native-spinkit';

import ItemView from './itemView';
import ItemViewLarge from './itemViewLarge';
import SpinView from '../common/spinner';
import moment from 'moment';
import HistoryModal from '../Modal/historyModal';
import {
  scale,
  verticalScale,
  moderateScale
} from '../../constants/const_functions';

page_size = 10;

export default class TestHistory extends Component {
  constructor(props) {
    super(props);
    console.log('userId:', this.props.userId);
    this.state = {
      uid: this.props.userId,
      singleList: [],
      packageList: [],
      ready: false,
      isHistoryModalVisible: false,
      name: undefined,
      date: undefined,
      status: undefined,
      address: undefined,
      orderType: undefined,
      tests: undefined,
      cart: [],
      price: undefined,

      activePage: 1,
      totalPages: 1
    };
    this.getSingleTest();
    this.fetchMyOrderCount();
  }

  fetchMyOrderCount() {
    const { uid } = this.state;
    Meteor.call('fetchMyOrderCount', { orderType: 'test', uid }, (err, res) => {
      console.log('test_count', err, res);
      if (err) alert('Failed to fetch test count, please try again later');
      else if (res) this.setState({ totalPages: Math.ceil(res / page_size) });
    });
  }

  updateState(obj) {
    this.setState(obj);
  }

  getSingleTest() {
    const { uid, activePage, singleList } = this.state;
    Meteor.call(
      'fetchMyOrders',
      { uid, orderType: 'test', page_no: activePage },
      (error, success) => {
        console.log('single_test', error, success);
        if (error) {
          alert('Unfortunately failed to fetch  More tests.');
        }
        if (success) {
          this.setState({
            singleList: singleList.concat(success),
            ready: true,
            activePage: activePage + 1,
            isLoadingMore: false
          });
        }
      }
    );
  }

  handlePaginate() {
    const { activePage, totalPages } = this.state;
    this.setState({ isLoadingMore: true });

    if (activePage <= totalPages) {
      this.getSingleTest();
    } else {
      this.setState({ isLoadingMore: false });
      if (activePage !== 2)
        ToastAndroid.show('You are at the end of list.', ToastAndroid.SHORT);
    }
  }

  render() {
    const displayWidth = Dimensions.get('window').width;
    const displayHeight = Dimensions.get('window').height;
    let h;
    let w;
    const { singleList } = this.state;
    var map = [];
    if (!this.state.ready) {
      return <SpinView />;
    }

    if (singleList.length <= 0) {
      return (
        <View
          style={{
            flex: 1,
            justifyContent: 'center',
            alignItems: 'center'
          }}
        >
          <Image
            source={require('../../assets/empytPageIcon/Group_641.png')}
            style={{ width: 150, height: 150 }}
            resizeMode='contain'
          />
          <Text style={{ fontSize: moderateScale(22) }}>No Test History!</Text>
          <Text style={{ fontSize: moderateScale(16) }}>
            No test history has been created yet.
          </Text>
        </View>
      );
    }

    return (
      <View style={styles.container}>
        <HistoryModal
          visibility={this.state.isHistoryModalVisible}
          visibilityStateName='isHistoryModalVisible'
          updateState={this.updateState.bind(this)}
          cart={this.state.cart}
          date={this.state.date}
          status={this.state.status}
          orderType={this.state.orderType}
          address={this.state.address}
          homeCare={false}
          test={true}
          price={parseInt(this.state.price)}
          name={this.state.name}
          payment={this.state.payment || 'Not given'}
        />
        <View style={styles.viewStyle}>
          <View style={styles.scrollViewStyle}>
            <FlatList
              style={{ width: displayWidth }}
              onEndReached={(info: { distanceFromEnd: number }) => {
                this.handlePaginate();
              }}
              onEndReachedThreshold={0.2}
              data={singleList}
              renderItem={({ item }) => (
                <ItemViewLarge
                  onPress={() => {
                    var name =
                      item.orderType === 'single_test'
                        ? item.tests.length + ' Tests'
                        : item.tests[0].name;
                    this.setState(
                      {
                        name: name,
                        cart: [...item.tests],
                        date: item.time,
                        status: item.status,
                        orderType: item.orderType,
                        address: item.address,
                        price: item.price,
                        payment: item.payment
                      },
                      () => {
                        this.setState({
                          isHistoryModalVisible: !this.state
                            .isHistoryModalVisible
                        });
                      }
                    );
                  }}
                  itemName={
                    item.orderType === 'single_test'
                      ? item.tests.length + ' Tests'
                      : item.tests[0].name
                  }
                  orderDate={moment(item.time).format('MMM Do YYYY')}
                  price={item.price}
                  invoiceNumber={item.payment || 'Not given'}
                  status={item.status}
                />
              )}
            />

            {this.state.isLoadingMore && (
              <View style={{ position: 'relative', bottom: 20 }}>
                <Spinner
                  type='ThreeBounce'
                  isVisible={this.state.isLoadingMore}
                  size={50}
                  color='grey'
                />
              </View>
            )}
          </View>
        </View>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    flex: 1
  },
  scrollViewStyle: {
    width: '100%',
    flex: 1,
    alignItems: 'center'
  },
  viewStyle: {
    flex: 1,
    width: '100%'
  }
});
