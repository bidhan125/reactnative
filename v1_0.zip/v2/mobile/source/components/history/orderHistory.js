import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Dimensions,
  ScrollView,
  Image,
  FlatList,
  ToastAndroid
} from 'react-native';
import Meteor from 'react-native-meteor';
import Spinner from 'react-native-spinkit';

import ItemView from './itemView';
import ItemViewLarge from './itemViewLarge';
import SpinView from '../common/spinner';
import moment from 'moment';

import HistoryModal from '../Modal/historyModal';
import {
  scale,
  verticalScale,
  moderateScale
} from '../../constants/const_functions';

page_size = 10;

export default class OrderHistory extends Component {
  constructor(props) {
    super(props);
    this.state = {
      uid: this.props.userId,
      medicineList: [],
      ready: false,
      isHistoryModalVisible: false,
      name: undefined,
      date: undefined,
      status: undefined,
      address: undefined,
      orderType: undefined,
      tests: undefined,
      cart: [],
      homeCare: false,

      activePage: 1,
      totalPages: 1
    };
    this.getMedicine();
    this.fetchMyOrderCount();
  }

  fetchMyOrderCount() {
    const { uid } = this.state;
    Meteor.call(
      'fetchMyOrderCount',
      { orderType: 'medicine', uid },
      (err, res) => {
        console.log('medicine_count', err, res);
        if (err)
          alert('Failed to fetch medicine count, please try again later');
        else if (res) this.setState({ totalPages: Math.ceil(res / page_size) });
      }
    );
  }

  updateState(obj) {
    this.setState(obj);
  }

  getMedicine() {
    const { uid, activePage, medicineList } = this.state;
    Meteor.call(
      'fetchMyOrders',
      { uid, orderType: 'medicine', page_no: activePage },
      (error, success) => {
        console.log(error, success);
        if (error) {
          alert('Unfortunately failed to fetch  More Medicine.');
        }
        if (success) {
          console.log('medicine: ', success);
          this.setState({
            medicineList: medicineList.concat(success),
            ready: true,
            activePage: activePage + 1,
            isLoadingMore: false
          });
        }
      }
    );
  }

  handlePaginate() {
    const { activePage, totalPages } = this.state;
    this.setState({ isLoadingMore: true });

    if (activePage <= totalPages) {
      this.getMedicine();
    } else {
      this.setState({ isLoadingMore: false });
      if (activePage !== 2)
        ToastAndroid.show('You are at the end of list.', ToastAndroid.SHORT);
    }
  }

  render() {
    const displayWidth = Dimensions.get('window').width;
    const displayHeight = Dimensions.get('window').height;
    let h;
    let w;
    const { medicineList } = this.state;

    if (!this.state.ready) {
      return <SpinView />;
    }

    if (medicineList.length <= 0) {
      return (
        <View
          style={{
            flex: 1,
            justifyContent: 'center',
            alignItems: 'center'
          }}
        >
          <Image
            source={require('../../assets/empytPageIcon/Group_642.png')}
            style={{ width: 150, height: 150 }}
            resizeMode="contain"
          />
          <Text style={{ fontSize: moderateScale(22) }}>
            No Medicine History!
          </Text>
          <Text style={{ fontSize: moderateScale(16) }}>
            No medicine history has been created yet.
          </Text>
        </View>
      );
    }

    return (
      <View style={styles.container}>
        <HistoryModal
          visibility={this.state.isHistoryModalVisible}
          visibilityStateName="isHistoryModalVisible"
          updateState={this.updateState.bind(this)}
          cart={this.state.cart}
          date={this.state.date}
          status={this.state.status}
          orderType={this.state.orderType}
          address={this.state.address}
          homeCare={false}
          name={this.state.name}
          payment={this.state.payment || 'Not given'}
        />
        <View style={styles.viewStyle}>
          <View style={styles.scrollViewStyle}>
            <FlatList
              style={{ width: displayWidth }}
              onEndReached={(info: { distanceFromEnd: number }) => {
                this.handlePaginate();
              }}
              onEndReachedThreshold={0.2}
              data={medicineList}
              renderItem={({ item }) => (
                <ItemViewLarge
                  onPress={() => {
                    var arrCart = [];
                    for (var key in item.cart) {
                      if (item.cart.hasOwnProperty(key)) {
                        arrCart.push({ ...item.cart[key], id: key });
                      }
                    }
                    this.setState(
                      {
                        name: Object.keys(item.cart).length + ' Orders',
                        cart: [...arrCart],
                        date: item.time,
                        status: item.status,
                        orderType: item.orderType,
                        address: item.address,
                        homeCare: false,
                        payment: item.payment
                      },
                      () => {
                        this.setState({
                          isHistoryModalVisible: !this.state
                            .isHistoryModalVisible
                        });
                      }
                    );
                  }}
                  itemName={Object.keys(item.cart).length + ' Orders'}
                  orderDate={moment(item.time).format('MMM Do YYYY')}
                  price={item.price}
                  invoiceNumber={item.payment || 'Not given'}
                  status={item.status}
                />
              )}
            />
            {this.state.isLoadingMore && (
              <View style={{ position: 'relative', bottom: 20 }}>
                <Spinner
                  type="ThreeBounce"
                  isVisible={this.state.isLoadingMore}
                  size={50}
                  color="grey"
                />
              </View>
            )}
          </View>
        </View>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    flex: 1
  },
  scrollViewStyle: {
    width: '100%',
    flex: 1,
    alignItems: 'center'
  },
  viewStyle: {
    flex: 1,
    width: '100%'
  }
});
