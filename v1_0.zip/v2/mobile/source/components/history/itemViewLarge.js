import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Dimensions,
  TouchableOpacity,
  Image
} from 'react-native';
import { Icon as IconEl } from 'react-native-elements';
//props:  itemName, orderDate,branchName, Price,invoiceNumber,deliveryDate,

import { moderateScale, verticalScale } from '../../constants/const_functions';

export default class ItemViewLarge extends Component {
  render() {
    const displayWidth = Dimensions.get('window').width;
    const displayHeight = Dimensions.get('window').height;
    let h = displayHeight * 0.135;
    let w = displayWidth - 20;

    const status = this.props.status;

    return (
      <TouchableOpacity onPress={this.props.onPress} style={styles.container}>
        {/* <View style={styles.container} elevation={1.5} height={h} width={w}> */}
        <View
          style={{
            flex: 0.65,
            justifyContent: 'center',
            alignItems: 'flex-start'
          }}
        >
          <View style={{ flex: 0.36, justifyContent: 'center' }}>
            <Text
              style={{
                fontSize: moderateScale(15),
                fontWeight: 'bold',
                color: '#0076BE'
              }}
            >
              {this.props.itemName}
            </Text>
          </View>
          <View
            style={{
              flex: 0.22,
              flexDirection: 'row',
              justifyContent: 'flex-start',
              alignItems: 'center'
            }}
          >
            <Image
              source={require('../../assets/price_tag.png')}
              style={{ width: moderateScale(15), height: moderateScale(15) }}
            />
            <Text style={styles.textStyle}>{this.props.price + ' BDT'}</Text>
          </View>
          <View
            style={{
              flex: 0.22,
              flexDirection: 'row',
              justifyContent: 'flex-start',
              alignItems: 'center'
            }}
          >
            <IconEl name='calendar' type='antdesign' size={moderateScale(15)} />
            <Text style={styles.textStyle}>{this.props.orderDate}</Text>
          </View>
        </View>
        <View
          style={{
            flex: 0.35,
            justifyContent: 'center',
            alignItems: 'flex-start',
            paddingRight: moderateScale(5)
          }}
        >
          <View style={{ flex: 0.36 }} />
          <View
            style={{
              flex: 0.22,
              flexDirection: 'row',
              justifyContent: 'flex-start',
              alignItems: 'center'
            }}
          >
            <IconEl
              name='infocirlceo'
              color={
                status === 'Pending'
                  ? '#767676'
                  : status === 'Rejected'
                  ? '#db2828'
                  : status === 'Confirmed'
                  ? '#fbbd08'
                  : status === 'Processing'
                  ? '#2185d0'
                  : status === 'Shipping'
                  ? '#b5cc18'
                  : '#21ba45'
              }
              type='antdesign'
              size={moderateScale(15)}
            />

            <Text style={styles.textStyle}>{this.props.status}</Text>
          </View>
          <View
            style={{
              flex: 0.22,
              flexDirection: 'row',
              justifyContent: 'flex-start',
              alignItems: 'center'
            }}
          >
            <Image
              source={require('../../assets/rsz_invoice.png')}
              style={{
                width: moderateScale(15),
                height: moderateScale(15),
                opacity: 0.8
              }}
            />
            <Text style={[styles.textStyle, {marginRight: 10}]} numberOfLines={1}>
              {this.props.invoiceNumber.invId || 'Not given'}
            </Text>
          </View>
        </View>
        {/* </View> */}
      </TouchableOpacity>
    );
  }
}

const displayWidth = Dimensions.get('window').width;
const displayHeight = Dimensions.get('window').height;
let h = displayHeight * 0.135;
let w = displayWidth - 20;

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    flexDirection: 'row',
    justifyContent: 'flex-start',
    borderRadius: 8,
    marginTop: verticalScale(5),
    marginBottom: verticalScale(5),
    marginLeft: moderateScale(10),
    marginRight: moderateScale(10),
    paddingLeft: moderateScale(10),
    paddingTop: moderateScale(5),
    paddingBottom: moderateScale(5),
    height: h,
    width: w,
    elevation: 1.5,
    shadowOffset: { width: 3, height: 3 },
    shadowColor: 'grey',
    shadowOpacity: 0.25,
    shadowRadius: 5
  },
  leftViewStyle: {
    flex: 0.6,
    justifyContent: 'space-evenly'
  },
  rightViewStyle: {
    flex: 0.4,
    justifyContent: 'space-evenly'
  },

  textStyle: {
    fontSize: moderateScale(13.5),
    paddingLeft: moderateScale(5)
  }
});
