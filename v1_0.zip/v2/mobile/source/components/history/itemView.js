import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Dimensions,
  TouchableOpacity,
} from 'react-native';
//props:  itemName, orderDate,branchName, Price,invoiceNumber,deliveryDate,

export default class ItemView extends Component {
  render() {
    const { height, width } = Dimensions.get('window');
    let h = height * 0.18;
    let w = width - 20;

    return (
      <TouchableOpacity>
        <View style={styles.container} elevation={1.5} height={h} width={w}>
          <View style={{ flex: 0.33, flexDirection: 'row' }}>
            <Text style={{ fontSize: 18 }}>Order Date: </Text>
            <Text style={{ fontSize: 18, fontWeight: 'bold' }}>
              {this.props.orderDate}
            </Text>
          </View>

          <View
            style={{
              flex: 0.33,
              flexDirection: 'row',
              justifyContent: 'space-between',
            }}
          >
            <View style={{ flexDirection: 'row' }}>
              <Text style={{ fontSize: 18 }}>Invoice #</Text>
              <Text style={{ fontSize: 18, fontWeight: 'bold' }}>
                {this.props.invoiceNumber}
              </Text>
            </View>
            <View style={{ flexDirection: 'row' }}>
              <Text
                style={{ fontSize: 16, color: 'green', fontWeight: 'bold' }}
              >
                {this.props.status}
              </Text>
            </View>
          </View>

          <View
            style={{
              flex: 0.33,
              flexDirection: 'row',
              justifyContent: 'space-between',
            }}
          >
            <View style={{ flexDirection: 'row' }}>
              <Text style={{ fontSize: 18 }}>Quantity:</Text>
              <Text style={{ fontSize: 18, fontWeight: 'bold' }}>
                {' '}
                {this.props.quantity}
              </Text>
            </View>

            <View style={{ flexDirection: 'row' }}>
              <Text style={{ fontSize: 18 }}>Price: </Text>
              <Text style={{ fontSize: 18, fontWeight: 'bold' }}>
                {this.props.price}
              </Text>
            </View>
          </View>
        </View>
      </TouchableOpacity>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    justifyContent: 'flex-start',
    borderRadius: 8,
    marginBottom: 10,
    paddingLeft: 12,
    paddingTop: 12,
    paddingBottom: 10,
    paddingRight: 8,
    shadowOffset: { width: 3, height: 3 },
    shadowColor: 'grey',
    shadowOpacity: 0.25,
    shadowRadius: 5,
  },
});
