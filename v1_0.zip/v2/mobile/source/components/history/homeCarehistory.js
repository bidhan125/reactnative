import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Dimensions,
  ScrollView,
  Image,
  ToastAndroid
} from 'react-native';
import Meteor from 'react-native-meteor';
import Spinner from 'react-native-spinkit';

import ItemView from './itemView';
import ItemViewLarge from './itemViewLarge';
import SpinView from '../common/spinner';
import moment from 'moment';

import HistoryModal from '../Modal/historyModal';
import {
  scale,
  verticalScale,
  moderateScale
} from '../../constants/const_functions';
import { FlatList } from 'react-native-gesture-handler';

page_size = 10;

export default class HomeCareHistory extends Component {
  constructor(props) {
    super(props);
    this.state = {
      uid: this.props.userId,
      homeCareList: [],
      ready: false,
      isHistoryModalVisible: false,
      name: undefined,
      status: undefined,
      address: undefined,
      orderType: undefined,
      phone: undefined,
      gender: undefined,
      patientName: undefined,

      activePage: 1,
      totalPages: 1
    };
    this.getHomeCare();
    this.fetchMyOrderCount();
  }

  fetchMyOrderCount() {
    const { uid } = this.state;
    Meteor.call(
      'fetchMyOrderCount',
      { orderType: 'home_care', uid },
      (err, res) => {
        console.log('home_care', err, res);
        if (err)
          alert('Failed to fetch home care count, please try again later');
        else if (res) this.setState({ totalPages: Math.ceil(res / page_size) });
      }
    );
  }

  updateState(obj) {
    this.setState(obj);
  }

  getHomeCare() {
    const { uid, activePage, homeCareList } = this.state;
    Meteor.call(
      'fetchMyOrders',
      { uid, orderType: 'home_care', page_no: activePage },
      (error, success) => {
        console.log(error, success);
        if (error) {
          console.log('error', error);
        }
        if (success) {
          console.log('home: ', success);
          this.setState({
            homeCareList: homeCareList.concat(success),
            ready: true,
            activePage: activePage + 1,
            isLoadingMore: false
          });
        }
      }
    );
  }

  handlePaginate() {
    const { activePage, totalPages } = this.state;
    this.setState({ isLoadingMore: true });

    if (activePage <= totalPages) {
      this.getHomeCare();
    } else {
      this.setState({ isLoadingMore: false });
      if (activePage !== 2)
        ToastAndroid.show('You are at the end of list.', ToastAndroid.SHORT);
    }
  }

  render() {
    const displayWidth = Dimensions.get('window').width;
    const displayHeight = Dimensions.get('window').height;
    let h;
    let w;
    const { homeCareList } = this.state;

    if (!this.state.ready) {
      return <SpinView />;
    }

    if (homeCareList.length <= 0) {
      return (
        <View
          style={{
            flex: 1,
            justifyContent: 'center',
            alignItems: 'center'
          }}
        >
          <Image
            source={require('../../assets/empytPageIcon/Group_643.png')}
            style={{ width: 150, height: 150 }}
            resizeMode="contain"
          />
          <Text style={{ fontSize: moderateScale(22) }}>
            No Home Care History!
          </Text>
          <Text style={{ fontSize: moderateScale(16) }}>
            No home care history has been created yet.
          </Text>
        </View>
      );
    }

    return (
      <View style={styles.container}>
        <HistoryModal
          visibility={this.state.isHistoryModalVisible}
          visibilityStateName="isHistoryModalVisible"
          updateState={this.updateState.bind(this)}
          name={this.state.name}
          gender={this.state.gender}
          phone={this.state.phone}
          status={this.state.status}
          patientName={this.state.patientName}
          orderType={this.state.orderType}
          address={this.state.address}
          homeCare={true}
        />
        <View style={styles.viewStyle}>
          <View style={styles.scrollViewStyle}>
            <FlatList
              onEndReached={(info: { distanceFromEnd: number }) => {
                this.handlePaginate();
              }}
              style={{ width: displayWidth }}
              onEndReachedThreshold={0.2}
              data={homeCareList}
              renderItem={({ item }) => (
                <ItemViewLarge
                  onPress={() =>
                    this.setState(
                      {
                        name: item.serviceName,
                        patientName: item.name,
                        phone: item.phone,
                        gender: item.gender,
                        status: item.status,
                        orderType: item.orderType,
                        address: item.address
                      },
                      () => {
                        this.setState({
                          isHistoryModalVisible: !this.state
                            .isHistoryModalVisible
                        });
                      }
                    )
                  }
                  itemName={item.serviceName}
                  orderDate={moment(item.time).format('MMM Do YYYY')}
                  price={item.price || 'Not given'}
                  invoiceNumber={item.invoiceNumber || 'Not given'}
                  status={item.status}
                />
              )}
            />

            {this.state.isLoadingMore && (
              <View style={{ position: 'relative', bottom: 20 }}>
                <Spinner
                  type="ThreeBounce"
                  isVisible={this.state.isLoadingMore}
                  size={50}
                  color="grey"
                />
              </View>
            )}
          </View>
        </View>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    flex: 1
  },
  scrollViewStyle: {
    width: '100%',
    flex: 1,
    alignItems: 'center'
  },
  viewStyle: {
    flex: 1,
    width: '100%'
  }
});
