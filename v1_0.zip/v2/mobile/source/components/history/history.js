import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  Picker,
  ScrollView,
  Dimensions
} from 'react-native';
import { TabView, SceneMap } from 'react-native-tab-view';

import Header from '../common/header';
import TestHistory from './testHistory';
import OrderHistory from '../history/orderHistory';
import HomeCareHistory from '../history/homeCarehistory';
import { getUserAsync } from '../../constants/const_functions';
import SpinView from '../common/spinner';

const { height, width } = Dimensions.get('window');
export default class History extends Component {
  constructor(props) {
    super(props);

    this.state = {
      index: 0,
      id: undefined,
      routes: [
        { key: 'first', title: 'Test History' },
        { key: 'second', title: 'Medicine & Accessories' },
        { key: 'third', title: 'Home Care' }
      ]
    };

    this.fetchUser();
  }

  async fetchUser() {
    const user = JSON.parse(await getUserAsync());
    console.log(user);
    this.setState({
      id: user._id
    });
  }

  render() {
    console.log(this.props);
    if (!this.state.id) {
      return (
        <View
          style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}
        >
          <Header
            text="Order History"
            iconLeft="arrowleft"
            iconRight="shoppingcart"
            navigation={this.props.navigation}
          />
          <SpinView />
        </View>
      );
    }

    return (
      <React.Fragment>
        <Header
          text="Order History"
          iconLeft="arrowleft"
          iconRight="shoppingcart"
          navigation={this.props.navigation}
        />
        <TabView
          navigationState={this.state}
          renderScene={({ route }) => {
            switch (route.key) {
              case 'first':
                return <TestHistory userId={this.state.id} />;
              case 'second':
                return <OrderHistory userId={this.state.id} />;
              case 'third':
                return <HomeCareHistory userId={this.state.id} />;
              default:
                null;
            }
          }}
          onIndexChange={index => this.setState({ index })}
          initialLayout={{ width }}
          tabStyle={{ height: 50 }}
          style={{ height: height / 2 }}
          tabBarPosition="bottom"
        />
      </React.Fragment>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    height: 1000,
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center'
  }
});
