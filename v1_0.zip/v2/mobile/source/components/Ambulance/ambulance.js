import React, { Component } from 'react';
import {
  StyleSheet,
  View,
  Image,
  Dimensions,
  TouchableOpacity,
  Text,
  ScrollView
} from 'react-native';

import Meteor from 'react-native-meteor';

import Header from '../common/header';
import RectangleViewHomecare from '../common/rectangleViewHomeCare';
import { moderateScale, verticalScale } from '../../constants/const_functions';
import AmbulanceModal from './ambulanceModal';

export default class Ambulance extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isModalVisible: false,
      regularFare: {},
      icuFare: {},
      regular: false
    };

    this.fetchAmbulanceFare();
  }

  fetchAmbulanceFare() {
    Meteor.call('fetchAmbulanceFare', (err, res) => {
      console.log(err, res);
      if (err) {
        console.log(err);
      } else {
        this.setState({ regularFare: res.regular, icuFare: res.icu }, () =>
          console.log(this.state.regularFare, this.state.icuFare)
        );
      }
    });
  }

  modalMethod = () => {
    this.setState({ isModalVisible: !this.state.isModalVisible });
  };

  render() {
    const displayWidth = Dimensions.get('window').width;
    const displayHeight = Dimensions.get('window').height;
    h = displayHeight / 6;

    return (
      <View style={styles.container}>
        <Header
          text='Ambulance'
          iconLeft='arrowleft'
          iconRight='shoppingcart'
          navigation={this.props.navigation}
        />
        <AmbulanceModal
          visibility={this.state.isModalVisible}
          updateState={this.modalMethod.bind(this)}
          fare={this.state.regular ? this.state.regularFare : this.state.icuFare}
        />
        <ScrollView contentContainerStyle={{ flex: 1 }}>
          <View style={styles.mainView}>
            {/* <View style={styles.middleView}> */}
            <TouchableOpacity
              style={styles.touchView}
              onPress={() => {
                this.setState({ isModalVisible: true });
              }}
            >
              <View style={{ padding: 10, paddingBottom: 0 }}>
                <Image
                  resizeMode='contain'
                  source={require('../../assets/ICU/Asset_9a.png')}
                  style={styles.image}
                />
              </View>
              <View style={{ padding: 10 }}>
                <Text style={styles.headerText}>ICU Ambulance</Text>
                <Text style={{ textAlign: 'right' }}>
                  Intensive care ambulances are well-equipped ambulances staffed
                  by highly trained paramedics dispatched to emergency
                  situations where patients require a higher level of care than
                  a regular ambulance can provide
                </Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.touchView}
              onPress={() => {
                this.setState({ isModalVisible: true, regular: true });
              }}
            >
              <View style={{ padding: 10, paddingBottom: 0 }}>
                <Image
                  resizeMode='contain'
                  source={require('../../assets/ICU/Asset_5a.png')}
                  style={styles.image}
                />
              </View>
              <View style={{ padding: 10 }}>
                <Text style={styles.headerText}>Regular Ambulance</Text>
                <Text style={{ textAlign: 'right' }}>
                  The Ambulance service at Labaid Hospital provides emergency
                  support to patients who require it. In order to bring patients
                  who call for ambulance they need to provide their home address
                  and or telephone and cellphone number to the ambulance drivers
                </Text>
              </View>
            </TouchableOpacity>
          </View>
          {/* </View> */}
        </ScrollView>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center'
  },
  mainView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%'
  },
  touchView: {
    flex: 1,
    elevation: 2,
    margin: 5,
    width: '96%',
    borderRadius: 10,
    backgroundColor: '#ffffff',
    shadowOffset: { width: 3, height: 3 },
    shadowColor: 'grey',
    shadowOpacity: 0.25,
    shadowRadius: 5
    // borderWidth: 1
  },
  image: {
    width: moderateScale(190),
    height: verticalScale(136)
  },
  headerText: {
    fontSize: moderateScale(25),
    color: '#0076BE',
    textAlign: 'right'
  }
});
