import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Image,
  Dimensions,
  TouchableOpacity,
  Linking
} from 'react-native';

import call from 'react-native-phone-call';
import { Button } from 'react-native-elements';
import Modal from 'react-native-modal';

import { moderateScale } from '../../constants/const_functions';

export default class AmbulanceModal extends Component {
  render() {
    const args = {
      number: '01766661030',
      prompt: false
    };
    const displayWidth = Dimensions.get('window').width;
    const displayHeight = Dimensions.get('window').height;
    let h = displayHeight * 0.15;
    let w = (h * 144) / 103;
    let fieldHeight = displayHeight * 0.22;

    const { fare } = this.props
    return (
      <Modal
        style={styles.modalStyle}
        transparent={true}
        isVisible={this.props.visibility}
        onBackButtonPress={() => {
          this.props.updateState();
        }}
        onBackdropPress={() => {
          this.props.updateState();
        }}
      >
        <View style={styles.modalInsideViewStyle}>
          <View style={styles.modalChildStyle}>
            <Image
              source={require('../../assets/customIcons/healthcare-and-medical(1).png')}
              style={{ width: w / 2, height: h / 2 }}
            />
          </View>
          <View style={styles.fairViewStyle}>
            <View style={styles.rowStyle}>
              <Text style={styles.listStyle}>Base Fair</Text>
              <Text style={styles.listStyle}>{fare.baseFare || 'Not applicable'}</Text>
            </View>
            <View style={styles.rowStyle}>
              <Text style={styles.listStyle}>Per Kilometer</Text>
              <Text style={styles.listStyle}>{fare.perKMFare || 'Not applicable'}</Text>
            </View>
            <View style={styles.rowStyle}>
              <Text style={styles.listStyle}>Per Minute</Text>
              <Text style={styles.listStyle}>{fare.perMinute || 'Not applicable'}</Text>
            </View>
            <View style={styles.rowStyle}>
              <Text style={styles.listStyle}>Minimum Fair</Text>
              <Text style={styles.listStyle}>{fare.minFare || 'Not applicable'}</Text>
            </View>
          </View>
          <View style={styles.modalChildStyle}>
            <Text
              style={{
                fontSize: 19,
                textAlign: 'center',
                marginLeft: 30,
                marginRight: 30
              }}
            >
              Do you want to make a call for an ambulance?{' '}
            </Text>
          </View>
          <View style={styles.modalButtonView}>
            <View
              style={{
                justifyContent: 'center',
                alignItems: 'center',
                flex: 1
              }}
            >
              <Button
                title='Later'
                type='outline'
                containerStyle={{ width: '70%' }}
                buttonStyle={{ borderRadius: 20 }}
                titleStyle={{ fontSize: moderateScale(14) }}
                onPress={() => this.props.updateState()}
              />
            </View>

            <View
              style={{
                flex: 1,
                justifyContent: 'center',
                alignItems: 'center'
              }}
            >
              <Button
                title='Call'
                type='solid'
                containerStyle={{ width: '70%' }}
                buttonStyle={{ backgroundColor: '#60BB46', borderRadius: 20 }}
                titleStyle={{ fontSize: moderateScale(14) }}
                onPress={() => call(args).catch(console.error)}
              />
            </View>
          </View>
        </View>
      </Modal>
    );
  }
}

const styles = StyleSheet.create({
  modalStyle: {
    justifyContent: 'center',
    alignItems: 'center'
  },

  modalInsideViewStyle: {
    flex: 0.7,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f0f0ff',
    width: '100%',
    borderRadius: 10
  },
  modalChildStyle: {
    flex: 0.3,
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center'
  },

  fairViewStyle: {
    flex: 0.4,
    width: '70%',
    padding: moderateScale(10)
    // elevation: 1
  },

  listStyle: {
    fontSize: moderateScale(16),
    color: 'black'
  },

  rowStyle: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderBottomWidth: 0.5,
    borderBottomColor: '#BCBDC0',
    alignItems: 'center'
  },

  modalButtonView: {
    flex: 0.3,
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center'
  }
});
