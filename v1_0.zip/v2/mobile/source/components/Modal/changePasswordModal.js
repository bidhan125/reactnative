import React, { Component } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  ScrollView,
  KeyboardAvoidingView
} from 'react-native';
import { Icon, Button, Input } from 'react-native-elements';

import Modal from 'react-native-modal';
import {
  scale,
  verticalScale,
  moderateScale
} from '../../constants/const_functions';

export default (ChangePasswordModal = props => {
  return (
    <Modal
      // style={{ justifyContent: 'center', minHeight: verticalScale(200) }}
      avoidKeyboard={true}
      // transparent={true}
      isVisible={props.visibility}
      onBackdropPress={() =>
        props.updateState({ [props.visibilityStateName]: !props.visibility })
      }
      onBackButtonPress={() =>
        props.updateState({ [props.visibilityStateName]: !props.visibility })
      }
    >
      <KeyboardAvoidingView style={styles.container}>
        <View
          style={{
            // flex: 0.1,
            justifyContent: 'center',
            alignItems: 'center',
            marginBottom: 15,
            borderBottomWidth: 1,
            borderBottomColor: 'grey',
            paddingBottom: 10,
            height: 50
          }}
        >
          <Text
            style={{
              fontSize: moderateScale(22),
              color: '#1285ff',
              fontWeight: 'bold'
            }}
          >
            Change your password
          </Text>
        </View>
        <View
          style={{ justifyContent: 'center', alignItems: 'center' }}
        >
          <Input
            placeholder='Current Password'
            // value={this.state.email}
            editable={true}
            style={styles.inputStyle}
            onChangeText={currentPassword =>
              props.updateState({ currentPassword })
            }
            keyboardType='default'
            secureTextEntry={true}
            leftIcon={
              <Icon
                name='lock'
                type='simple-line-icon'
                size={24}
                color='#707070'
              />
            }
            containerStyle={{
              borderWidth: 1,
              borderRadius: 20,
              marginBottom: 20,
              borderColor: '#BCBDC0'
            }}
            inputContainerStyle={{ borderBottomWidth: 0 }}
            // ref={ref => (this.emailRef = ref)}
            onSubmitEditing={() => password.focus()}
            returnKeyType='next'
          />
          <Input
            placeholder='New Password'
            // value={this.state.email}
            editable={true}
            onChangeText={password => props.updateState({ password })}
            keyboardType='default'
            secureTextEntry={true}
            leftIcon={
              <Icon
                name='lock'
                type='simple-line-icon'
                size={24}
                color='#707070'
              />
            }
            containerStyle={{
              borderWidth: 1,
              borderRadius: 20,
              marginBottom: 20,
              borderColor: '#BCBDC0'
            }}
            inputContainerStyle={{ borderBottomWidth: 0 }}
            ref={ref => (password = ref)}
            onSubmitEditing={() => password1.focus()}
            returnKeyType='next'
          />
          <Input
            placeholder='Confirm New Password'
            // value={this.state.email}
            editable={true}
            onChangeText={password1 => props.updateState({ password1 })}
            keyboardType='default'
            secureTextEntry={true}
            leftIcon={
              <Icon
                name='lock'
                type='simple-line-icon'
                size={24}
                color='#707070'
              />
            }
            containerStyle={{
              borderWidth: 1,
              borderRadius: 20,
              marginBottom: 10,
              borderColor: '#BCBDC0',
              height: 50
            }}
            inputContainerStyle={{ borderBottomWidth: 0 }}
            ref={ref => (password1 = ref)}
            // onSubmitEditing={() => this.feedBackRef.focus()}
            returnKeyType='done'
          />
        </View>
        <Button
          title='Update'
          containerStyle={{ width: '100%' }}
          buttonStyle={{ backgroundColor: '#60BB46', borderRadius: 20 }}
          titleStyle={{ fontSize: moderateScale(20) }}
          onPress={() => props.handlePasswordChange()}
        />
      </KeyboardAvoidingView>
    </Modal>
  );
});

const styles = StyleSheet.create({
  container: {
    // height: verticalScale(300),
    borderRadius: 20,
    padding: moderateScale(15),
    backgroundColor: 'white'
  },
  inputStyle: {
    height: verticalScale(50),
    paddingTop: verticalScale(10),
    borderWidth: 1
  }
});
