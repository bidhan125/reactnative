import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, Dimensions } from 'react-native';
import { moderateScale } from '../../constants/const_functions';

export default class CartItem extends Component {
  render() {
    const { width, height } = Dimensions.get('window');

    return (
      <View style={styles.container} height={height * 0.08} width={'100%'}>
        <View style={styles.viewStyle} flex={0.3}>
          <Text style={[styles.textStyle, { textAlign: 'left' }]}>
            {this.props.name.trim()}
          </Text>
        </View>
        {!this.props.test && (
          <View style={styles.viewStyle} flex={0.25}>
            <Text style={styles.textStyle}>{this.props.quantity}</Text>
          </View>
        )}
        {!this.props.test && (
          <View style={styles.viewStyle} flex={0.2}>
            <Text style={styles.textStyle}>{this.props.unitPrice}</Text>
          </View>
        )}
        {this.props.test && (
          <View
            style={{
              flex: 0.45,
              justifyContent: 'center',
              alignItems: 'center',
              height: '100%'
            }}
          >
            <Text style={styles.textStyle}>{this.props.beneficiary}</Text>
          </View>
        )}

        <View style={styles.viewStyle} flex={0.25} alignItems='flex-end'>
          <Text style={styles.textStyle}>
            {this.props.subTotal && parseFloat(this.props.subTotal).toFixed(1)}
          </Text>
        </View>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    flexDirection: 'row',
    justifyContent: 'flex-start',
    borderBottomWidth: 1,
    borderColor: '#80808044'
  },
  viewStyle: {
    justifyContent: 'center',
    alignItems: 'center',
    height: '100%'
  },
  textStyle: {
    fontSize: moderateScale(17)
  }
});
