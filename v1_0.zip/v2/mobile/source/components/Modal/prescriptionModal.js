import React, { Component } from 'react';
import { View, StyleSheet, Text, TouchableOpacity, Image } from 'react-native';
import Modal from 'react-native-modal';

import { moderateScale, verticalScale } from '../../constants/const_functions';
import { Button } from 'react-native-elements';

export default class PrescriptionModal extends Component {
  render() {
    console.log(this.props);
    return (
      <Modal
        isVisible={this.props.visibility}
        onBackButtonPress={() =>
          this.props.updateState({
            [this.props.visibilityStateName]: !this.props.visibility
          })
        }
      >
        <View style={styles.mainView}>
          <View style={styles.header}>
            <Text>Prescription</Text>
          </View>
          <View>
            <Text>Uploda Image</Text>
          </View>
          <View>
            <Button title="Submit" onPress={this.props.handlePrescription} />
          </View>
        </View>
      </Modal>
    );
  }
}

const styles = StyleSheet.create({
  mainView: {
    flex: 1,
    marginTop: verticalScale(50),
    marginLeft: moderateScale(10),
    marginRight: moderateScale(10),
    marginBottom: verticalScale(30),
    borderRadius: 20,
    padding: moderateScale(15),
    backgroundColor: 'white'
  },

  header: {
    flex: 2,
    borderBottomWidth: 1,
    borderBottomColor: 'grey'
  },

  body: {
    flex: 6
  },

  button: {
    flex: 2
  }
});
