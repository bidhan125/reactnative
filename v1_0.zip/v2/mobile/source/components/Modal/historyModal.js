import React, { Component } from 'react';
import { View, Text, Image, StyleSheet, ScrollView } from 'react-native';
import Modal from 'react-native-modal';
import moment from 'moment';

import { moderateScale, verticalScale } from '../../constants/const_functions';
import CartItem from '../Modal/cartForHistoryModal';
import { Button } from 'react-native-elements';

export default class HistoryModal extends Component {
  render() {
    var arrCart = [];
    var totalPrice = 0;
    if (!this.props.homeCare) {
      arrCart = [...this.props.cart];
    }

    return (
      <Modal
        isVisible={this.props.visibility}
        onBackButtonPress={() =>
          this.props.updateState({
            [this.props.visibilityStateName]: !this.props.visibility
          })
        }
      >
        <View style={styles.mainView}>
          <View
            style={{
              flex: 0.1,
              justifyContent: 'center',
              alignItems: 'center',
              borderBottomWidth: 1,
              borderBottomColor: '#BCBDC0'
            }}
          >
            <Text
              style={{
                fontSize: moderateScale(22),
                color: '#0076BE',
                fontWeight: 'bold'
              }}
            >
              {this.props.name || 'Name not given'}
            </Text>
          </View>
          <View
            style={this.props.homeCare ? styles.homeStyle : styles.notHomeStyle}
          >
            {this.props.homeCare && (
              <View style={{ flex: 0.8 }}>
                <View style={{ flex: 1, flexDirection: 'row' }}>
                  <Text style={styles.leftColumn}>Name:</Text>
                  <Text style={styles.rightColumn}>
                    {this.props.patientName}
                  </Text>
                </View>
                <View style={{ flex: 1, flexDirection: 'row' }}>
                  <Text style={styles.leftColumn}>Gender:</Text>
                  <Text style={styles.rightColumn}>
                    {this.props.gender.charAt(0).toUpperCase() +
                      this.props.gender.slice(1)}
                  </Text>
                </View>
                <View style={{ flex: 1, flexDirection: 'row' }}>
                  <Text style={styles.leftColumn}>Phone:</Text>
                  <Text style={styles.rightColumn}>{this.props.phone}</Text>
                </View>
                <View style={{ flex: 1, flexDirection: 'row' }}>
                  <Text style={styles.leftColumn}>Status:</Text>
                  <Text style={styles.rightColumn}>{this.props.status}</Text>
                </View>
                <View style={{ flex: 1, flexDirection: 'row' }}>
                  <Text style={styles.leftColumn}>Address:</Text>
                  <Text style={styles.rightColumn}>
                    {this.props.address &&
                      this.props.address.replace('\n', ' ')}
                  </Text>
                </View>
                <View style={{ flex: 1, flexDirection: 'row' }}>
                  <Text style={styles.leftColumn}>Order Type:</Text>
                  <Text style={styles.rightColumn}>
                    {this.props.orderType !== undefined &&
                      (
                        this.props.orderType.charAt(0).toUpperCase() +
                        this.props.orderType.slice(1)
                      ).replace('_', ' ')}
                  </Text>
                </View>
              </View>
            )}
            {!this.props.homeCare && (
              <View style={{ flex: 1 }}>
                <View style={{ flex: 1, flexDirection: 'row' }}>
                  <Text style={styles.leftColumn}>Date:</Text>
                  <Text style={styles.rightColumn}>
                    {moment(this.props.date).format('MMM Do YYYY')}
                  </Text>
                </View>
                <View style={{ flex: 1, flexDirection: 'row' }}>
                  <Text style={styles.leftColumn}>Status:</Text>
                  <Text style={styles.rightColumn}>{this.props.status}</Text>
                </View>
                <View style={{ flex: 1, flexDirection: 'row' }}>
                  <Text style={styles.leftColumn}>Payment:</Text>
                  <Text style={[styles.rightColumn]}>{this.props.payment.status || 'Not given'}</Text>
                </View>
                <View style={{ flex: 1, flexDirection: 'row' }}>
                  <Text style={styles.leftColumn}>Address:</Text>
                  <Text style={styles.rightColumn}>
                    {this.props.address &&
                      this.props.address.replace('\n', ' ')}
                  </Text>
                </View>
                <View style={{ flex: 1, flexDirection: 'row' }}>
                  <Text style={styles.leftColumn}>Order Type:</Text>
                  <Text style={styles.rightColumn}>
                    {this.props.orderType !== undefined &&
                      (
                        this.props.orderType.charAt(0).toUpperCase() +
                        this.props.orderType.slice(1)
                      ).replace('_', ' ')}
                  </Text>
                </View>
              </View>
            )}
          </View>
          {!this.props.homeCare && (
            <View style={{ flex: 0.7, elevation: 2,}}>
              <ScrollView >
                <View style={{ flex: 1, paddingLeft: 1, paddingRight:1}}>
                  <View
                    style={styles.headingStyle}
                    width={'100%'}
                  >
                    <View
                      style={styles.viewStyle}
                      flex={0.3}
                      alignItems="flex-start"
                    >
                      <Text style={styles.textStyle}>Name</Text>
                    </View>

                    {!this.props.test && (
                      <View style={styles.viewStyle} flex={0.25}>
                        <Text style={styles.textStyle}>Quantity</Text>
                      </View>
                    )}

                    {this.props.test && (
                      <View
                        style={styles.viewStyle}
                        flex={0.6}
                        justifyContent="center"
                        alignItems="center"
                      >
                        <Text style={styles.textStyle}>Beneficiary</Text>
                      </View>
                    )}

                    <View
                      style={styles.viewStyle}
                      flex={0.2}
                      justifyContent="center"
                      alignItems="center"
                    >
                      <Text style={styles.textStyle}>Price</Text>
                    </View>
                    {!this.props.price && (
                      <View
                        style={styles.viewStyle}
                        flex={0.25}
                        alignItems="flex-end"
                      >
                        <Text style={[styles.textStyle, {textAlign: 'right'}]}>Sub Total</Text>
                      </View>
                    )}
                  </View>
                  <View style={{ borderBottomWidth: 1 }}>
                    {!this.props.test &&
                      arrCart.map((item, idx) => {
                        totalPrice +=
                          (item.count || item.quantity) * item.price;
                        return (
                          <CartItem
                            serial={idx + 1}
                            name={item.name}
                            quantity={item.count || item.quantity}
                            unitPrice={item.price}
                            subTotal={item.count || item.quantity * item.price}
                          />
                        );
                      })}
                    {this.props.test &&
                      arrCart.map((item, idx) => {
                        totalPrice = this.props.price;
                        return (
                          <CartItem
                            test={true}
                            serial={idx + 1}
                            name={item.name}
                            beneficiary={item.for.name}
                            subTotal={item.price}
                          />
                        );
                      })}
                  </View>
                </View>
                <View
                  style={{
                    flexDirection: 'row',
                    marginTop: 12,
                    width: '100%'
                  }}
                >
                  <View
                    style={{
                      justifyContent: 'center',
                      alignItems: 'flex-end',
                      flex: 0.6
                    }}
                  >
                    <Text
                      style={{
                        fontSize: moderateScale(18),
                        fontWeight: 'bold'
                      }}
                    >
                      Total :
                    </Text>
                  </View>

                  <View
                    style={{
                      justifyContent: 'center',
                      alignItems: 'flex-end',
                      flex: 0.4
                    }}
                  >
                    <Text style={{ fontSize: moderateScale(18) }}>
                      {totalPrice.toFixed(2)}/-
                    </Text>
                  </View>
                </View>
              </ScrollView>
            </View>
          )}
          {!this.props.homeCare && (
            <View
              style={{
                flex: 0.1,
                borderTopWidth: 0.5,
                borderTopColor: '#BCBDC0',
                paddingTop: verticalScale(20),
                justifyContent: 'center',
                alignItems: 'center',
                marginTop: moderateScale(5),
                paddingBottom: verticalScale(5)
              }}
            >
              <Button
                title="OK"
                containerStyle={{ width: '40%' }}
                buttonStyle={{
                  backgroundColor: '#60BB46',
                  borderRadius: 20
                }}
                titleStyle={{ fontSize: moderateScale(20) }}
                onPress={() =>
                  this.props.updateState({
                    [this.props.visibilityStateName]: !this.props.visibility
                  })
                }
              />
            </View>
          )}
          {this.props.homeCare && (
            <View
              style={{
                flex: 0.1,
                borderTopWidth: 0.5,
                borderTopColor: '#BCBDC0',
                paddingTop: verticalScale(20),
                justifyContent: 'center',
                alignItems: 'center',
                marginTop: moderateScale(5),
                paddingBottom: verticalScale(5)
              }}
            >
              <Button
                title="OK"
                containerStyle={{ width: '40%' }}
                buttonStyle={{
                  backgroundColor: '#60BB46',
                  borderRadius: 20
                }}
                titleStyle={{ fontSize: moderateScale(20) }}
                onPress={() =>
                  this.props.updateState({
                    [this.props.visibilityStateName]: !this.props.visibility
                  })
                }
              />
            </View>
          )}
        </View>
      </Modal>
    );
  }
}

const styles = StyleSheet.create({
  mainView: {
    flex: 1,
    marginTop: verticalScale(50),
    marginLeft: moderateScale(5),
    marginRight: moderateScale(5),
    marginBottom: verticalScale(30),
    borderRadius: 20,
    padding: moderateScale(15),
    backgroundColor: 'white'
  },
  headingStyle: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderTopWidth: 1
  },
  viewStyle: {
    justifyContent: 'center',
    alignItems: 'center',
    height: verticalScale(40),
  },
  textStyle: {
    fontSize: moderateScale(17)
  },

  leftColumn: {
    flex: 0.4,
    fontSize: moderateScale(18),
    paddingTop: verticalScale(5)
  },

  rightColumn: {
    flex: 0.6,
    fontSize: moderateScale(16),
    paddingTop: verticalScale(5)
  },

  homeStyle: {
    flex: 0.8,
    marginBottom: verticalScale(10)
  },

  notHomeStyle: {
    flex: 0.4,
    marginBottom: verticalScale(10)
  }
});

HistoryModal.defaultProps = {
  orderType: 'Not given',
  patientName: 'Not given',
  gender: 'Not given'
};
