import React, { Component } from 'react';
import { View, StyleSheet, Text, TouchableOpacity, Image } from 'react-native';
import Modal from 'react-native-modal';

import { moderateScale, verticalScale } from '../../constants/const_functions';

export default class PaymentModal extends Component {
  render() {
    console.log(this.props);
    return (
      <Modal
        isVisible={this.props.visibility}
        onBackButtonPress={() =>
          this.props.updateState({
            [this.props.visibilityStateName]: !this.props.visibility,
          })
        }
        onBackdropPress={() =>
          this.props.updateState({
            [this.props.visibilityStateName]: !this.props.visibility,
          })
        }
      >
        <View style={styles.mainView}>
          <TouchableOpacity
            style={styles.rowView}
            onPress={() => {
              this.props.updateState({
                [this.props.visibilityStateName]: !this.props.visibility,
              });
              this.props.handleSubmit('Cash on Delivery')
            }}
          >
            <View>
              <Image
                source={require('../../assets/cash-on-delivery.png')}
                style={styles.image}
                resizeMode="contain"
              />
            </View>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.rowView}
            onPress={() => {
              this.props.updateState({
                [this.props.visibilityStateName]: !this.props.visibility,
              });
              this.props.handleSubmit('Pay Online')
            }}
          >
            <View>
              <Image
                source={require('../../assets/payOnline.png')}
                style={styles.image}
                resizeMode="contain"
              />
            </View>
          </TouchableOpacity>
        </View>
      </Modal>
    );
  }
}

const styles = StyleSheet.create({
  mainView: {
    // flex: 1,
    // marginTop: verticalScale(50),
    // marginLeft: moderateScale(10),
    // marginRight: moderateScale(10),
    // marginBottom: verticalScale(30),
    borderRadius: 20,
    padding: moderateScale(15),
    backgroundColor: 'white',
  },

  rowView: {
    // flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 2,
    borderRadius: 10,
    margin: moderateScale(5),
    backgroundColor: '#ffffff',
    shadowOffset: { width: 3, height: 3 },
    shadowColor: 'grey',
    shadowOpacity: 0.25,
    shadowRadius: 5,
  },

  image: {
    width: moderateScale(150),
    height: verticalScale(80),
    borderRadius: 10,
  },
});
