import React, { Component } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  ScrollView
} from 'react-native';
import { Icon, Button, colors } from 'react-native-elements';
import { Button as NBbutton } from 'native-base';
import getRNDraftJSBlocks from 'react-native-draftjs-render';

import Modal from 'react-native-modal';
import {
  scale,
  verticalScale,
  moderateScale
} from '../../constants/const_functions';

/*
 * description: string or object  //mandatory
 * quantity: number or string  //mandatory
 * name: string
 * image: string
 */
export default (ItemDetailsModalView = props => {
  const {
    name = 'No name given',
    description,
    image,
    quantity,
    pharma,
    price,
    type,
    administration,
    interaction,
    indication
  } = props;

  const isOrder = !isNaN(quantity);

  var isDraftJs;
  if (description) isDraftJs = description.hasOwnProperty('entityMap');

  const customStyle = StyleSheet.flatten({
    'header-two': {
      fontSize: moderateScale(16)
    },

    'header-three': {
      fontSize: moderateScale(14)
    }
  });
  const blocks = isDraftJs
    ? getRNDraftJSBlocks({
        contentState: description,
        customStyles: customStyle
      })
    : {};

  var path = { path: '' };

  if (type === 'Liquid') {
    path = { path: require('../../assets/medicineIcon/liquid.png') };
  } else if (type === 'Syrup') {
    path = { path: require('../../assets/medicineIcon/liquid.png') };
  } else if (type === 'Suspension') {
    path = { path: require('../../assets/medicineIcon/liquid.png') };
  } else if (type === 'Powder for Suspension') {
    path = { path: require('../../assets/medicineIcon/liquid.png') };
  } else if (type === 'Tablet') {
    path = { path: require('../../assets/medicineIcon/tablet.png') };
  } else if (type === 'Capsule') {
    path = { path: require('../../assets/medicineIcon/capsules.png') };
  } else if (type === 'Topical medicines') {
    path = { path: require('../../assets/medicineIcon/topical.png') };
  } else if (type === 'Gel') {
    path = { path: require('../../assets/medicineIcon/topical.png') };
  } else if (type === 'Eye gel') {
    path = { path: require('../../assets/medicineIcon/topical.png') };
  } else if (type === 'Topical Solution') {
    path = { path: require('../../assets/medicineIcon/topical.png') };
  } else if (type === 'Cream') {
    path = { path: require('../../assets/medicineIcon/topical.png') };
  } else if (type === 'Ointment') {
    path = { path: require('../../assets/medicineIcon/topical.png') };
  } else if (type === 'Suppository') {
    path = { path: require('../../assets/medicineIcon/suppositories.png') };
  } else if (type === 'Eye Drops') {
    path = { path: require('../../assets/medicineIcon/drops.png') };
  } else if (type === 'Paediatric Drops') {
    path = { path: require('../../assets/medicineIcon/drops.png') };
  } else if (type === 'Inhaler') {
    path = { path: require('../../assets/medicineIcon/inhalers.png') };
  } else if (type === 'Mouthwash') {
    path = { path: require('../../assets/medicineIcon/inhalers.png') };
  } else if (type === 'Injection') {
    path = { path: require('../../assets/medicineIcon/injection.png') };
  } else if (type === 'Implants or patches') {
    path = { path: require('../../assets/medicineIcon/implants.png') };
  } else if (type === 'Buccal or sublingual tablets or liquids') {
    path = { path: require('../../assets/medicineIcon/buccal.png') };
  } else {
    path = { path: require('../../assets/customIcons/drug.png') };
  }

  console.log('generic name', props);
  return (
    <Modal
      // style={{ flex: 1 }}
      isVisible={props.visibility}
      onBackButtonPress={() =>
        props.updateState({ [props.visibilityStateName]: !props.visibility })
      }
      onBackdropPress={() =>
        props.updateState({ [props.visibilityStateName]: !props.visibility })
      }
    >
      <View style={styles.mainView}>
        <View style={styles.headerView}>
          <View style={styles.imageView}>
            <Image
              resizeMode='cover'
              source={
                type ? path.path : require('../../assets/image_placeholder.png')
              }
              style={styles.image}
            />
          </View>
          {name && (
            <Text
              style={{
                fontSize: moderateScale(20),
                color: 'black',
                padding: moderateScale(10)
              }}
            >
              {name}
            </Text>
          )}
        </View>

        <View style={styles.detailsView}>
          <ScrollView>
            {Boolean(props.genericName) && (
              <Text
                style={{
                  fontSize: moderateScale(14),
                  paddingTop: moderateScale(10)
                }}
              >
                Generic Name:{' '}
                <Text style={styles.text}>{'\n' + props.genericName}</Text>
              </Text>
            )}
            {Boolean(props.pharma) && (
              <Text
                style={{
                  fontSize: moderateScale(14),
                  paddingTop: moderateScale(10)
                }}
              >
                Pharmaceutical:{' '}
                <Text style={styles.text}>{'\n' + props.pharma}</Text>
              </Text>
            )}
            {Boolean(props.mfg) && (
              <Text
                style={{
                  fontSize: moderateScale(14),
                  paddingTop: moderateScale(10)
                }}
              >
                Manufaturer: <Text style={styles.text}>{'\n' + props.mfg}</Text>
              </Text>
            )}
            {Boolean(props.price) && (
              <Text
                style={{
                  fontSize: moderateScale(14),
                  paddingTop: moderateScale(10)
                }}
              >
                Price: <Text style={styles.text}>{'\n' + props.price}</Text>
              </Text>
            )}

            {Boolean(props.packsize) && (
              <Text
                style={{
                  fontSize: moderateScale(14),
                  paddingTop: moderateScale(10)
                }}
              >
                Pack size:{' '}
                <Text style={styles.text}>{'\n' + props.packsize}</Text>
              </Text>
            )}

            {props.strength !== ' ' && Boolean(props.strength) && (
              <Text
                style={{
                  fontSize: moderateScale(14),
                  paddingTop: moderateScale(10)
                }}
              >
                Strength:{' '}
                <Text style={styles.text}>{'\n' + props.strength}</Text>
              </Text>
            )}

            {Boolean(props.administration) && (
              <Text
                style={{
                  fontSize: moderateScale(14),
                  paddingTop: moderateScale(10)
                }}
              >
                Administration:{' '}
                <Text style={styles.text}>{'\n' + props.administration}</Text>
              </Text>
            )}

            {Boolean(props.indication) && (
              <Text
                style={{
                  fontSize: moderateScale(14),
                  paddingTop: moderateScale(10)
                }}
              >
                Indication:{' '}
                <Text style={styles.text}>{'\n' + props.indication}</Text>
              </Text>
            )}

            {Boolean(props.interaction) && (
              <Text
                style={{
                  fontSize: moderateScale(14),
                  paddingTop: moderateScale(10)
                }}
              >
                Interaction:{' '}
                <Text style={styles.text}>{'\n' + props.interaction}</Text>
              </Text>
            )}

            {description && (
              <Text
                style={{
                  fontSize: moderateScale(17),
                  color: 'black',
                  paddingTop: moderateScale(10)
                }}
              >
                Details:
              </Text>
            )}
          </ScrollView>
          {description && !isDraftJs && (
            <Text style={{ fontSize: moderateScale(15) }}>{description}</Text>
          )}
          {description && isDraftJs && <ScrollView>{blocks}</ScrollView>}
        </View>

        {!isNaN(quantity) && (
          <View style={styles.quantityView}>
            <View style={{ flex: 1, justifyContent: 'flex-start' }}>
              <Text
                style={{
                  fontSize: moderateScale(18),
                  color: 'black'
                  // paddingTop: moderateScale(10)
                }}
              >
                Quantity:
              </Text>
            </View>
            <View
              style={{
                flex: 1,
                // borderWidth: 1,
                // width: 100,
                flexDirection: 'row',
                // justifyContent: 'flex-end',
                // padding: moderateScale(10),
                alignItems: 'center',
                justifyContent: 'space-around',
              }}
            >

              <Icon
                name='minuscircleo'
                type='antdesign'
                onPress={props.reduceQuantity}
              />

              <Text
                style={{
                  // flex: 1,
                  fontSize: moderateScale(18)
                  // padding: moderateScale(5)
                }}
              >
                {props.quantity}
              </Text>

              <Icon
                name='pluscircleo'
                type='antdesign'
                onPress={props.addQuantity}
              />

            </View>
          </View>
        )}
        <View
          style={{ borderBottomWidth: 1, marginTop: 7, borderColor: '#F4F4F5' }}
        />
        {!isNaN(quantity) && (
          <View style={styles.buttonView}>
            <View
              style={{
                flex: 1,
                justifyContent: 'center',
                alignItems: 'center',
                marginRight: 7.5
              }}
            >
              <Button
                title='Cancel'
                type='outline'
                containerStyle={{ width: '100%' }}
                buttonStyle={{ borderRadius: 20 }}
                titleStyle={{ fontSize: moderateScale(20) }}
                onPress={() =>
                  props.updateState({
                    [props.visibilityStateName]: !props.visibility
                  })
                }
              />
            </View>

            <View
              style={{
                flex: 1,
                justifyContent: 'center',
                alignItems: 'center',
                marginLeft: 7.5
              }}
            >
              <Button
                title='Order'
                containerStyle={{ width: '100%' }}
                buttonStyle={{ backgroundColor: '#60BB46', borderRadius: 20 }}
                titleStyle={{ fontSize: moderateScale(20) }}
                onPress={() => props.handleOrder(props.item, props.quantity)}
              />
            </View>
          </View>
        )}
        {isNaN(quantity) && (
          <View style={styles.buttonView}>
            <Button
              title='Ok'
              containerStyle={{ width: '100%' }}
              buttonStyle={{ backgroundColor: '#60BB46', borderRadius: 20 }}
              titleStyle={{ fontSize: moderateScale(15) }}
              onPress={() =>
                props.updateState({
                  [props.visibilityStateName]: !props.visibility
                })
              }
            />
          </View>
        )}
      </View>
    </Modal>
  );
});

const styles = StyleSheet.create({
  mainView: {
    // flex: 1,
    // marginTop: verticalScale(80),
    // marginLeft: moderateScale(5),
    // marginRight: moderateScale(5),
    // marginBottom: verticalScale(10),
    // borderRadius: 20,
    // padding: moderateScale(15),
    backgroundColor: 'white',
    borderRadius: 10,
    marginTop: verticalScale(20)
  },

  text: {
    color: 'black',
    fontSize: moderateScale(16)
  },

  headerView: {
    // flex: 3,
    height: verticalScale(130),
    justifyContent: 'flex-end',
    alignItems: 'center',
    borderBottomColor: '#F4F4F5',
    borderBottomWidth: 1,
    marginTop: verticalScale(-50)
  },

  detailsView: {
    // flex: 5,
    height: verticalScale(300),
    margin: 10,
    marginTop: 0
  },

  quantityView: {
    // flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    height: 30,
    marginLeft: 10,
    marginRight: 10,
  },

  buttonView: {
    // flex: 1,
    height: 50,
    margin: 10,
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'center'
  },

  imageView: {
    alignItems: 'center',
    justifyContent: 'center',
    width: moderateScale(90),
    height: moderateScale(90),
    borderRadius: 100,
    borderColor: 'grey',
    borderWidth: 0.5,
    backgroundColor: 'white'
  },

  image: {
    alignSelf: 'center',
    width: moderateScale(65),
    height: moderateScale(65)
  }
});
