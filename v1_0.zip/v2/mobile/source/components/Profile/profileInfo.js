import React, { Component } from 'react';
import {
  View,
  Image,
  ScrollView,
  Text,
  StyleSheet,
  Dimensions,
  TouchableOpacity
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { Fab } from 'native-base';
import { Icon } from 'react-native-elements';
import moment from 'moment';

import Header from '../common/header';
import { getUserAsync } from '../../constants/const_functions';
import {
  scale,
  verticalScale,
  moderateScale
} from '../../constants/const_functions';
import SpinView from '../common/spinner';

export default class ProfileInfo extends Component {
  constructor(props) {
    super(props);
    this.state = {
      active: true,
      _id: '',
      user: {},
      profile: {},
      reload: false,
      isLoaded: false
    };
    this.fetchUser();
  }

  async fetchUser() {
    const user = JSON.parse(await getUserAsync());
    console.log(user);
    this.setState(
      {
        user: user,
        _id: user._id,
        profile: user.profile
      },
      () => this.setState({ isLoaded: true })
    );
  }

  calculateAge(dateString) {
    var age = moment().diff(moment(dateString, 'YYYY-MM-DD'), 'years');
    console.log(typeof dateString);
    return age;
  }

  handleReload() {
    this.fetchUser();
    this.setState({ reload: true });
  }

  render() {
    const { width, height } = Dimensions.get('window');
    const notgiven = 'Not given';

    if (!this.state.reload) {
      if (this.props.navigation.getParam('isReload')) {
        this.handleReload();
      }
    }

    if (!this.state.isLoaded)
      return (
        <View style={{ flex: 1 }}>
          <Header
            iconLeft='arrowleft'
            text='Profile'
            iconRight='shoppingcart'
            navigation={this.props.navigation}
          />
          <SpinView />
        </View>
      );

    return (
      <View style={styles.mainView}>
        <Header
          text='Profile'
          iconLeft='arrowleft'
          iconRight='shoppingcart'
          navigation={this.props.navigation}
        />
        <ScrollView
          showsVerticalScrollIndicator={false}
          // contentContainerStyle={{ height: 900 }}
        >
          <View style={styles.headerView}>
            <View
              style={{
                flex: 1,
                flexDirection: 'row',
                justifyContent: 'flex-end',
                alignItems: 'flex-end',
                backgroundColor: '#37C6F4',
                height: 180
              }}
            >
              <TouchableOpacity
                onPress={() =>
                  this.props.navigation.navigate('ProfileUpdate', {
                    profile: this.state.profile,
                    id: this.state._id
                  })
                }
                style={{
                  flex: 1,
                  flexDirection: 'row',
                  justifyContent: 'flex-end',
                  paddingRight: moderateScale(8)
                }}
              >
                <Icon name='pencil' type='evilicon' color='white' size={20} />
                <Text style={{ fontStyle: 'italic', color: 'white' }}>
                  Edit Profile
                </Text>
              </TouchableOpacity>
            </View>
          </View>
          <View
            style={{
              position: 'absolute',
              top: 95,
              left: '50%',
              marginLeft: -75,
              borderRadius: 100,
              width: 150,
              height: 150,
              backgroundColor: 'white',
              overflow: 'hidden'
            }}
          >
            <Image
              source={{ uri: this.state.user.profile.avatar }}
              style={styles.image}
            />
          </View>
          <View style={styles.bodyView}>
            <View style={styles.nameView}>
              <Text
                style={{
                  fontSize: moderateScale(30),
                  color: '#1285ff',
                  fontWeight: 'bold'
                }}
              >
                {this.state.profile.name}
              </Text>
              {this.state.profile.dob !== undefined && (
                <Text
                  style={{ fontSize: moderateScale(18), fontWeight: 'bold' }}
                >
                  {this.calculateAge(this.state.profile.dob)},{' '}
                  {this.state.profile.Gender || this.state.profile.gender}
                </Text>
              )}
              {/* {this.state.profile.dob !== undefined && (
                <Text
                  style={{ fontSize: moderateScale(17), fontWeight: 'bold' }}
                >
                  {moment(this.state.profile.dob).format('MMM Do YYYY')}
                </Text>
              )} */}
            </View>

            <Text
              style={{
                fontSize: 18,
                fontWeight: 'bold',
                paddingHorizontal: 10,
                paddingTop: 10,
                paddingBottom: 10
              }}
            >
              Personal Info:
            </Text>
            <View style={{ flex: 3.5 }}>
              <View style={{ flex: 1, flexDirection: 'row' }}>
                <View
                  style={{
                    flex: 1,
                    alignItems: 'center',
                    justifyContent: 'center',
                    // borderRightWidth: 0.5,
                    borderColor: '#CCCCCC'
                  }}
                >
                  <Icon
                    name='email'
                    type='entypo'
                    color='#0076BE'
                    size={18}
                    containerStyle={{ paddingBottom: 5 }}
                  />
                  <Text style={styles.text}>
                    {this.state.profile.email || 'Not given'}
                  </Text>
                </View>

                <View
                  style={{
                    borderRightWidth: 0.5,
                    borderColor: '#CCCCCC',
                    height: moderateScale(50),
                    marginTop: moderateScale(10),
                    marginBottom: moderateScale(10),
                    opacity: 0.5
                  }}
                />

                <View
                  style={{
                    flex: 1,
                    alignItems: 'center',
                    justifyContent: 'center',
                    // borderWidth: 0.5,
                    // borderLeftWidth: 0,
                    borderColor: '#CCCCCC'
                  }}
                >
                  <Icon
                    name='idcard'
                    type='antdesign'
                    color='#0076BE'
                    size={18}
                    containerStyle={{ paddingBottom: 5 }}
                  />
                  <Text style={styles.text}>
                    {this.state.profile.nId || 'Not given'}
                  </Text>
                </View>
              </View>
              <View
                style={{ flexDirection: 'row', justifyContent: 'space-around' }}
              >
                <View
                  style={{
                    borderTopWidth: 0.5,
                    width: width / 4,
                    // flex: 1,
                    borderColor: '#CCCCCC',
                    opacity: 0.5
                  }}
                />
                <View
                  style={{
                    // flex: 1,
                    borderTopWidth: 0.5,
                    borderColor: '#CCCCCC',
                    width: width / 4,
                    opacity: 0.5
                  }}
                />
              </View>
              <View style={{ flex: 1, flexDirection: 'row' }}>
                <View
                  style={{
                    flex: 1,
                    alignItems: 'center',
                    justifyContent: 'center',
                    // borderWidth: 1,
                    borderTopWidth: 0,
                    borderColor: '#CCCCCC'
                  }}
                >
                  <Icon
                    name='address-book'
                    type='font-awesome'
                    color='#0076BE'
                    size={18}
                    containerStyle={{ paddingBottom: 5 }}
                  />
                  <Text style={styles.text}>
                    {this.state.profile.address || 'Not given'}
                  </Text>
                </View>

                <View
                  style={{
                    borderRightWidth: 0.5,
                    borderColor: '#CCCCCC',
                    height: moderateScale(50),
                    marginTop: moderateScale(10),
                    marginBottom: moderateScale(10),
                    opacity: 0.5
                  }}
                />

                <View
                  style={{
                    flex: 1,
                    // flexDirection: 'row',
                    // backgroundColor: '#60BB46',
                    alignItems: 'center',
                    justifyContent: 'center',
                    borderColor: '#CCCCCC'
                    // borderBottomWidth: 1,
                    // borderRightWidth: 1,
                  }}
                >
                  <Icon
                    name='phone'
                    type='font-awesome'
                    color='#0076BE'
                    size={18}
                    containerStyle={{ paddingBottom: 5 }}
                  />
                  <Text style={styles.text}>
                    {this.state.profile.phone || 'Not given'}
                  </Text>
                </View>
              </View>
            </View>

            {/* <Text style={{ fontSize: 18, padding: 10, fontWeight: 'bold' }}>
              Medical Record:
            </Text> */}

            <View
              style={{
                flex: 2,
                // padding: 10,
                flexDirection: 'row',
                justifyContent: 'space-evenly'
              }}
            >
              <View
                style={{
                  // backgroundColor: '#37C6F4',
                  // borderRadius: 100,
                  height: moderateScale(90),
                  width: moderateScale(100),
                  // borderRightWidth: 1,
                  borderColor: '#CCCCCC'
                }}
              >
                <View
                  style={{
                    flex: 1,
                    justifyContent: 'center',
                    alignItems: 'center'
                  }}
                >
                  <Text
                    style={{ fontSize: moderateScale(45), color: '#37C6F4' }}
                  >
                    {this.state.profile.height || (
                      <Text style={{ fontSize: 18 }}>Not given</Text>
                    )}
                  </Text>
                  <Text style={styles.text}>Height</Text>
                </View>
              </View>
              <View
                style={{
                  borderRightWidth: 0.5,
                  borderColor: '#CCCCCC',
                  height: moderateScale(50),
                  marginTop: moderateScale(25),
                  opacity: 0.5
                }}
              />

              <View
                style={{
                  // backgroundColor: '#99CA3C',
                  // borderRadius: 100,
                  height: moderateScale(90),
                  width: moderateScale(100)
                }}
              >
                <View
                  style={{
                    flex: 1,
                    justifyContent: 'center',
                    alignItems: 'center'
                  }}
                >
                  <Text
                    style={{ fontSize: moderateScale(45), color: '#99CA3C' }}
                  >
                    {this.state.profile.weight || (
                      <Text style={{ fontSize: 18 }}>Not given</Text>
                    )}
                  </Text>
                  <Text style={styles.text}>Weight</Text>
                </View>
              </View>

              <View
                style={{
                  borderRightWidth: 0.5,
                  borderColor: '#CCCCCC',
                  height: moderateScale(50),
                  marginTop: moderateScale(25),
                  opacity: 0.5
                }}
              />

              <View
                style={{
                  // backgroundColor: '#60BB46',
                  // borderRadius: 100,
                  // borderLeftWidth: 1,
                  // borderColor: '#CCCCCC',
                  height: moderateScale(90),
                  width: moderateScale(100)
                }}
              >
                <View
                  style={{
                    flex: 1,
                    justifyContent: 'center',
                    alignItems: 'center'
                  }}
                >
                  <Text
                    style={{ fontSize: moderateScale(45), color: '#60BB46' }}
                  >
                    {this.state.profile.bloodGroup || (
                      <Text style={{ fontSize: 18 }}>Not given</Text>
                    )}
                  </Text>
                  <Text style={styles.text}>Blood Group</Text>
                </View>
              </View>
            </View>
            {this.state.profile.contactName && (
              <Text style={{ fontSize: 18, padding: 10, fontWeight: 'bold' }}>
                Alternate Contact Info: {this.state.profile.contactName}
              </Text>
            )}
            {this.state.profile.contactName && (
              <View style={{ flex: 2, flexDirection: 'row' }}>
                <View
                  style={{
                    flex: 1,
                    alignItems: 'center',
                    justifyContent: 'center',
                    // borderWidth: 1,
                    // borderLeftWidth: 0,
                    borderColor: '#CCCCCC'
                  }}
                >
                  <Icon
                    name='email'
                    type='entypo'
                    color='#0076BE'
                    size={18}
                    containerStyle={{ paddingBottom: 5 }}
                  />
                  <Text style={styles.text}>
                    {this.state.profile.contactEmail || 'Not given'}
                  </Text>
                </View>

                <View
                  style={{
                    borderRightWidth: 0.5,
                    borderColor: '#CCCCCC',
                    height: moderateScale(50),
                    marginTop: moderateScale(15),
                    marginBottom: moderateScale(15),
                    opacity: 0.5
                  }}
                />

                <View
                  style={{
                    flex: 1,
                    // flexDirection: 'row',
                    // backgroundColor: '#37C6F4',
                    alignItems: 'center',
                    justifyContent: 'center',
                    // borderWidth: 1,
                    // borderLeftWidth: 0,
                    borderColor: '#CCCCCC'
                  }}
                >
                  <Icon
                    name='phone'
                    type='font-awesome'
                    color='#0076BE'
                    size={18}
                    containerStyle={{ paddingBottom: 5 }}
                  />
                  <Text style={styles.text}>
                    {this.state.profile.contactNumber || 'Not given'}
                  </Text>
                </View>
              </View>
            )}
          </View>
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  mainView: {
    flex: 1
  },

  headerView: {
    flex: 1.75,
    justifyContent: 'flex-end',
    alignContent: 'flex-end'
  },

  bodyView: {
    flex: 7.75,
    marginTop: 70
  },

  nameView: {
    flex: 2.5,
    justifyContent: 'flex-end',
    alignItems: 'center'
  },

  text: {
    color: '#939598',
    fontSize: 15
  },

  image: {
    // position: 'absolute',
    // top: 95,
    // left: '50%',
    // marginLeft: -75,
    // borderRadius: 100,
    width: 150,
    height: 150,
    backgroundColor: 'white'
  }
});
