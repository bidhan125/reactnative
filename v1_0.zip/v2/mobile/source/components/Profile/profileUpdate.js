import React, { Component } from 'react';
import {
  Alert,
  Platform,
  StyleSheet,
  Text,
  View,
  Dimensions,
  Image,
  TextInput,
  Picker,
  ScrollView,
  AsyncStorage,
  KeyboardAvoidingView,
  TouchableOpacity,
  Modal,
  PixelRatio
} from 'react-native';
import {
  Form,
  Item as FormItem,
  Input,
  Label,
  Title,
  Container,
  Picker as PickerNative,
  Icon as IconNative,
  Button as ButtonN
} from 'native-base';
import Meteor from 'react-native-meteor';
import { Accounts } from 'react-native-meteor';
import DatePicker from 'react-native-datepicker';
import NavButton from '../common/navigationButton';
import ImagePicker from 'react-native-image-picker';
import { RNS3 } from 'react-native-aws3';
import { StackActions, NavigationActions } from 'react-navigation';
import TextInputMask from 'react-native-text-input-mask';

import ChangePasswordModal from '../Modal/changePasswordModal';
import SpinView from '../common/spinner';
import Header from '../common/header';
import {
  scale,
  verticalScale,
  moderateScale,
  validation,
  logout
} from '../../constants/const_functions';
import { blood_group } from '../../constants/const_strings';
import { optionsS3 } from '../../configs/AppConfig';
import { Icon, Button, Avatar } from 'react-native-elements';

const { width, height } = Dimensions.get('window');

export default class ProfileUpdate extends Component {
  constructor(props) {
    super(props);
    const { navigation } = this.props;
    console.log(navigation.state.params);
    this.state = {
      _id: navigation.getParam('id'),
      chosenGender: navigation.getParam('profile').Gender,
      chosenBloodGrp: navigation.getParam('profile').bloodGroup,
      name: navigation.getParam('profile').name,
      date: navigation.getParam('profile').dob,
      phone: navigation.getParam('profile').phone,
      currentPassword: undefined,
      password: undefined,
      password1: undefined,
      height: navigation.getParam('profile').height,
      weight: navigation.getParam('profile').weight,
      email: navigation.getParam('profile').email,
      nId: navigation.getParam('profile').nId,
      address: navigation.getParam('profile').address,
      contactName: navigation.getParam('profile').contactName,
      contactNumber: navigation.getParam('profile').contactNumber,
      contactEmail: navigation.getParam('profile').contactEmail,
      isModalVisible: false,
      processing: false,
      avatarSource: null,
      updateAvatarModalVisible: false,
      currentPhoto: navigation.getParam('profile').avatar,
      upStatus: false,
      isFocus: false
    };
  }

  // TODO: @Mostafiz vai

  selectPhotoTapped() {
    const options = {
      color: '#464646',
      quality: 1.0,
      maxWidth: 500,
      maxHeight: 500,
      storageOptions: {
        skipBackup: true
      }
    };

    ImagePicker.showImagePicker(options, response => {
      console.log('Response - ', response);

      if (response.didCancel) {
        console.log('User cancelled photo picker');
      } else if (response.error) {
        console.log('ImagePicker Error: ', response.error);
      } else if (response.customButton) {
        console.log('User tapped custom button: ', response.customButton);
      } else {
        const source = { uri: response.uri };
        console.log(source);
        this.setState({
          avatarSource: source
        });
      }
    });
  }

  uploadPhoto() {
    console.log('dfsfs');
    const file = {
      uri: this.state.avatarSource.uri,
      name: this.state.name + Math.random() + 'propic.png',
      type: 'image/png'
    };
    // console.log(file);
    RNS3.put(file, optionsS3).then(responseS3 => {
      // console.log('RNS3 put method called...');
      // console.log('response received... ', responseS3);
      if (responseS3.status !== 201) {
        throw new Error('Failed to upload image to S3');
      }
      this.setState(
        {
          avatarSource: responseS3.body.postResponse.location,
          currentPhoto: responseS3.body.postResponse.location,
          upStatus: true
        },
        () => {
          this.handleSubmit();
        }
      );
    });
    // .progress((e) => console.log(e.percent));
  }

  handleSubmit() {
    const {
      _id,
      chosenGender,
      chosenBloodGrp,
      name,
      date,
      phone,
      password,
      password1,
      height,
      weight,
      email,
      nId,
      address,
      contactName,
      contactNumber,
      contactEmail,
      avatarSource,
      currentPhoto
    } = this.state;

    if (this.state.upStatus === false) {
      if (validation(email, 'isEmail') !== true) return;
      if (validation(name, 'isName') !== true) return;
      // if (validation(date, 'isDob') !== true) return;
      if (validation(phone, 'isPhone') !== true) return;
    }

    if (contactEmail !== undefined) {
      if (validation(contactEmail, 'isEmail') !== true) return;
    }
    if (contactNumber !== undefined) {
      if (validation(contactNumber, 'isPhone') !== true) return;
    }

    this.setState({ processing: true });

    data = {
      id: _id,
      name: name,
      height: height,
      weight: weight,
      email: email,
      nId: nId,
      phone: phone,
      address: address,
      bloodGroup: chosenBloodGrp,
      Gender: chosenGender,
      dob: date,
      contactName: contactName,
      contactNumber: contactNumber,
      contactEmail: contactEmail,
      avatar: currentPhoto
    };

    console.log(this.state);

    Meteor.call('updateProfile', data, (err, res) => {
      console.log(err, res);
      this.setState({ processing: false, upStatus: false });
      if (err) {
        alert(
          'Sorry! Failed to submit your request at this moment. Please try again later'
        );
      } else if (res) {
        Alert.alert(
          'Success',
          'Congratulations! Your profile has been updated successfully! Thank you!',
          [
            {
              text: 'OK',
              onPress: () => {
                this.setState({ updateAvatarModalVisible: false });
                setTimeout(() => {
                  AsyncStorage.setItem(
                    'user',
                    JSON.stringify(Meteor.user()),
                    () => {
                      if (this.props.navigation.getParam('isNavigationReset')) {
                        const resetAction = StackActions.reset({
                          index: 0,
                          actions: [
                            NavigationActions.navigate({
                              routeName: 'Home',
                              params: { isReload: true }
                            })
                          ]
                        });
                        this.props.navigation.dispatch(resetAction);
                      } else {
                        this.props.navigation.navigate('ProfileInfo', {
                          isReload: true
                        });
                      }
                    }
                  );
                }, 1000);
              }
            }
          ],
          { cancelable: false }
        );
        console.log(Meteor.user());
      }
    });
  }

  updateState(obj) {
    this.setState(obj);
  }

  handlePasswordChange() {
    const { currentPassword, password, password1 } = this.state;
    console.log('passwords', currentPassword, password);
    if (password !== password1) {
      alert("Sorry! Passwords don't match. ");
      return;
    } else {
      Accounts.changePassword(currentPassword, password, res => {
        console.log(res);
        if (!res) {
          console.log('successfully changed pasword');
          this.setState({
            isModalVisible: !this.state.isModalVisible
          });
          Alert.alert(
            'Success',
            'Congratulations! Your password has been updated successfully! Please login again!'
          );
          logout();
          this.props.navigation.navigate('LogIn');
        } else if (res) {
          console.log(res.message);
          alert('Sorry! You gave wrong password');
        }
      });
    }
  }

  handleUpdateProfilePicture() {
    console.log('Update Profile Picture');
    this.setState({ processing: !this.state.processing });
    this.uploadPhoto();
  }

  render() {
    const { avatarSource, updateAvatarModalVisible, currentPhoto } = this.state;
    console.log(avatarSource);

    if (this.state.processing) {
      return <SpinView />;
    }

    return (
      <KeyboardAvoidingView style={styles.container}>
        <Header
          text='Edit Profile'
          iconLeft='arrowleft'
          navigation={this.props.navigation}
        />
        <ChangePasswordModal
          visibility={this.state.isModalVisible}
          visibilityStateName='isModalVisible'
          updateState={this.updateState.bind(this)}
          handlePasswordChange={this.handlePasswordChange.bind(this)}
        />
        <Modal
          animationType='slide'
          transparent={false}
          visible={this.state.updateAvatarModalVisible}
          onRequestClose={() => {
            this.setState({
              updateAvatarModalVisible: !this.state.updateAvatarModalVisible,
              avatarSource: undefined
            });
          }}
        >
          <View
            style={{
              flex: 1,
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center'
            }}
          >
            <TouchableOpacity onPress={() => this.selectPhotoTapped()}>
              <View style={[styles.avatar, styles.avatarContainer]}>
                {avatarSource === null ? (
                  <Icon
                    name='camera'
                    type='entypo'
                    size={60}
                    color='#0fc9ff'
                    align='right'
                  />
                ) : (
                  <Image style={styles.avatar} source={avatarSource} />
                )}
              </View>
            </TouchableOpacity>
            <View style={{ margin: 10 }} />
            {avatarSource && (
              <ButtonN
                style={[
                  styles.confirmButton,
                  {
                    width: width * 0.6,
                    alignItems: 'center',
                    marginLeft: width * 0.2
                  }
                ]}
                block
                info
                onPress={() => this.handleUpdateProfilePicture()}
              >
                <Text style={styles.buttonText}>Update Profile Picture</Text>
              </ButtonN>
            )}
          </View>
        </Modal>
        <ScrollView
          style={styles.scrollViewStyle}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{
            justifyContent: 'flex-start',
            alignItems: 'center'
          }}
        >
          <View style={styles.logoStyle} height={height * 0.2}>
            <Avatar
              rounded
              source={{ uri: currentPhoto }}
              size={moderateScale(150)}
              showEditButton
              editButton={{
                reverse: true,
                underlayColor: '#fffff',
                size: moderateScale(20),
                name: 'mode-edit',
                type: 'material',
                color: '#1285ff',
                containerStyle: { top: -12, right: 4 }
              }}
              overlayContainerStyle={{ backgroundColor: 'transparent' }}
              containerStyle={{
                borderWidth: 1,
                borderColor: '#CCCCCC'
              }}
              onEditPress={() =>
                this.setState({
                  updateAvatarModalVisible: !updateAvatarModalVisible
                })
              }
            />
          </View>

          <View
            style={styles.formViewStyle}
            width={width - 25}
            height={verticalScale(800)}
          >
            <Form style={styles.formStyle} width={'100%'}>
              <FormItem floatingLabel style={styles.itemStyle}>
                <Label style={{ fontSize: moderateScale(15) }}>Name</Label>
                <Input
                  style={{ fontSize: moderateScale(15) }}
                  value={this.state.name}
                  editable={true}
                  onChangeText={name => this.setState({ name: name })}
                  onSubmitEditing={() => this.phone._root.focus()}
                  returnKeyType='next'
                />
              </FormItem>

              <View
                style={{
                  flex: 0.125,
                  flexDirection: 'row',
                  alignItems: 'flex-end',
                  justifyContent: 'space-between'
                }}
              >
                <View style={{ flex: 0.45, justifyContent: 'center' }}>
                  <Text
                    style={{
                      fontSize: moderateScale(17),
                      marginLeft: moderateScale(15),
                      textAlignVertical: 'center',
                      paddingBottom: 8
                    }}
                  >
                    Date of Birth
                  </Text>
                </View>
                <View
                  style={{
                    flex: 0.55,
                    alignItems: 'center',
                    justifyContent: 'flex-end',
                    borderBottomWidth: 1,
                    borderBottomColor: '#d5d9e2'
                  }}
                >
                  <DatePicker
                    date={this.state.date}
                    mode='date'
                    format='YYYY-MM-DD'
                    placeholder='Select date'
                    maxDate={new Date()}
                    onDateChange={date => {
                      this.setState({ date: date });
                    }}
                    iconComponent={<Icon name='calendar' type='antdesign' />}
                    customStyles={{
                      dateIcon: {
                        // position: 'absolute',
                        // left: 0,
                        // top: 4,
                        // marginLeft: 0,
                        // height: moderateScale(25)
                      },

                      dateInput: {
                        borderWidth: 0
                      }
                    }}
                  />
                </View>
              </View>

              <Form
                style={{
                  flex: 0.125,
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'flex-end',
                  marginLeft: 8
                }}
                alignItems='flex-end'
              >
                <View
                  style={{
                    flex: 0.5,
                    marginLeft: 5,
                    alignSelf: 'flex-end',
                    fontSize: moderateScale(15),
                    borderBottomWidth: 1,
                    borderBottomColor: '#d5d9e2'
                  }}
                >
                  {(Platform.OS == 'android' && (
                    <Picker
                      selectedValue={this.state.chosenGender}
                      mode='dropdown'
                      onValueChange={(itemValue, itemIndex) =>
                        this.setState({ chosenGender: itemValue })
                      }
                    >
                      <Picker.Item label='GENDER' value='key0' />
                      <Picker.Item label='Male' value='Male' />
                      <Picker.Item label='Female' value='Female' />
                      <Picker.Item label='Other' value='Other' />
                    </Picker>
                  )) || (
                    <PickerNative
                      iosIcon={<IconNative name='arrow-down' />}
                      selectedValue={this.state.chosenGender}
                      mode='dropdown'
                      onValueChange={(itemValue, itemIndex) =>
                        this.setState({ chosenGender: itemValue })
                      }
                    >
                      <PickerNative.Item label='GENDER' value='key0' />
                      <PickerNative.Item label='Male' value='Male' />
                      <PickerNative.Item label='Female' value='Female' />
                      <PickerNative.Item label='Other' value='Other' />
                    </PickerNative>
                  )}
                </View>
                <View
                  style={{
                    flex: 0.5,
                    marginLeft: 5,
                    alignSelf: 'flex-end',
                    fontSize: moderateScale(15),
                    borderBottomWidth: 1,
                    borderBottomColor: '#d5d9e2'
                  }}
                >
                  {(Platform.OS == 'android' && (
                    <Picker
                      selectedValue={this.state.chosenBloodGrp}
                      mode='dropdown'
                      onValueChange={(itemValue, itemIndex) =>
                        this.setState({ chosenBloodGrp: itemValue })
                      }
                    >
                      <Picker.Item label='Blood group' value={undefined} />
                      {blood_group.map(item => (
                        <Picker.Item label={item} value={item} />
                      ))}
                    </Picker>
                  )) || (
                    <PickerNative
                      iosIcon={<IconNative name='arrow-down' />}
                      selectedValue={this.state.chosenBloodGrp}
                      mode='dropdown'
                      onValueChange={(itemValue, itemIndex) =>
                        this.setState({ chosenBloodGrp: itemValue })
                      }
                    >
                      <PickerNative.Item
                        label='Blood group'
                        value={undefined}
                      />
                      {blood_group.map(item => (
                        <PickerNative.Item label={item} value={item} />
                      ))}
                    </PickerNative>
                  )}
                </View>
              </Form>

              <FormItem floatingLabel style={styles.itemStyle}>
                <Label style={{ fontSize: moderateScale(15) }}>
                  Phone Number
                </Label>
                <Input
                  getRef={input => {
                    this.phone = input;
                  }}
                  onChangeText={phone => this.setState({ phone: phone })}
                  value={this.state.phone}
                  editable={false}
                  keyboardType='phone-pad'
                  onSubmitEditing={() => this.height._root.focus()}
                  returnKeyType='next'
                />
              </FormItem>

              <Form style={styles.dualItemStyle}>
                <View
                  style={{
                    flex: 0.45,
                    flexDirection: 'row',
                    marginTop: 10
                  }}
                >
                  <View floatingLabel style={{ flex: 0.75, paddingLeft: 15 }}>
                    <Text
                      style={{
                        fontSize: 16,
                        top: !this.state.height && !this.state.isFocus ? 35: 7,
                        
                      }}
                    >
                      Height
                    </Text>
                    {/* <Input
                      getRef={input => {
                        this.height = input;
                      }}
                      value={this.state.height}
                      editable={true}
                      onChangeText={height => {
                        if (height.length===1) {
                          height = height+'\' '
                        } if (height.length ==4) {
                          height = height+'\'\''
                        }
                        this.setState({ height: height });
                      }}
                      keyboardType='number-pad'
                      onSubmitEditing={() => this.weight._root.focus()}
                      returnKeyType='next'
                    /> */}
                    <TextInputMask
                      refInput={ref => {
                        this.input = ref;
                      }}
                      // getRef={input => {
                      //   this.height = input;
                      // }}
                      value={this.state.height}
                      style={{
                        textAlignVertical: 'bottom',
                        borderBottomWidth: 0.5,
                        paddingBottom: 0,
                        // paddingTop: 10,
                        fontSize: 16
                      }}
                      onFocus={() => this.setState({isFocus: true})}
                      onBlur={() => this.setState({isFocus: false})}
                      keyboardType='numeric'
                      returnKeyType='next'
                      onChangeText={(formatted, height) => {
                        this.setState({ height });
                        console.log(formatted); // +1 (123) 456-78-90
                        console.log(height); // 1234567890
                      }}
                      mask={"[0]' [00]''"}
                    />
                  </View>
                  <View style={{ justifyContent: 'flex-end', flex: 0.25 }}>
                    <Text style={{ fontWeight: 'bold' }}> FT</Text>
                  </View>
                </View>

                <Form style={{ flex: 0.45, flexDirection: 'row' }}>
                  <FormItem floatingLabel style={{ flex: 0.75 }}>
                    <Label style={{ fontSize: 16 }}>Weight</Label>
                    <Input
                      getRef={input => {
                        this.weight = input;
                      }}
                      maxLength={3}
                      value={this.state.weight}
                      editable={true}
                      onChangeText={weight => this.setState({ weight: weight })}
                      keyboardType='number-pad'
                      onSubmitEditing={() => this.email._root.focus()}
                      returnKeyType='next'
                    />
                  </FormItem>
                  <View style={{ justifyContent: 'flex-end', flex: 0.25 }}>
                    <Text style={{ fontWeight: 'bold' }}> KG</Text>
                  </View>
                </Form>
              </Form>

              <FormItem floatingLabel style={styles.itemStyle}>
                <Label style={{ fontSize: moderateScale(15) }}>
                  Email Address
                </Label>
                <Input
                  getRef={input => {
                    this.email = input;
                  }}
                  value={this.state.email}
                  editable={true}
                  keyboardType='email-address'
                  onChangeText={email => this.setState({ email: email })}
                  onSubmitEditing={() => this.nId._root.focus()}
                  returnKeyType='next'
                />
              </FormItem>

              <FormItem floatingLabel style={styles.itemStyle}>
                <Label style={{ fontSize: moderateScale(15) }}>
                  National ID number
                </Label>
                <Input
                  getRef={input => {
                    this.nId = input;
                  }}
                  keyboardType='number-pad'
                  value={this.state.nId}
                  editable={true}
                  onChangeText={nId => this.setState({ nId: nId })}
                  returnKeyType='next'
                  onSubmitEditing={() => this.address._root.focus()}
                />
              </FormItem>
              <FormItem floatingLabel style={styles.itemStyle}>
                <Label style={{ fontSize: moderateScale(15) }}>Address</Label>
                <Input
                  getRef={input => {
                    this.address = input;
                  }}
                  keyboardType='default'
                  value={this.state.address}
                  editable={true}
                  onChangeText={address => this.setState({ address: address })}
                  returnKeyType='next'
                  onSubmitEditing={() => this.contactName._root.focus()}
                />
              </FormItem>
              <Text
                style={{
                  paddingTop: 10,
                  paddingLeft: 5,
                  fontSize: moderateScale(20),
                  fontWeight: 'bold'
                }}
              >
                Contact Person Details
                <Text style={{ fontSize: 15, fontWeight: 'normal' }}>
                  (Optional)
                </Text>
              </Text>
              <FormItem floatingLabel style={styles.itemStyle}>
                <Label style={{ fontSize: moderateScale(15) }}>
                  Contact Person Name
                </Label>
                <Input
                  getRef={input => {
                    this.contactName = input;
                  }}
                  keyboardType='default'
                  value={this.state.contactName}
                  editable={true}
                  onChangeText={contactName =>
                    this.setState({ contactName: contactName })
                  }
                  returnKeyType='next'
                  onSubmitEditing={() => this.contactNumber._root.focus()}
                />
              </FormItem>
              <FormItem floatingLabel style={styles.itemStyle}>
                <Label style={{ fontSize: moderateScale(15) }}>
                  Contact Person Number
                </Label>
                <Input
                  getRef={input => {
                    this.contactNumber = input;
                  }}
                  keyboardType='number-pad'
                  value={this.state.contactNumber}
                  editable={true}
                  onChangeText={contactNumber =>
                    this.setState({ contactNumber: contactNumber })
                  }
                  returnKeyType='next'
                  onSubmitEditing={() => this.contactEmail._root.focus()}
                />
              </FormItem>
              <FormItem floatingLabel style={styles.itemStyle}>
                <Label style={{ fontSize: moderateScale(15) }}>
                  Contact Person Email
                </Label>
                <Input
                  getRef={input => {
                    this.contactEmail = input;
                  }}
                  keyboardType='email-address'
                  value={this.state.contactEmail}
                  editable={true}
                  onChangeText={contactEmail =>
                    this.setState({ contactEmail: contactEmail })
                  }
                  returnKeyType='done'
                  onSubmitEditing={() => this.handleSubmit()}
                />
              </FormItem>
              <View style={styles.buttonStyle}>
                <Button
                  title='Change Password'
                  type='outline'
                  containerStyle={{ width: '100%' }}
                  buttonStyle={{ borderRadius: 10, borderColor: 'red' }}
                  titleStyle={{ fontSize: moderateScale(20), color: 'red' }}
                  onPress={() =>
                    this.setState({
                      isModalVisible: !this.state.isModalVisible
                    })
                  }
                />
              </View>
              <View style={styles.buttonStyle}>
                <Button
                  title='Update'
                  containerStyle={{ width: '100%' }}
                  buttonStyle={{ backgroundColor: '#60BB46', borderRadius: 10 }}
                  titleStyle={{ fontSize: moderateScale(20) }}
                  onPress={this.handleSubmit.bind(this)}
                />
              </View>
            </Form>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    flex: 1,
    alignItems: 'center'
  },
  scrollViewStyle: {
    width: '100%'
  },
  logoStyle: {
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: verticalScale(15),
    marginBottom: verticalScale(15)
  },

  formViewStyle: {
    backgroundColor: '#fffff8',
    elevation: 1,
    paddingBottom: moderateScale(25),
    marginBottom: moderateScale(10),
    borderRadius: 3,
    alignItems: 'center',
    shadowOffset: { width: 3, height: 3 },
    shadowColor: 'grey',
    shadowOpacity: 0.25,
    shadowRadius: 5
  },
  formStyle: {
    flex: 1,
    paddingRight: 15
  },
  dualItemStyle: {
    flex: 0.125,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  itemStyle: {
    flex: 0.125,
    justifyContent: 'center',
    alignItems: 'center',
    margin: 0,
    padding: 0
  },
  buttonStyle: {
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: moderateScale(25),
    paddingLeft: moderateScale(15)
  },

  avatarContainer: {
    borderColor: '#0fc9ff',
    borderWidth: 3 / PixelRatio.get(),
    justifyContent: 'center',
    alignItems: 'center'
  },
  avatar: {
    borderRadius: width * 0.25,
    width: width * 0.5,
    height: width * 0.5
  },

  buttonText: {
    color: '#FFFFFF',
    fontSize: 18,
    margin: 10,
    textAlign: 'center'
  },

  confirmButton: {
    width: width * 0.9,
    height: 50,
    marginLeft: width * 0.05,
    marginBottom: 20,
    borderRadius: 6,
    backgroundColor: '#0fc9ff'
  }
});
