import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff'
  },

  iconView: {
    flex: 0.26,
    justifyContent: 'center',
    alignItems: 'center'
  },

  greenView: {
    flex: 0.37,
    width: '100%',
    flexDirection: 'row'
  },

  blueView: {
    flex: 0.37,
    width: '100%',
    flexDirection: 'row'
  },

  greenCurve: {
    flex: 0.4,
    height: '100%',
    backgroundColor: '#59ff00',
    borderBottomRightRadius: 1000
  },

  blueCurve: {
    flex: 0.4,
    height: '100%',
    borderTopLeftRadius: 1000,
    backgroundColor: '#1285ff'
  }
});
