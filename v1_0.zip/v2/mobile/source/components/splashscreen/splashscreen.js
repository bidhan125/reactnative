import React, { Component } from 'react';
import {
  View,
  Dimensions,
  Image,
  AsyncStorage,
  ImageBackground
} from 'react-native';
import Meteor from 'react-native-meteor';

import { styles } from './styles';

const server_url = 'ws://lb.durbintest.pro/websocket';
// const server_url = 'ws://192.168.1.9:3000/websocket';

Meteor.connect(server_url);

export default class Splashscreen extends Component {
  constructor(props) {
    super(props);
    this._bootstrapAsync();
    console.log(props);
  }

  _bootstrapAsync = async () => {
    const userToken = await AsyncStorage.getItem('user');
    const introShown = await AsyncStorage.getItem('intro');
    if (userToken) {
      const user = JSON.parse(userToken);
      // TODO: show welcome toast message
    }
    setTimeout(() => {
      this.props.navigation.navigate(
        introShown ? (userToken ? 'App' : 'Auth') : 'Intro',
        { showSnack: true }
      );
    }, 1500);
  };

  render() {
    const { width, height } = Dimensions.get('window');

    return (
      <View style={styles.container}>
        <ImageBackground
          source={require('../../assets/Splash_bg.png')}
          style={{ width: width, height: height }}
        >
          <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
            <Image
              resizeMode="contain"
              source={require('../../assets/Splash_logo.png')}
              style={{width: width*0.5, height: height*0.3}}
            />
          </View>
        </ImageBackground>
      </View>
    );
  }
}
