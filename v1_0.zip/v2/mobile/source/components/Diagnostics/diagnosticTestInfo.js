import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Dimensions,
  ScrollView,
  TouchableOpacity
} from 'react-native';
import Icon from 'react-native-vector-icons/AntDesign';

import Header from '../common/header';

export default class DiagnosticTestInfo extends Component {
  render() {
    return (
      <View style={styles.container}>
        <Header
          text="Diagnostic Test"
          iconLeft="arrowleft"
          iconRight="shoppingcart"
          navigation={this.props.navigation}
        />

        <View style={styles.viewStyle}>
          <View style={styles.priceStyle}>
            <View style={{ flex: 0.1 }}>
              <TouchableOpacity>
                <Icon name="shoppingcart" size={24} color="#1285ff" />
              </TouchableOpacity>
            </View>
            <View style={{ flex: 0.25 }}>
              <Text>1000 BDT</Text>
            </View>
          </View>

          <View style={styles.testNameStyle}>
            <Text style={{ fontSize: 21, color: '#1285ff' }}>Test Name</Text>
          </View>
          <View style={styles.testRequirementStyle}>
            <Text style={{ fontSize: 18, color: '#59ff00' }}>
              Test Requirements:
            </Text>
          </View>
          <View style={styles.requirementNamesStyle}>
            <Text style={{ fontSize: 16, fontWeight: 'bold' }}>1. ECG </Text>
            <Text style={{ fontSize: 16, fontWeight: 'bold' }}>2. MRI</Text>
          </View>
          <View style={{ flex: 0.6, width: '94%', alignItems: 'center' }}>
            <ScrollView style={styles.scrollingStyle}>
              <Text>
                The electrocardiogram (ECG or EKG) is a diagnostic tool that is
                routinely used to assess the electrical and muscular functions
                of the heart. While it is a relatively simple test to perform,
                the interpretation of the ECG tracing requires significant
                amounts of training. Numerous textbooks are devoted to the
                subject. The heart is a two stage electrical pump and the
                heart's electrical activity can be measured by electrodes placed
                on the skin. The electrocardiogram can measure the rate and
                rhythm of the heartbeat, as well as provide indirect evidence of
                blood flow to the heart muscle. A standardized system has been
                developed for the electrode placement for a routine ECG. Ten
                electrodes are needed to produce 12 electrical views of the
                heart. An electrode lead, or patch, is placed on each arm and
                leg and six are placed across the chest wall. The signals
                received from each electrode are recorded. The printed view of
                these recordings is the electrocardiogram. By comparison, a
                heart monitor requires only three electrode leads – one each on
                the right arm, left arm, and left chest. It only measures the
                rate and rhythm of the heartbeat. This kind of monitoring does
                not constitute a complete ECG.
              </Text>
            </ScrollView>
          </View>
        </View>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    flex: 1
  },
  viewStyle: {
    flex: 1,
    margin: 10,
    backgroundColor: '#fffff8',
    elevation: 2,
    alignItems: 'center'
  },
  priceStyle: {
    flex: 0.08,
    justifyContent: 'flex-end',
    alignItems: 'center',
    flexDirection: 'row',
    width: '94%'
  },
  testNameStyle: {
    flex: 0.08,
    width: '94%',
    justifyContent: 'center',
    borderBottomWidth: 1,
    borderBottomColor: 'gray'
  },
  testRequirementStyle: {
    flex: 0.08,
    justifyContent: 'flex-end',
    alignItems: 'flex-start',
    width: '94%'
  },
  requirementNamesStyle: {
    flex: 0.15,
    width: '94%',
    alignItems: 'flex-start',
    justifyContent: 'space-evenly'
  },
  scrollingStyle: {
    width: '100%',
    marginTop: 10,
    paddingTop: 2
  }
});
