import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  Picker,
  ScrollView,
  Dimensions,
  KeyboardAvoidingView
} from 'react-native';
import { Fab } from 'native-base';
import { TabView, SceneMap } from 'react-native-tab-view';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import Header from '../common/header';
import DiagnosticTest from './diagnosticTest';
import DiagnosticPackageTest from './diagnosticPackageTest';

const { height, width } = Dimensions.get('window');

export default class DiagnosticsTabControl extends Component {
  constructor(props) {
    super(props);

    this.state = {
      index: 0,
      routes: [
        { key: 'first', title: 'Individual Tests' },
        { key: 'second', title: 'Package Tests' }
      ]
    };
  }

  render() {
    return (
      <React.Fragment>
        <Header
          text="Diagnostic Test"
          iconLeft="arrowleft"
          iconRight="shoppingcart"
          navigation={this.props.navigation}
        />

        <TabView
          navigationState={this.state}
          navigation={this.navigation}
          renderScene={({ route }) => {
            switch (route.key) {
              case 'first':
                return <DiagnosticTest navigation={this.props.navigation} />;
              case 'second':
                return (
                  <DiagnosticPackageTest navigation={this.props.navigation} />
                );
              default:
                return null;
            }
          }}
          onIndexChange={index => this.setState({ index })}
          initialLayout={{ width }}
          tabStyle={{ height: 50 }}
          style={{ height: height / 2 }}
          tabBarPosition="bottom"
        />
      </React.Fragment>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    height: 1000,
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center'
  }
});
