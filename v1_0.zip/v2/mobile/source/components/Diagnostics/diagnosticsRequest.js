import React, { Component } from 'react';
import {
  Alert,
  Platform,
  KeyboardAvoidingView,
  StyleSheet,
  Text,
  View,
  Dimensions,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Picker
} from 'react-native';
import { Button, Icon as IconEl } from 'react-native-elements';
import { Picker as PickerNative, Icon as IconNative } from 'native-base';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Meteor from 'react-native-meteor';
import DatePicker from 'react-native-datepicker';
import moment from 'moment';
import SnackBar from 'react-native-snackbar-component';

const { height, width } = Dimensions.get('window');

import Header from '../common/header';
import {
  getUserAsync,
  moderateScale,
  verticalScale
} from '../../constants/const_functions';
import { order_types, branchCity } from '../../constants/const_strings';
import PaymentModal from '../Modal/paymentModal';
import SpinView from '../common/spinner';

export default class DiagnosticsRequest extends Component {
  constructor(props) {
    super(props);
    this.state = {
      address: '',
      chosenBeneficiary: undefined,
      count: {},
      bList: [],
      date: new Date(),
      beneficiaryList: [],
      showSnack: false,
      removeSnack: false,
      checked: {},
      testWithBenList: [],
      flag: false,
      price: 0,
      district: undefined,
      procssing: false
    };

    this.fetchBeneficiary();
  }

  async fetchBeneficiary() {
    const user = JSON.parse(await getUserAsync());
    console.log('user:', user);
    Meteor.call('fetchBeneficiary', user._id, (err, res) => {
      console.log('bList: ', res);
      if (err) {
        alert(
          'Sorry! Failed to fetch beneficiary list. Please try again later'
        );
      }
      if (res) {
        this.setState({ user, bList: res });
        let temp = this.state.bList.unshift(user.profile);
        this.setState({ bList: [...this.state.bList] });
      }
    });
  }

  updateState(obj) {
    this.setState(obj);
  }

  updateCount(idx, cnt) {
    this.setState({
      count: {
        ...this.state.count,
        [idx]: cnt
      }
    });
  }

  calculateAge(dob) {
    if (!dob) return undefined;
    const today = moment();
    const dob_m = moment(dob);
    // console.log(dob, today.diff(dob_m, 'years'));

    return today.diff(dob_m, 'years');
  }

  handleConfirm(paymentMethod) {
    const { testWithBenList, district } = this.state;
    const address = this.state.address || this.state.user.profile.address;
    const selecTedItems = this.props.navigation.getParam('selecTedItems', []);
    const branch = this.props.navigation.getParam('branch', undefined);
    const tests = [];

    // console.log('tests', address);

    testWithBenList.forEach(item => {
      tests.push({
        name: item.testName,
        id: item.testInfo._id,
        price: item.price,
        for: item.beneficiaryInfo
      });
    });

    if (this.state.district === undefined) {
      alert('Please select a city!');
      return;
    }

    // if (address === undefined || address.length <= 0) {
    //   alert('Please give your address!');
    //   return;
    // }

    var price = 0;
    this.state.testWithBenList.forEach(item => {
      price += parseInt(item.price);
    });
    price += 200

    const beneList = [];
    for (let index in this.state.checked) {
      if (this.state.checked[index]) {
        beneList.push(this.state.bList[index].name);
      }
    }

    let patient = {};
    if (beneList.length <= 0) {
      alert('Please select beneficiary.');
      return;
    } else {
      const {
        name,
        address,
        phone,
        gender,
        dob,
        email
      } = this.state.user.profile;
      patient = {
        ...patient,
        name,
        address,
        gender,
        phone,
        age: this.calculateAge(dob)
      };
      this.setState({ procssing: true });
    }

    let data = {
      patient,
      district: this.state.district,
      address,
      branch,
      tests,
      orderType: 'single_test',
      beneficiaries: beneList,
      time: new Date(this.state.date),
      price,
      paymentMethod
    };

    if (this.props.navigation.getParam('testType')) {
      data.orderType = 'package_test';
    }

    const { name, phone, gender, dob, email } = this.state.user.profile;
    const order = {
      amount: price,
      currency: 'BDT',
      redirect_url: 'http://google.com'
    };
    const product = {
      name: 'Diagnostic Test',
      description: 'Sample collection for diagnostic test'
    };
    const billing = {
      customer: {
        name: name,
        email: email,
        phone: phone,
        address: {
          street: address,
          city: district || 'Dhaka',
          state: district || 'Dhaka',
          zipcode: '1000',
          country: 'BD'
        }
      }
    };
    Meteor.call('addOrder', data, (err, res) => {
      this.setState({ procssing: false });
      if (err) {
        // console.log(err);
        alert(
          "Sorry! Your order couldn't be processed at this moment. Please try again later."
        );
      } else if (res) {
        // console.log(res);
        if (paymentMethod === 'Pay Online') {
          this.props.navigation.navigate('PaymentGateway', {
            orderId: res,
            order: order,
            product: product,
            billing: billing
          });
        } else {
          Alert.alert(
            'Success',
            'Congratulations! Your order successfully saved!',
            [
              {
                text: 'Ok',
                onPress: () => this.props.navigation.navigate('Home'),
                style: 'ok'
              }
            ],
            { cancelable: false }
          );
        }
      }
    });
  }

  calculateTotal() {
    var count = 0;
    this.state.testWithBenList.forEach(item => {
      count += parseInt(item.price);
    });
    count += 200
    return count;
  }

  handleBeneficiary(item, index, selecTedItems) {
    this.setState(
      state => {
        return {
          showSnack: true,
          sl_no: index,
          checked: {
            ...state.checked,
            [index]: !state.checked[index]
          }
        };
      },
      () => {
        const beneList = [];
        for (let index in this.state.checked) {
          if (this.state.checked[index]) {
            beneList.push(this.state.bList[index]);
          }
        }
        setTimeout(() => {
          this.setState({
            showSnack: false
          });
        }, 1500),
          this.setState({ beneficiaryList: [...beneList] });
        var tempList = [];
        selecTedItems.map((item, sl_no) => {
          return beneList.map((b, key) => {
            return tempList.push({
              b_key: key,
              test_key: sl_no,
              beneficiary: b.name,
              testName: item.name,
              price: item.price,
              testInfo: item,
              beneficiaryInfo: b
            });
          });
        });
        this.setState({ testWithBenList: [...tempList] }, () => {
          console.log('testWithBenList: ', this.state.testWithBenList);
        });
      }
    );
  }

  deleteTestWithBen(index) {
    // console.log('indelete: ', index);
    var tempList = [...this.state.testWithBenList];
    tempList.splice(index, 1);
    // console.log(tempList);
    this.setState(
      state => {
        return {
          testWithBenList: [...tempList],
          flag: !state.flag
        };
      },
      () => {
        console.log(this.state.testWithBenList, this.state.flag);
      }
    );
  }

  render() {
    const selecTedItems = this.props.navigation.getParam('selecTedItems', []);
    const { testWithBenList } = this.state;
    const { bList, user } = this.state;

    const distOptions = [];
    branchCity.map(item =>
      distOptions.push(<Picker.Item label={item.name} value={item.name} />)
    );

    var newList = [
      <TouchableOpacity
        onPress={() => this.props.navigation.navigate('BeneficiaryCreate')}
      >
        <View style={styles.cardView}>
          <IconEl name='plus' type='font-awesome' color='#707070' />
          <Text style={styles.cardName}>Add New</Text>
        </View>
      </TouchableOpacity>
    ];
    bList.map((item, sl_no) => {
      newList.push(
        <TouchableOpacity
          onPress={() =>
            this.handleBeneficiary(
              item.name,
              sl_no,
              selecTedItems,
              (isBene = true)
            )
          }
          style={
            this.state.checked[sl_no]
              ? styles.selectedCardView
              : styles.cardView
          }
        >
          {/* <View
            style={
              this.state.checked[sl_no]
                ? styles.selectedCardView
                : styles.cardView
            }
          > */}
          <Text
            style={
              this.state.checked[sl_no] ? styles.cardSelected : styles.cardName
            }
          >
            {sl_no === 0 ? 'For me' : item.name}
          </Text>
          <Text
            style={
              this.state.checked[sl_no]
                ? styles.selectedRelationText
                : styles.relationText
            }
          >
            {item.relation}
          </Text>
          {/* </View> */}
        </TouchableOpacity>
      );
    });
    // console.log(this.state.beneficiaryList);

    if (this.state.procssing) {
      return <SpinView />;
    }

    return (
      <View style={styles.container}>
        <SnackBar
          visible={this.state.showSnack}
          textMessage={
            this.state.checked[this.state.sl_no]
              ? 'The beneficiary has been added!'
              : 'The beneficiary has been remvoed!'
          }
          actionHandler={() => {
            this.setState({ showSnack: !this.state.showSnack });
          }}
          actionText='Ok'
          position='bottom'
        />
        <Header
          text='Diagnostic Test'
          iconLeft='arrowleft'
          iconRight='shoppingcart'
          navigation={this.props.navigation}
        />
        <PaymentModal
          visibilityStateName='isPaymentModalVisible'
          visibility={this.state.isPaymentModalVisible}
          updateState={this.updateState.bind(this)}
          handleSubmit={this.handleConfirm.bind(this)}
        />
        <View style={styles.viewStyle}>
          <ScrollView
            style={styles.scrollViewStyle}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{ justifyContent: 'flex-start' }}
          >
            <View style={styles.dropDownViewStyle}>
              <View
                style={{
                  flex: 1,
                  width: '100%',
                  elevation: 1,
                  height: moderateScale(45),
                  borderRadius: 10,
                  backgroundColor: 'white',
                  shadowOffset: { width: 3, height: 3 },
                  shadowColor: 'grey',
                  shadowOpacity: 0.25,
                  shadowRadius: 5
                }}
              >
                {(Platform.OS == 'android' && (
                  <Picker
                    style={{ flex: 1 }}
                    selectedValue={this.state.district}
                    mode='dropdown'
                    onValueChange={(itemValue, itemIndex) =>
                      this.setState({ district: itemValue })
                    }
                  >
                    <Picker.Item label='Select City' value='key0' />
                    {distOptions}
                  </Picker>
                )) || (
                  <PickerNative
                    style={{ width: '100%' }}
                    placeholder='Select your city'
                    iosHeader='Select your city'
                    iosIcon={<IconNative name='arrow-down' />}
                    selectedValue={this.state.district}
                    mode='dropdown'
                    onValueChange={(itemValue, itemIndex) =>
                      this.setState({ district: itemValue })
                    }
                  >
                    {distOptions}
                  </PickerNative>
                )}
              </View>
            </View>

            <View style={{ height: height * 0.05, justifyContent: 'center' }}>
              <Text style={{ fontSize: moderateScale(15), fontWeight: 'bold' }}>
                Your Address:
              </Text>
            </View>
            <View style={styles.inputStyle} height={height * 0.1}>
              <TextInput
                placeholder='Type your address, (Your profile address will be used if empty)'
                multiline={true}
                editable={true}
                onChangeText={address => this.setState({ address })}
                value={this.state.address}
                style={{ backgroundColor: '#F4F4F5', height: '100%' }}
                numberOfLines={4}
                textAlignVertical='top'
                underlineColorAndroid='transparent'
              />
            </View>
            <View style={{ height: height * 0.05, justifyContent: 'center' }}>
              <Text style={{ fontSize: moderateScale(15), fontWeight: 'bold' }}>
                Select beneficiary:
              </Text>
            </View>
            <ScrollView
              horizontal={true}
              showsHorizontalScrollIndicator={false}
            >
              {newList}
            </ScrollView>

            <View style={{ flexDirection: 'row', flex: 1, marginTop: 5 }}>
              <View
                style={{
                  flex: 0.4,
                  height: height * 0.05,
                  justifyContent: 'center'
                }}
              >
                <Text
                  style={{
                    fontSize: moderateScale(15),
                    fontWeight: 'bold'
                  }}
                >
                  Select a date:{' '}
                </Text>
              </View>

              <View style={styles.datePickerStyle}>
                <DatePicker
                  date={this.state.date}
                  mode='date'
                  placeholder='DD-MM-YY'
                  formatDate='DD-MM-YYYY'
                  minDate={new Date()}
                  confirmBtnText='Confirm'
                  cancelBtnText='Cancel'
                  onDateChange={date => {
                    this.setState({ date });
                  }}
                  iconComponent={<IconEl name='calendar' type='antdesign' />}
                  customStyles={{
                    dateIcon: {
                      // position: 'absolute',
                      // left: 0,
                      // top: 4,
                      // marginLeft: 0,
                    },
                    dateInput: {
                      borderWidth: 0
                    }
                  }}
                />
              </View>
            </View>
            <View style={{ height: height * 0.05, justifyContent: 'center' }}>
              <Text style={{ fontSize: moderateScale(15), fontWeight: 'bold' }}>
                Ordered Test Names:
              </Text>
            </View>
            <View style={styles.lastViewStyle}>
              {(this.state.testWithBenList.length > 0 &&
                testWithBenList.map((item, sl_no) => {
                  const count = this.state.count[item._id];
                  return (
                    <CustomListItem
                      index={sl_no}
                      // key2={key}
                      beneficiaryList={item.beneficiary}
                      price={item.price}
                      testName={item.testName}
                      deleteTestWithBen={this.deleteTestWithBen.bind(this)}
                    />
                  );
                })) || <Text>Please selcet beneficiaries</Text>}

              <View
                style={{
                  flex: 1,
                  width: '100%',
                  justifyContent: 'flex-end',
                  borderTopWidth: 1,
                  borderTopColor: '#BCBDC0'
                }}
              >
                <Text
                  style={{
                    paddingTop: 5,
                    textAlign: 'right',
                    paddingRight: moderateScale(18)
                  }}
                >
                  {'Sample Collection fee = '}
                  {200}
                  {'/='}
                </Text>

                <Text
                  style={{
                    paddingTop: 5,
                    textAlign: 'right',
                    paddingRight: moderateScale(18)
                  }}
                >
                  {'Total = '}
                  {this.calculateTotal()}
                  {'/='}
                </Text>
              </View>
            </View>
            {/* <View style={styles.payCashViewStyle}>
              <Text style={{ fontSize: moderateScale(14), fontWeight: 'bold' }}>
                Payment Method
              </Text>
              <TouchableOpacity
                onPress={() =>
                  this.setState({
                    isPaymentModalVisible: !this.state.isPaymentModalVisible
                  })
                }
              >
                <View style={{ flexDirection: 'row' }}>
                  <Text
                    style={{
                      fontSize: moderateScale(14),
                      color: '#1285ff'
                    }}
                  >
                    {this.state.paymentMethod + ' '}
                  </Text>
                  <Icon name='arrow-right' size={20} color='#1285ff' />
                </View>
              </TouchableOpacity>
            </View> */}
            <View style={styles.buttonStyle}>
              <Button
                title='Confirm'
                containerStyle={{ width: '94%' }}
                buttonStyle={{
                  backgroundColor: '#60BB46',
                  borderRadius: 10
                }}
                titleStyle={{ fontSize: moderateScale(16) }}
                onPress={() => this.setState({ isPaymentModalVisible: true })}
              />
            </View>
          </ScrollView>
        </View>
      </View>
    );
  }
}

CustomListItem = props => {
  return (
    <View style={styles.costViewStyle}>
      <TouchableOpacity
        style={styles.tinyViewStyle}
        flex={10}
        onPress={() => props.deleteTestWithBen(props.index)}
      >
        <IconEl
          name='closecircleo'
          type='antdesign'
          size={moderateScale(15)}
          color='red'
        />
      </TouchableOpacity>
      <View styles={{ height: '100%' }} flex={36}>
        <Text
          style={{
            fontSize: moderateScale(14),
            paddingLeft: moderateScale(10)
          }}
        >
          {props.testName}
        </Text>
      </View>

      <View style={{ flex: 27, alignItems: 'flex-start' }}>
        <Text numberOfLines={1}> {props.beneficiaryList || 'not given'} </Text>
      </View>

      <View style={{ flex: 17, alignItems: 'flex-end' }}>
        <Text> {parseInt(props.price) + '/='} </Text>
      </View>
    </View>
  );
};

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    flex: 1,
    alignItems: 'center'
  },
  viewStyle: {
    flex: 1,
    width: '94%',
    justifyContent: 'flex-start',
    alignItems: 'center'
  },
  scrollViewStyle: {
    flex: 1,
    paddingTop: 12,
    width: '100%',
    marginTop: 1
  },

  inputStyle: {
    marginTop: 5,
    marginBottom: 5
  },
  datePickerStyle: {
    alignItems: 'flex-end',
    flex: 0.6,
    width: '100%',
    paddingRight: moderateScale(5),
    borderBottomWidth: 1,
    borderBottomColor: '#BCBDC0'
  },
  lastViewStyle: {
    marginTop: verticalScale(10),
    paddingTop: verticalScale(10),
    marginBottom: verticalScale(15),
    paddingBottom: 5,
    justifyContent: 'space-evenly',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    width: '98%',
    elevation: 2,
    alignSelf: 'center',
    paddingBottom: verticalScale(20),
    borderRadius: 10,
    shadowOffset: { width: 3, height: 3 },
    shadowColor: 'grey',
    shadowOpacity: 0.25,
    shadowRadius: 5
  },
  costViewStyle: {
    width: '94%',
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    paddingBottom: verticalScale(10)
  },

  buttonStyle: {
    flex: 0.1,
    justifyContent: 'center',
    alignItems: 'center',
    height: verticalScale(80)
  },
  tinyViewStyle: {
    alignItems: 'center'
  },
  pickerViewStyle: {
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    elevation: 1
  },
  payCashViewStyle: {
    flex: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: verticalScale(40)
  },

  cardName: {
    fontWeight: 'bold',
    fontSize: moderateScale(15),
    textAlign: 'center'
  },

  cardSelected: {
    color: '#0076BE',
    fontWeight: 'bold',
    fontSize: moderateScale(15),
    textAlign: 'center'
  },

  cardView: {
    flex: 1,
    width: moderateScale(110),
    height: verticalScale(70),
    elevation: 3,
    backgroundColor: 'white',
    marginRight: moderateScale(10),
    marginTop: verticalScale(10),
    marginBottom: verticalScale(10),
    marginLeft: 5,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    shadowOffset: { width: 3, height: 3 },
    shadowColor: 'grey',
    shadowOpacity: 0.25,
    shadowRadius: 5
  },

  selectedCardView: {
    flex: 1,
    width: moderateScale(110),
    height: verticalScale(70),
    borderWidth: 2,
    borderColor: '#0076BE',
    backgroundColor: 'white',
    marginRight: moderateScale(10),
    marginTop: verticalScale(10),
    marginBottom: verticalScale(10),
    marginLeft: 5,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center'
  },

  relationText: {
    fontSize: moderateScale(13)
  },

  selectedRelationText: {
    fontSize: moderateScale(13),
    color: '#0076BE'
  },

  dropDownViewStyle: {
    flex: 8,
    flexDirection: 'row',
    alignItems: 'center',
    height: verticalScale(60),
    paddingLeft: 1,
    paddingRight: 1
  }
});
