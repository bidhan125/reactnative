import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Dimensions,
  Image,
  TouchableOpacity,
  ScrollView
} from 'react-native';
import Header from '../common/header';
import RectangleView from '../common/rectangleViewHomeCare';
import { moderateScale, verticalScale } from '../../constants/const_functions';

export default class Diagnostics extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    const displayWidth = Dimensions.get('window').width;
    const displayHeight = Dimensions.get('window').height;
    h = displayHeight / 6;

    return (
      <View style={styles.container}>
        <Header
          text='Diagnostics'
          iconLeft='arrowleft'
          iconRight='shoppingcart'
          navigation={this.props.navigation}
        />
        <ScrollView contentContainerStyle={{ flex: 1 }}>
          <View style={styles.mainView}>
            {/* <View style={styles.middleView}> */}
            <TouchableOpacity
              style={styles.touchView}
              onPress={() => {
                this.props.navigation.navigate('DiagnosticsTabControl');
              }}
            >
              <View style={{ padding: 10, paddingBottom: 0 }}>
                <Image
                  resizeMode='contain'
                  source={require('../../assets/Asset_cover.png')}
                  style={styles.image}
                />
              </View>
              <View style={{ padding: 10 }}>
                <Text style={styles.headerText}>Test Sample Collection</Text>
                <Text
                  style={{ textAlign: 'right' }}
                  adjustsFontSizeToFit={true}
                >
                  Our Expert will visit your home to collect the samples like:
                  blood, stool, tissues etc to provide the authentic result and
                  our results are highly accepted all over Bangladesh.
                </Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.touchView}
              onPress={() => {
                this.props.navigation.navigate('ReportHomeDelivery');
              }}
            >
              <View style={{ padding: 10, paddingBottom: 0 }}>
                <Image
                  resizeMode='contain'
                  source={require('../../assets/Asset_4f.png')}
                  style={styles.image}
                />
              </View>
              <View style={{ padding: 10 }}>
                <Text style={styles.headerText}>Report Home Delivery</Text>
                <Text style={{ textAlign: 'right' }}>
                  Get your reports delivered to you. We think about new
                  innovation and new ways of providing convenience to you. your
                  Medical Reports in Labaid Envelop will be delivered through
                  our Home Delivery service
                </Text>
              </View>
            </TouchableOpacity>
          </View>
          {/* </View> */}
        </ScrollView>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center'
  },
  mainView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%'
  },
  touchView: {
    flex: 1,
    elevation: 2,
    margin: 5,
    width: '96%',
    borderRadius: 10,
    backgroundColor: '#ffffff',
    shadowOffset: { width: 3, height: 3 },
    shadowColor: 'grey',
    shadowOpacity: 0.25,
    shadowRadius: 5
    // borderWidth: 1
  },
  image: {
    width: moderateScale(190),
    height: verticalScale(136)
  },
  headerText: {
    fontSize: moderateScale(25),
    color: '#0076BE',
    textAlign: 'right'
  }
});
