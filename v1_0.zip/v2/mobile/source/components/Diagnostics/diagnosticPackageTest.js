import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Dimensions,
  ScrollView,
  TouchableOpacity,
  ToastAndroid
} from 'react-native';
import Meteor from 'react-native-meteor';
import { Fab } from 'native-base';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import SpinView from '../common/spinner';
import { SearchField } from '../common/searchField';
import DiagnosticPackageViewField from './diagnosticPackageViewField';

page_size = 10;

export default class DiagnosticPackageTest extends Component {
  constructor(props) {
    super(props);

    this.state = {
      checked: {},
      dpList: [],
      clickedItemIdx: undefined,
      isVisibleModalDetails: false,
      isLoaded: false,
      searchQuery: undefined,
      activePage: 1,
      totalPages: 1,
      searchResult: false
    };

    this.fetchDiagnosticTest();
    this.fetchDiagnosticCount();
  }

  fetchDiagnosticCount() {
    const { searchQuery } = this.state;
    Meteor.call(
      'fetchDiagnosticCount',
      { searchQuery, type: 'package' },
      (err, res) => {
        // console.log(err, res);
        if (err) alert('Failed to fetch test count, please try again later');
        else if (res) this.setState({ totalPages: Math.ceil(res / page_size) });
      }
    );
  }

  fetchDiagnosticTest() {
    const { activePage, searchQuery, dpList } = this.state;
    Meteor.call(
      'fetchDiagnosticTest',
      { page_no: activePage, searchQuery, type: 'package' },
      (err, res) => {
        console.log(err, res);
        if (err)
          alert(
            'Unfortunately failed to package test Diagnostic Test list. Please try again later'
          );
        else if (res) {
          this.setState({
            dpList: dpList.concat(res),
            isLoaded: true,
            activePage: activePage + 1,
            isLoadingMore: false
          });
        }
      }
    );
  }

  handleItemClick(idx) {
    this.setState({
      clickedItemIdx: idx,
      isVisibleModalDetails: !this.state.isVisibleModalDetails
    });
  }

  updateState(obj) {
    this.setState(obj);
  }

  updateIndex(idx) {
    this.setState({
      checked: { [idx]: !this.state.checked[idx] }
    });
  }

  addQuantity() {
    this.setState({ quantity: this.state.quantity + 1 });
  }

  reduceQuantity() {
    if (this.state.quantity === 0) {
      return;
    } else {
      this.setState({ quantity: this.state.quantity - 1 });
    }
  }

  handleFab() {
    const selecTedItems = [];
    const { checked } = this.state;
    this.state.dpList.map((item, sl_no) => {
      const { name, _id, price } = item;
      if (checked[sl_no]) selecTedItems.push({ name, _id, price });
    });
    // console.log(selecTedItems, this.props);
    if (selecTedItems.length < 1) {
      alert('Please select a package test!');
      return;
    }
    this.props.navigation.navigate('DiagnosticsRequest', {
      selecTedItems,
      testType: 'package_test'
    });
  }

  handleSearch() {
    const { searchQuery } = this.state;
    this.setState(
      { isLoaded: false, activePage: 1, dpList: [], searchResult: true },
      () => {
        this.fetchDiagnosticCount();
        this.fetchDiagnosticTest(searchQuery);
      }
    );
  }

  handlePaginate() {
    const { activePage, totalPages } = this.state;
    console.log('active_page', activePage);
    this.setState({ isLoadingMore: true });

    if (activePage <= totalPages) {
      this.fetchDiagnosticTest();
    } else {
      this.setState({ isLoadingMore: false });
      if (activePage !== 2)
        ToastAndroid.show('You are at the end of list.', ToastAndroid.SHORT);
    }
  }
  render() {
    const {
      dpList,
      checked,
      clickedItemIdx,
      isVisibleModalDetails
    } = this.state;

    data = dpList[clickedItemIdx] || {};
    const { name = 'Not Given', description = 'No Description Given' } = data;
    if (!this.state.isLoaded)
      return (
        <View style={{ flex: 1 }}>
          <View style={styles.smallView}>
            <SearchField
              {...this.props}
              updateState={this.updateState.bind(this)}
              placeholderText="Search for a Package test"
              handleSearch={this.handleSearch.bind(this)}
            />
          </View>
          <SpinView />
        </View>
      );
    const { height, width } = Dimensions.get('window');

    return (
      <View style={styles.container}>
        <ItemDetailsModalView
          visibility={isVisibleModalDetails}
          visibilityStateName={'isVisibleModalDetails'}
          updateState={this.updateState.bind(this)}
          name={name}
          description={description}
          addQuantity={this.addQuantity.bind(this)}
          reduceQuantity={this.reduceQuantity.bind(this)}
          quantity={this.state.quantity}
        />

        <View style={styles.smallView}>
          <SearchField
            {...this.props}
            updateState={this.updateState.bind(this)}
            placeholderText="Search for a Package test"
            handleSearch={this.handleSearch.bind(this)}
          />
        </View>

        <View style={styles.largeView}>
          {dpList.map((item, sl_no) => (
            <DiagnosticPackageViewField
              key={sl_no}
              data={item}
              idx={sl_no}
              checked={!!checked[sl_no]}
              handleItemClick={this.handleItemClick.bind(this)}
              updateIndex={this.updateIndex.bind(this)}
              updateState={this.updateState.bind(this)}
            />
          ))}

          <Fab
            style={{ backgroundColor: '#5067FF' }}
            position="bottomRight"
            containerStyle={{ bottom: 30 }}
            onPress={() => this.handleFab()}
          >
            <Icon name="chevron-double-right" />
          </Fab>
        </View>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    flex: 1
  },
  smallView: {
    width: '100%',
    justifyContent: 'flex-end',
    alignItems: 'center',
    marginTop: 5
  },
  largeView: {
    flex: 1,
    justifyContent: 'flex-start',
    width: '100%',
    alignItems: 'center',
    paddingTop: 8
  },
  scrollStyle: {
    flex: 1,
    width: '100%',
    paddingTop: 15,
    backgroundColor: '#ffffff',
    elevation: 2,
    paddingBottom: 10
  }
});
