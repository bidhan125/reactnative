import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Dimensions,
  TouchableOpacity
} from 'react-native';
import { CheckBox } from 'react-native-elements';
import { verticalScale, moderateScale } from '../../constants/const_functions';

//props: testName,testDesc

var i = 0,
  checkedElements;
export default class DiagnosticTestViewField extends Component {
  constructor(props) {
    super(props);
    this.state = {
      checked: false
    };
  }

  pressHandler() {
    this.setState({ checked: !this.state.checked });
  }

  render() {
    const { height, width } = Dimensions.get('window');

    const { data } = this.props;

    console.log(data);

    return (
      <TouchableOpacity
        onPress={() => {
          this.props.handleItemClick(this.props.idx);
        }}
        style={{
          elevation: 1.5,
          // borderWidth: 1,
          borderRadius: 15,
          backgroundColor: 'white',
          marginBottom: moderateScale(10),
          marginLeft: moderateScale(10),
          marginRight: moderateScale(10),
          shadowOffset: { width: 3, height: 3 },
          shadowColor: 'grey',
          shadowOpacity: 0.25,
          shadowRadius: 5
        }}
        // height={verticalScale(70)}
        // width={width * 0.94}
      >
        <View
          style={styles.container}
          height={verticalScale(70)}
          width={width * 0.94}
        >
          <View
            style={styles.checkViewStyle}
            onPress={() => this.props.updateIndex(this.props.idx)}
          >
            <CheckBox
              icontype="antDesign"
              checkedIcon="check"
              size={30}
              checked={this.props.checked}
              onPress={() => this.props.updateIndex(this.props.idx)}
            />
          </View>

          <View style={styles.textView}>
            <View
              style={{
                flex: 0.5,
                justifyContent: 'center',
                alignItems: 'flex-start'
              }}
            >
              <Text style={{ fontSize: moderateScale(13), fontWeight: 'bold' }}>
                {data.name}
              </Text>
            </View>

            <View
              style={{
                flex: 0.5,
                flexDirection: 'row',
                justifyContent: 'center',
                alignItems: 'flex-start'
              }}
            >
              {data.categories.map((item, index) => (
                <View
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'flex-start',
                    paddingRight: 3
                  }}
                >
                  <View
                    style={{
                      fontSize: moderateScale(13),
                      backgroundColor: '#00808013',
                      padding: 3,
                      borderRadius: 10,
                      alignSelf: 'flex-start'
                    }}
                  >
                    <Text
                      style={{
                        paddingLeft: moderateScale(10),
                        paddingRight: moderateScale(10)
                      }}
                    >
                      {item}
                    </Text>
                  </View>
                  <View>
                    <Text> </Text>
                  </View>
                </View>
              ))}
            </View>
          </View>
        </View>
      </TouchableOpacity>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    // backgroundColor: 'white',
    // elevation: 1.5,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    // borderRadius: 15,
    // marginBottom: moderateScale(10),
    // marginLeft: moderateScale(10),
    // marginRight: moderateScale(10),
    // shadowOffset: { width: 3, height: 3 },
    // shadowColor: 'grey',
    // shadowOpacity: 0.25,
    // shadowRadius: 5
  },
  textView: {
    flex: 0.85,
    justifyContent: 'center',
    alignItems: 'flex-start'
  },
  checkViewStyle: {
    justifyContent: 'center',
    alignItems: 'center',
    flex: 0.15
  }
});
