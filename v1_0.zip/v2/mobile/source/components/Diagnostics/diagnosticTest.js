import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Dimensions,
  ScrollView,
  TouchableOpacity,
  FlatList,
  ToastAndroid
} from 'react-native';
import { Fab, Button } from 'native-base';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Meteor from 'react-native-meteor';
import Spinner from 'react-native-spinkit';

import Header from '../common/header';
import { SearchField } from '../common/searchField';
import DiagnosticTestViewField from './diagnosticTestViewField';
import ItemDetailsModalView from '../Modal/itemDetailsModalView';
import { moderateScale } from '../../constants/const_functions';
import SpinView from '../common/spinner';

page_size = 10;

export default class DiagnosticTest extends Component {
  constructor(props) {
    super(props);

    this.state = {
      checked: {},
      dList: [],
      clickedItemIdx: undefined,
      isVisibleModalDetails: false,
      isLoaded: false,
      searchQuery: undefined,
      activePage: 1,
      totalPages: 1,
      searchResult: false
    };

    this.fetchDiagnosticTest();
    this.fetchDiagnosticCount();
  }

  fetchDiagnosticCount() {
    const { searchQuery } = this.state;
    Meteor.call(
      'fetchDiagnosticCount',
      { searchQuery, type: 'single' },
      (err, res) => {
        console.log('diagnostic count', err, res);
        if (err) alert('Failed to fetch test count, please try again later');
        else if (res) this.setState({ totalPages: Math.ceil(res / page_size) });
      }
    );
  }

  fetchDiagnosticTest() {
    const { activePage, searchQuery, dList } = this.state;
    Meteor.call(
      'fetchDiagnosticTest',
      { page_no: activePage, searchQuery, type: 'single' },
      (err, res) => {
        console.log(err, res);
        if (err)
          alert(
            'Unfortunately failed to fetch Diagnostic Test list. Please try again later'
          );
        else if (res) {
          this.setState({
            dList: dList.concat(res),
            isLoaded: true,
            activePage: activePage + 1,
            isLoadingMore: false
          });
        }
      }
    );
  }

  handleFab() {
    const selecTedItems = [];
    const { checked } = this.state;
    this.state.dList.map((item, sl_no) => {
      const { name, _id, price } = item;
      if (checked[sl_no]) selecTedItems.push({ name, _id, price });
    });
    if (selecTedItems.length < 1) {
      alert('Please select a test!');
      return;
    }
    this.props.navigation.navigate('DiagnosticsRequest', { selecTedItems });
  }

  handleItemClick(idx) {
    this.setState({
      clickedItemIdx: idx,
      isVisibleModalDetails: !this.state.isVisibleModalDetails
    });
  }

  updateState(obj) {
    this.setState(obj);
  }

  updateIndex(idx) {
    this.setState({
      checked: { ...this.state.checked, [idx]: !this.state.checked[idx] }
    });
  }

  addQuantity() {
    this.setState({ quantity: this.state.quantity + 1 });
  }

  reduceQuantity() {
    if (this.state.quantity === 0) {
      return;
    } else {
      this.setState({ quantity: this.state.quantity - 1 });
    }
  }

  handleSearch() {
    const { searchQuery } = this.state;
    this.setState(
      { isLoaded: false, activePage: 1, dList: [], searchResult: true },
      () => {
        this.fetchDiagnosticCount();
        this.fetchDiagnosticTest(searchQuery);
      }
    );
  }

  handlePaginate() {
    const { activePage, totalPages } = this.state;
    console.log('active_page', activePage);
    this.setState({ isLoadingMore: true });

    if (activePage <= totalPages) {
      this.fetchDiagnosticTest();
    } else {
      this.setState({ isLoadingMore: false });
      if (activePage !== 2)
        ToastAndroid.show('You are at the end of list.', ToastAndroid.SHORT);
    }
  }

  render() {
    const {
      dList,
      checked,
      clickedItemIdx,
      isVisibleModalDetails
    } = this.state;

    data = dList[clickedItemIdx] || {};
    const { name = 'Not Given', description = 'No Description Given' } = data;

    if (!this.state.isLoaded)
      return (
        <View style={{ flex: 1 }}>
          <View style={styles.smallView}>
            <SearchField
              {...this.props}
              updateState={this.updateState.bind(this)}
              placeholderText="Search for a Test"
              handleSearch={this.handleSearch.bind(this)}
            />
          </View>
          <SpinView />
        </View>
      );

    return (
      <View style={styles.container}>
        <ItemDetailsModalView
          visibility={isVisibleModalDetails}
          visibilityStateName={'isVisibleModalDetails'}
          updateState={this.updateState.bind(this)}
          name={name}
          description={description}
          addQuantity={this.addQuantity.bind(this)}
          reduceQuantity={this.reduceQuantity.bind(this)}
          quantity={this.state.quantity}
        />

        <View style={styles.smallView}>
          <SearchField
            {...this.props}
            updateState={this.updateState.bind(this)}
            placeholderText="Search for a Tests"
            value={this.state.searchQuery}
            handleSearch={this.handleSearch.bind(this)}
          />
        </View>

        <View style={styles.largeView}>
          <FlatList
            onEndReached={(info: { distanceFromEnd: number }) => {
              this.handlePaginate();
            }}
            onEndReachedThreshold={0.2}
            data={dList}
            renderItem={({ item, index }) => (
              <DiagnosticTestViewField
                key={index}
                data={item}
                idx={index}
                checked={!!checked[index]}
                handleItemClick={this.handleItemClick.bind(this)}
                updateIndex={this.updateIndex.bind(this)}
                updateState={this.updateState.bind(this)}
              />
            )}
          />
          {this.state.isLoadingMore && (
            <View style={{ position: 'relative', bottom: 20 }}>
              <Spinner
                type="ThreeBounce"
                isVisible={this.state.isLoadingMore}
                size={50}
                color="grey"
              />
            </View>
          )}

          <Fab
            style={{ backgroundColor: '#5067FF' }}
            position="bottomRight"
            containerStyle={{ bottom: 10, right: 10 }}
            onPress={() => this.handleFab()}
          >
            <Icon name="chevron-double-right" />
          </Fab>
        </View>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    flex: 1
  },
  smallView: {
    width: '100%',
    justifyContent: 'flex-end',
    alignItems: 'center',
    marginTop: 5
  },
  largeView: {
    flex: 1,
    justifyContent: 'flex-start',
    width: '100%',
    alignItems: 'center',
    paddingTop: moderateScale(4)
  },
  scrollStyle: {
    flex: 1,
    width: '100%',
    paddingTop: 15,
    backgroundColor: '#ffffff',
    elevation: 2,
    paddingBottom: 10
  }
});
