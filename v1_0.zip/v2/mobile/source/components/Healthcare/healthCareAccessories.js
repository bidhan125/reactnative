import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Dimensions,
  ScrollView,
  Image,
  FlatList,
  ToastAndroid
} from 'react-native';

import { NavigationEvents } from 'react-navigation';
import SnackBar from 'react-native-snackbar-component';
import Spinner from 'react-native-spinkit';

import SpinView from '../common/spinner';
import Header from '../common/header';
import { SearchField } from '../common/searchField';
import PharmaViewField from '../common/pharmaViewField';
import ItemDetailsModalView from '../Modal/itemDetailsModalView';
import Meteor from 'react-native-meteor';
import {
  moderateScale,
  fetchCartData,
  updateCart
} from '../../constants/const_functions';

const page_size = 10;

export default class HealthCareAccessories extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isModalVisible: false,
      quantity: 1,
      mList: [],
      name: null,
      description: 'Not given',
      pharma: '',
      price: null,
      strength: '',
      type: null,
      isLoaded: false,
      cart: {},
      item: {},
      mfg: undefined,
      showSnack: false,
      processing: false,

      activePage: 1,
      totalPages: 1,
      searchResult: false
    };

    this.fetchMedAccessories();
    fetchCartData(this);
    this.fetchTotalAccCount();
  }

  fetchTotalAccCount() {
    const { form, searchQuery } = this.state;
    Meteor.call(
      'fetchTotalAccCount',
      { searchQuery, form, src: 'android' },
      (err, res) => {
        console.log(err, res);
        if (err)
          alert('Failed to fetch accessories count, please try again later');
        else if (res) this.setState({ totalPages: Math.ceil(res / page_size) });
      }
    );
  }

  fetchMedAccessories() {
    const { activePage, searchQuery, mList } = this.state;
    console.log(activePage);
    Meteor.call(
      'fetchMedAccessories',
      { page_no: activePage, searchQuery, src: 'android' },
      (err, res) => {
        // console.log(err, res);
        if (err)
          alert(
            'Unfortunately failed to fetch Diagnostic Test list. Please try again later'
          );
        else if (res) {
          this.setState({
            mList: mList.concat(res),
            isLoaded: true,
            activePage: activePage + 1,
            isLoadingMore: false
          });
          console.log('consoling accessories', res);
        }
      }
    );
  }

  addQuantity() {
    this.setState({ quantity: this.state.quantity + 1 });
  }

  reduceQuantity() {
    if (this.state.quantity === 0) {
      return;
    } else {
      this.setState({ quantity: this.state.quantity - 1 });
    }
  }

  updateState(obj) {
    this.setState(obj);
  }

  handleOrder(item, quantity) {
    this.setState({ processing: true });
    console.log(item, quantity);
    let { cart } = this.state;
    const { name, price, type } = item;
    cart[item._id.toString()] = {
      name,
      price,
      quantity,
      type
    };
    // console.log(cart);
    updateCart(cart, this);
    this.setState(
      {
        isModalVisible: false,
        showSnack: !this.state.showSnack,
        processing: false
      },
      () =>
        setTimeout(() => {
          this.setState({
            showSnack: false
          });
        }, 1500)
    );
  }

  removeItemFromCart(id) {
    let { cart } = this.state;
    delete cart[id];
    updateCart(cart, this);

    this.setState({ removeSnack: true }, () =>
      setTimeout(() => {
        this.setState({
          removeSnack: false
        });
      }, 1500)
    );
  }

  handleSearch() {
    const { searchQuery } = this.state;
    this.setState(
      { isLoaded: false, activePage: 1, mList: [], searchResult: true },
      () => {
        this.fetchTotalAccCount();
        this.fetchMedAccessories(searchQuery);
      }
    );
  }

  handlePaginate() {
    const { activePage, totalPages } = this.state;
    this.setState({ isLoadingMore: true });

    console.log(activePage, totalPages);

    if (activePage <= totalPages) {
      this.fetchMedAccessories();
    } else {
      this.setState({ isLoadingMore: false });
      if (activePage !== 2)
        ToastAndroid.show('You are at the end of list.', ToastAndroid.SHORT);
    }
  }

  render() {
    const { cart, item } = this.state;
    if (!this.state.isLoaded)
      return (
        <View style={{ flex: 1 }}>
          <Header
            text='Health Care Accessories'
            iconLeft='arrowleft'
            iconRight='shoppingcart'
            navigation={this.props.navigation}
          />
          <View style={styles.smallView}>
            <SearchField
              {...this.props}
              updateState={this.updateState.bind(this)}
              placeholderText='Search for a Medicine'
              value
              handleSearch={this.handleSearch.bind(this)}
            />
          </View>
          <SpinView />
        </View>
      );

    if (this.state.processing) {
      return <SpinView />;
    }

    return (
      <View style={styles.container}>
        <NavigationEvents onWillFocus={payload => fetchCartData(this)} />

        <ItemDetailsModalView
          visibilityStateName='isModalVisible'
          visibility={this.state.isModalVisible}
          quantity={this.state.quantity}
          name={this.state.name}
          // description={this.state.description}
          price={this.state.price}
          mfg={this.state.mfg}
          updateState={this.updateState.bind(this)}
          addQuantity={this.addQuantity.bind(this)}
          reduceQuantity={this.reduceQuantity.bind(this)}
          // TODO :: Fetch all properties from this ITEM props in the child component
          item={item}
          handleOrder={this.handleOrder.bind(this)}
        />
        <Header
          text='Health Care Accessories'
          iconLeft='arrowleft'
          iconRight='shoppingcart'
          navigation={this.props.navigation}
        />

        <View style={styles.smallView}>
          <SearchField
            {...this.props}
            updateState={this.updateState.bind(this)}
            placeholderText='Search for a health care accessories'
            value
            handleSearch={this.handleSearch.bind(this)}
          />
        </View>

        {this.state.searchResult && (
          <Text
            style={{
              fontSize: moderateScale(15),
              paddingLeft: 10,
              marginBottom: 10
            }}
          >
            Search matched with {this.state.mList.length} items:
          </Text>
        )}

        <View style={styles.largeView}>
          <FlatList
            onEndReached={(info: { distanceFromEnd: number }) => {
              this.handlePaginate();
            }}
            style={{ width: '100%' }}
            onEndReachedThreshold={0.2}
            data={this.state.mList}
            renderItem={({ item }) => (
              <PharmaViewField
                onPress={() =>
                  this.setState({
                    // TODO :: use ITEM to store nested properties
                    item,
                    isModalVisible: !this.state.isModalVisible,
                    name: item.name,
                    mfg: item.mfg,
                    price: item.price,
                    type: item.type,
                    quantity: cart.hasOwnProperty(item._id)
                      ? cart[item._id].quantity
                      : 1
                  })
                }
                // TODO :: use ITEM to store nested properties
                item={item}
                // key={sl_no}
                medicineName={item.name}
                mfg={item.mfg}
                medicinePrice={item.price}
                medicineType={item.type}
                isOrdered={cart.hasOwnProperty(item._id)}
                quantity={
                  cart.hasOwnProperty(item._id) ? cart[item._id].quantity : 1
                }
                removeItemFromCart={this.removeItemFromCart.bind(this)}
              />
            )}
          />
          {this.state.isLoadingMore && (
            <View style={{ position: 'relative', bottom: 20 }}>
              <Spinner
                type='ThreeBounce'
                isVisible={this.state.isLoadingMore}
                size={50}
                color='grey'
              />
            </View>
          )}
        </View>
        <SnackBar
          visible={this.state.showSnack}
          textMessage='Your order has been added to cart!'
          actionHandler={() => {
            this.setState({ showSnack: !this.state.showSnack });
          }}
          actionText='Ok'
          position='bottom'
          autoHidingTime={2000}
        />

        <SnackBar
          visible={this.state.removeSnack}
          textMessage='Your order has been removed from cart!'
          actionHandler={() => {
            this.setState({ removeSnack: !this.state.removeSnack });
          }}
          actionText='Ok'
          position='bottom'
          autoHidingTime={2000}
        />
      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    flex: 1
  },
  smallView: {
    flex: 0.09,
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: moderateScale(5)
  },
  largeView: {
    flex: 1,
    justifyContent: 'flex-start',
    width: '100%',
    alignItems: 'center'
  },
  scrollStyle: {
    flex: 1,
    width: '100%',
    paddingTop: 13,
    backgroundColor: '#ffffff',
    paddingBottom: 10
  }
});
