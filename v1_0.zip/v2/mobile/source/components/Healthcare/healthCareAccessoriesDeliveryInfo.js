import React, { Component } from 'react';
import {
  Platform,
  KeyboardAvoidingView,
  StyleSheet,
  Text,
  View,
  Dimensions,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Picker,
  Button
} from 'react-native';
import Icon from 'react-native-vector-icons/AntDesign';
import PlusIcon from 'react-native-vector-icons/FontAwesome5';
import Header from '../common/header';

export default class HealthCareAccessoriesDeliveryInfo extends Component {
  state = {
    text: '',
    chosenValue: 'key0'
  };

  render() {
    const { height, width } = Dimensions.get('window');

    return (
      <View style={styles.container}>
        <Header
          text="Order Accessories"
          iconLeft="arrowleft"
          iconRight="shoppingcart"
          navigation={this.props.navigation}
        />
        <View style={styles.viewStyle}>
          <ScrollView
            style={styles.scrollViewStyle}
            contentContainerStyle={{ justifyContent: 'flex-start' }}
          >
            <View style={{ height: height * 0.03, justifyContent: 'center' }}>
              <Text style={{ fontSize: 16 }}>Select the beneficiary</Text>
            </View>

            <Picker
              style={styles.beneficiaryViewStyle}
              selectedValue={this.state.chosenValue}
              mode="dropdown"
              onValueChange={(itemValue, itemIndex) =>
                this.setState({ chosenValue: itemValue })
              }
            >
              <Picker.Item label="BENEFICIARY" value="key0" />
              <Picker.Item label="Myself" value="key1" />
              <Picker.Item label="Father" value="key2" />
              <Picker.Item label="Mother" value="key3" />
            </Picker>
            <View style={{ height: height * 0.04, justifyContent: 'center' }}>
              <Text style={{ fontSize: 16 }}>Select Address:</Text>
            </View>

            <View style={styles.dropDownViewStyle}>
              <Picker
                style={{ flex: 0.4 }}
                selectedValue={this.state.chosenValueCity}
                mode="dropdown"
                onValueChange={(itemValue, itemIndex) =>
                  this.setState({ chosenValueCity: itemValue })
                }
              >
                <Picker.Item label="Select City" value="key0" />
                <Picker.Item label="Dhaka" value="key1" />
                <Picker.Item label="Chittagong" value="key2" />
                <Picker.Item label="Sylhet" value="key3" />
              </Picker>

              <Picker
                style={{ flex: 0.42 }}
                selectedValue={this.state.chosenValueArea}
                mode="dropdown"
                onValueChange={(itemValue, itemIndex) =>
                  this.setState({ chosenValueArea: itemValue })
                }
              >
                <Picker.Item label="Select Area" value="key0" />
                <Picker.Item label="Dhanmondi" value="key1" />
                <Picker.Item label="Mirpur" value="key2" />
                <Picker.Item label="Gulshan" value="key3" />
              </Picker>
            </View>

            <View style={styles.inputStyle} height={height * 0.1}>
              <TextInput
                placeholder="Type address"
                multiline={true}
                editable={true}
                onChangeText={text => this.setState({ text })}
                value={this.state.text}
                style={{ backgroundColor: '#ddddddaa' }}
                numberOfLines={2}
                textAlignVertical="top"
                underlineColorAndroid="transparent"
              />
            </View>

            <View style={{ height: height * 0.05, justifyContent: 'center' }}>
              <Text style={{ fontSize: 16 }}>Ordered Accessories Names:</Text>
            </View>

            <View style={styles.lastViewStyle}>
              <View style={styles.costViewStyle}>
                <View styles={{ height: '100%' }} flex={40}>
                  <Text style={{ fontWeight: 'bold' }}>Scissors</Text>
                </View>
                <View style={styles.tinyViewStyle} flex={8}>
                  <Icon name="minuscircleo" size={18} />
                </View>
                <View style={styles.tinyViewStyle} flex={4}>
                  <Text>3</Text>
                </View>
                <View style={styles.tinyViewStyle} flex={8}>
                  <Icon name="pluscircleo" size={18} />
                </View>
                <View style={styles.tinyViewStyle} flex={4} />
                <View style={styles.tinyViewStyle} flex={4}>
                  <Text>1</Text>
                </View>
                <View style={styles.tinyViewStyle} flex={8}>
                  <Icon name="close" size={16} />
                </View>
                <View style={styles.tinyViewStyle} flex={4} />
                <View style={styles.tinyViewStyle} flex={20}>
                  <Text>230 BDT</Text>
                </View>
              </View>

              <View style={styles.costViewStyle}>
                <View styles={{ height: '100%' }} flex={40}>
                  <Text style={{ fontWeight: 'bold' }}>BPM Device</Text>
                </View>
                <View style={styles.tinyViewStyle} flex={8}>
                  <Icon name="minuscircleo" size={18} />
                </View>
                <View style={styles.tinyViewStyle} flex={4}>
                  <Text>3</Text>
                </View>
                <View style={styles.tinyViewStyle} flex={8}>
                  <Icon name="pluscircleo" size={18} />
                </View>
                <View style={styles.tinyViewStyle} flex={4} />
                <View style={styles.tinyViewStyle} flex={4}>
                  <Text>1</Text>
                </View>
                <View style={styles.tinyViewStyle} flex={8}>
                  <Icon name="close" size={16} />
                </View>
                <View style={styles.tinyViewStyle} flex={4} />
                <View style={styles.tinyViewStyle} flex={20}>
                  <Text>230 BDT</Text>
                </View>
              </View>
            </View>
          </ScrollView>
        </View>
        <View style={styles.buttonStyle}>
          <Button title="Confirm" color="#1285ff" />
        </View>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    flex: 1,
    alignItems: 'center'
  },
  viewStyle: {
    flex: 0.85,
    width: '94%',
    justifyContent: 'flex-start',
    alignItems: 'center'
  },
  scrollViewStyle: {
    flex: 1,
    paddingTop: 12,
    width: '100%',
    marginTop: 1
  },

  beneficiaryViewStyle: {
    width: '100%'
  },
  inputStyle: {
    marginTop: 5,
    marginBottom: 5
  },
  datePickerStyle: {
    alignItems: 'center'
  },
  lastViewStyle: {
    marginTop: 10,
    paddingTop: 10,
    marginBottom: 30,
    paddingBottom: 5,
    justifyContent: 'space-evenly',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    width: '98%',
    elevation: 1,
    alignSelf: 'center',
    paddingBottom: 100
  },
  costViewStyle: {
    width: '94%',
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    paddingBottom: 10
  },

  buttonStyle: {
    flex: 0.1,
    justifyContent: 'flex-start',
    alignItems: 'center',
    width: '94%'
  },
  dropDownViewStyle: {
    flexDirection: 'row',
    width: '100%',
    justifyContent: 'space-between',
    alignItems: 'center'
  }
});
