import React, { Component } from 'react';
import {
  Alert,
  Platform,
  StyleSheet,
  Text,
  View,
  Dimensions,
  Image,
  TextInput,
  TouchableOpacity,
  Picker,
  ScrollView,
  KeyboardAvoidingView
} from 'react-native';

import { CheckBox } from 'react-native-elements';
import Modal from 'react-native-modal';
import {
  Button,
  Fab,
  Picker as PickerNative,
  Icon as IconNative
} from 'native-base';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import TextInputMask from 'react-native-text-input-mask';

import Header from '../common/header';
import GreenButton from '../common/lifeplusGreenButton';
import call from 'react-native-phone-call';
import Meteor from 'react-native-meteor';

import { branchCity } from '../../constants/const_strings';
import PaymentModal from '../Modal/paymentModal';
import {
  scale,
  verticalScale,
  moderateScale,
  validation
} from '../../constants/const_functions';
import SpinView from '../common/spinner';

export default class NursingCare extends Component {
  state = {
    text: '',
    isPaymentModalVisible: false,
    isModalVisible: false,
    chosenValueCity: 'key1',
    chosenValueArea: 'key0',
    district: undefined,
    patientCondition: undefined,
    processing: false
  };

  updateState(obj) {
    this.setState(obj);
  }

  handleSubmit(paymentMethod) {
    const ttitle = this.props.navigation.getParam('title', 'No Title');
    const { name, district, gender, age, patientCondition } = this.state;

    const address = this.state.address || Meteor.user().profile.address;
    const email = Meteor.user().profile.email;

    if (this.state.phone !== undefined) {
      var phone = 0 + this.state.phone;
    }

    data = {
      name,
      address,
      district,
      gender,
      age,
      phone,
      patientCondition,
      orderType: 'home_care',
      serviceName: ttitle,
      paymentMethod
    };

    console.log(phone);
    if (validation(phone, 'isPhone') !== true) return;

    if (district === undefined) {
      alert('Please select a city!');
      return;
    }
    // if (address === undefined || address.length <= 0) {
    //   alert('Please give your full address');
    //   return;
    // }
    if (validation(name, 'isName') !== true) return;

    if (gender === undefined) {
      alert('Please select a gender!');
      return;
    }

    if (patientCondition === undefined) {
      alert('Please select the condition of the patient!');
      return;
    }

    this.setState({ processing: true });

    const order = {
      amount: 2000,
      currency: 'BDT',
      redirect_url: 'http://google.com'
    };
    const product = {
      name: 'Home Care',
      description: 'Home care service'
    };
    const billing = {
      customer: {
        name: name,
        email: email,
        phone: phone,
        address: {
          street: address,
          city: district || 'Dhaka',
          state: district || 'Dhaka',
          zipcode: '1000',
          country: 'BD'
        }
      }
    };

    Meteor.call('addOrder', data, (err, res) => {
      console.log(err, res);
      this.setState({ processing: false });
      if (err) {
        alert(
          'Sorry! Failed to submit your request at this moment. Please try again later'
        );
      } else if (res) {
        if (paymentMethod === 'Pay Online') {
          this.props.navigation.navigate('PaymentGateway', {
            orderId: res,
            order: order,
            product: product,
            billing: billing
          });
        } else {
          Alert.alert(
            'Success',
            'Congratulations! Your request has been received successfully! Thank you!',
            [
              {
                text: 'Ok',
                onPress: () => this.props.navigation.navigate('Home')
              }
            ],
            { cancelable: false }
          );
        }
      }
    });
  }

  render() {
    const args = {
      number: '999',
      prompt: false
    };

    const ttitle = this.props.navigation.getParam('title', 'No Title');
    const distOptions = [];
    branchCity.map(item =>
      distOptions.push(<Picker.Item label={item.name} value={item.name} />)
    );

    if (this.state.processing) {
      return <SpinView />;
    }

    return (
      <KeyboardAvoidingView style={styles.container}>
        <Header
          text={ttitle}
          iconLeft='arrowleft'
          iconRight='shoppingcart'
          navigation={this.props.navigation}
        />
        <PaymentModal
          visibilityStateName='isPaymentModalVisible'
          visibility={this.state.isPaymentModalVisible}
          updateState={this.updateState.bind(this)}
          handleSubmit={this.handleSubmit.bind(this)}
        />
        <ScrollView
          style={{ width: '100%' }}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{
            justifyContent: 'flex-start',
            alignItems: 'center'
          }}
        >
          <View style={styles.viewStyle}>
            <View
              style={{
                flex: 25,
                elevation: 2,
                backgroundColor: 'white',
                marginTop: 10,
                borderRadius: 10,
                marginBottom: 20,
                shadowOffset: { width: 3, height: 3 },
                shadowColor: 'grey',
                shadowOpacity: 0.25,
                shadowRadius: 5
              }}
            >
              <View
                style={{
                  flex: 10,
                  alignSelf: 'flex-start',
                  width: '100%',
                  borderBottomColor: '#F4F4F5',
                  borderBottomWidth: 1,
                  paddingLeft: moderateScale(10)
                }}
              >
                <Text style={styles.textViewStyle} alignSelf='flex-start'>
                  Patient's Address
                </Text>
              </View>

              <View style={styles.dropDownViewStyle}>
                <View
                  style={{
                    flex: 1,
                    width: '100%',
                    elevation: 1,
                    height: moderateScale(45),
                    borderRadius: 10,
                    marginLeft: moderateScale(10),
                    marginRight: moderateScale(10),
                    backgroundColor: 'white',
                    shadowOffset: { width: 3, height: 3 },
                    shadowColor: 'grey',
                    shadowOpacity: 0.25,
                    shadowRadius: 5
                  }}
                >
                  {(Platform.OS == 'android' && (
                    <Picker
                      style={{ flex: 1 }}
                      selectedValue={this.state.district}
                      mode='dropdown'
                      onValueChange={(itemValue, itemIndex) =>
                        this.setState({ district: itemValue })
                      }
                    >
                      <Picker.Item label='Select City' value='key0' />
                      {distOptions}
                    </Picker>
                  )) || (
                    <PickerNative
                      style={{
                        width: '100%'
                      }}
                      placeholder='Select your city'
                      iosHeader='Select your city'
                      iosIcon={<IconNative name='arrow-down' />}
                      selectedValue={this.state.district}
                      mode='dropdown'
                      onValueChange={(itemValue, itemIndex) =>
                        this.setState({ district: itemValue })
                      }
                    >
                      {distOptions}
                    </PickerNative>
                  )}
                </View>
              </View>
              <View style={styles.addressInputStyle}>
                <TextInput
                  placeholder="Type patient's address, (Your profile address will be used if left Empty)"
                  multiline={true}
                  editable={true}
                  onChangeText={address => this.setState({ address })}
                  value={this.state.address}
                  style={{ backgroundColor: '#F4F4F5', height: '100%' }}
                  numberOfLines={4}
                  textAlignVertical='top'
                />
              </View>
            </View>
            <View style={styles.patientInfoViewStyle}>
              <View
                style={{
                  flex: 6,
                  alignSelf: 'flex-start',
                  width: '100%',
                  paddingLeft: moderateScale(10),
                  borderBottomColor: '#F4F4F5',
                  borderBottomWidth: 1
                }}
              >
                <Text style={styles.textViewStyle} alignSelf='flex-start'>
                  Patient's Details
                </Text>
              </View>
              <View style={styles.nameViewStyle} flex={7}>
                <TextInput
                  style={{
                    height: moderateScale(40),
                    borderColor: '#BCBDC0',
                    borderBottomWidth: 1,
                    fontSize: moderateScale(14),
                    marginTop: verticalScale(15),
                    marginBottom: verticalScale(10)
                  }}
                  value={this.state.name}
                  onChangeText={name => this.setState({ name })}
                  placeholder="Type patient's name"
                  onSubmitEditing={() => this.refs.age.focus()}
                  returnKeyType='next'
                />
              </View>
              <View style={styles.genderViewStyle} flex={7}>
                <Text
                  style={{
                    fontSize: moderateScale(14),
                    justifyContent: 'flex-start',
                    fontWeight: 'bold',
                    color: '#777777'
                  }}
                >
                  Gender
                </Text>
                <CheckBox
                  title='Male'
                  checked={this.state.gender == 'male'}
                  containerStyle={styles.checkBoxStyle}
                  onPress={() => this.setState({ gender: 'male' })}
                />

                <CheckBox
                  title='Female'
                  checked={this.state.gender == 'female'}
                  containerStyle={styles.checkBoxStyle}
                  onPress={() => this.setState({ gender: 'female' })}
                />
              </View>

              <View style={styles.specsViewStyle} flex={7} alignItems='center'>
                <TextInput
                  ref='age'
                  style={{
                    flex: 0.35,
                    height: moderateScale(40),
                    borderColor: 'gray',
                    fontSize: moderateScale(14),
                    marginRight: moderateScale(10)
                  }}
                  value={this.state.age}
                  onChangeText={age => this.setState({ age })}
                  placeholder='Age'
                  multiline={false}
                  keyboardType='numeric'
                  borderBottomWidth={1}
                  width={120}
                  // onSubmitEditing={() => this.refs.phone.focus()}
                  returnKeyType='next'
                />
                <View
                  style={{
                    flex: 0.65,
                    elevation: 1,
                    borderRadius: 10,
                    height: moderateScale(45),
                    backgroundColor: 'white',
                    shadowOffset: { width: 3, height: 3 },
                    shadowColor: 'grey',
                    shadowOpacity: 0.25,
                    shadowRadius: 5
                  }}
                >
                  {(Platform.OS == 'android' && (
                    <Picker
                      style={{ flex: 1 }}
                      itemStyle={{ fontSize: moderateScale(14) }}
                      selectedValue={this.state.patientCondition}
                      mode='dropdown'
                      onValueChange={(itemValue, itemIndex) =>
                        this.setState({ patientCondition: itemValue })
                      }
                    >
                      <Picker.Item
                        label='Patient Condition'
                        value={undefined}
                      />
                      <Picker.Item label='Mildly Sick' value='key1' />
                      <Picker.Item label='Moderate' value='key2' />
                      <Picker.Item label='Severe' value='key3' />
                    </Picker>
                  )) || (
                    <PickerNative
                      style={{ width: '100%' }}
                      placeholder='Patient Condition'
                      // placeholderStyle={{color: 'black'}}
                      iosHeader='Select Patient Condition'
                      iosIcon={<IconNative name='arrow-down' />}
                      itemStyle={{ fontSize: moderateScale(14) }}
                      selectedValue={this.state.patientCondition}
                      mode='dropdown'
                      onValueChange={(itemValue, itemIndex) =>
                        this.setState({ patientCondition: itemValue })
                      }
                    >
                      <PickerNative.Item label='Mildly Sick' value='key1' />
                      <PickerNative.Item label='Moderate' value='key2' />
                      <PickerNative.Item label='Severe' value='key3' />
                    </PickerNative>
                  )}
                </View>
              </View>

              <View
                style={{
                  flex: 7,
                  flexDirection: 'row',
                  alignItems: 'center',
                  width: '92%',
                  marginBottom: moderateScale(10)
                }}
              >
                <View
                  style={{
                    flex: 1,
                    flexDirection: 'row',
                    alignItems: 'center',
                    width: '100%'
                  }}
                >
                  <Text style={{ fontWeight: 'bold' }}>Mobile Number </Text>
                  {/* <Text style={{ fontSize: moderateScale(14) }}>+88 </Text> */}
                  {/* <TextInput
                    ref='phone'
                    style={styles.numberInputStyle}
                    value={this.state.phone}
                    onChangeText={phone => this.setState({ phone })}
                    keyboardType='phone-pad'
                  /> */}
                  <TextInputMask
                    style={styles.numberInputStyle}
                    value={this.state.phone}
                    onChangeText={(formatted, phone) => {
                      this.setState({ phone });
                      console.log(formatted); // +1 (123) 456-78-90
                      console.log(phone); // 1234567890
                    }}
                    mask={'+880 [0000] [000000]'}
                    keyboardType='numeric'
                  />
                </View>
              </View>
            </View>

            {/* <View style={styles.payCashViewStyle}>
              <Text style={{ fontSize: moderateScale(14), fontWeight: 'bold' }}>
                Payment Method
              </Text>
              <TouchableOpacity
                disabled
                onPress={() =>
                  this.setState({
                    isPaymentModalVisible: !this.state.isPaymentModalVisible
                  })
                }
              >
                <View style={{ flexDirection: 'row' }}>
                  <Text
                    style={{ fontSize: moderateScale(14), color: '#1285ff' }}
                  >
                    {this.state.paymentMethod + ' '}
                  </Text>
                  <Icon name='arrow-right' size={20} color='#1285ff' />
                </View>
              </TouchableOpacity>
            </View> */}

            <View style={styles.button}>
              <GreenButton
                buttonLength='100%'
                buttonText='  Send Request  '
                buttonFont={moderateScale(17)}
                passFunction={this.updateState.bind(this, {
                  isPaymentModalVisible: !this.state.isPaymentModalVisible
                })}
              />
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    );
  }
}

const height = Dimensions.get('window').height;
const width = Dimensions.get('window').width;

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    flex: 1,
    alignItems: 'center'
  },
  viewStyle: {
    flex: 1,
    width: '95%'
  },
  textViewStyle: {
    flex: 5,
    fontSize: moderateScale(14),
    fontWeight: 'bold',
    paddingTop: moderateScale(16),
    height: verticalScale(40)
  },
  dropDownViewStyle: {
    flex: 8,
    flexDirection: 'row',
    alignItems: 'center',
    height: verticalScale(60)
  },
  addressInputStyle: {
    flex: 10,
    padding: moderateScale(10),
    height: moderateScale(100)
  },
  patientInfoViewStyle: {
    flex: 35,
    backgroundColor: '#ffffff',
    elevation: 2,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: moderateScale(5),
    height: verticalScale(300),
    shadowOffset: { width: 3, height: 3 },
    shadowColor: 'grey',
    shadowOpacity: 0.25,
    shadowRadius: 5
  },
  button: {
    flex: 15,
    justifyContent: 'center',
    alignItems: 'center',
    height: moderateScale(100)
  },
  nameViewStyle: {
    flex: 18,
    width: '92%',
    justifyContent: 'center'
  },
  genderViewStyle: {
    flex: 7,
    width: '92%',
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    alignItems: 'center',
    marginTop: moderateScale(5)
  },
  phoneNumberViewStyle: {
    flex: 15,
    width: '92%',
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    marginBottom: moderateScale(10)
  },
  numberInputStyle: {
    flex: 1,
    borderColor: 'gray',
    borderBottomWidth: 1,
    fontSize: moderateScale(14),
    marginLeft: 5
  },
  checkBoxStyle: {
    backgroundColor: '#ffffff',
    width: '36%'
  },
  specsViewStyle: {
    flex: 7,
    width: '92%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  smallViewStyle: {
    flex: 0.5,
    alignItems: 'center'
  },
  modalStyle: {
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1
  },
  modalInsideViewStyle: {
    flex: 0.5,
    justifyContent: 'flex-start',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    width: '100%',
    borderRadius: 10
  },
  modalChildStyle: {
    flex: 0.33,
    width: '100%',
    alignItems: 'center'
  },
  modalButtonView: {
    flex: 0.33,
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center'
  },
  payCashViewStyle: {
    flex: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: verticalScale(40)
  }
});
