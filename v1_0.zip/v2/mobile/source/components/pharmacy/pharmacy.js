import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Dimensions,
  ScrollView,
  Image,
  KeyboardAvoidingView,
  FlatList,
  ToastAndroid
} from 'react-native';
import Meteor from 'react-native-meteor';
import SnackBar from 'react-native-snackbar-component';
import Spinner from 'react-native-spinkit';
import { NavigationEvents } from 'react-navigation';

import SpinView from '../common/spinner';
import Header from '../common/header';
import { SearchField } from '../common/searchField';
import PharmaViewField from '../common/pharmaViewField';
import ItemDetailsModalView from '../Modal/itemDetailsModalView';
import { medicine_types } from '../../constants/const_strings';
import {
  moderateScale,
  fetchCartData,
  updateCart
} from '../../constants/const_functions';

const { width, height } = Dimensions.get('window');

page_size = 10;

export default class Pharmacy extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isModalVisible: false,
      searchQuery: undefined,
      quantity: 1,
      mList: [],
      name: null,
      description: 'Not given',
      pharma: '',
      price: null,
      strength: undefined,
      type: null,
      isLoaded: false,
      cart: {},
      item: {},
      showSnack: false,
      removeSnack: false,
      packsize: undefined,
      administration: undefined,
      indication: undefined,
      interaction: undefined,
      genericName: undefined,
      processing: false,

      activePage: 1,
      totalPages: 1,
      searchResult: false
    };

    this.fetchMedicines();
    fetchCartData(this);
    this.fetchTotalMedicineCount();
  }

  updateState(obj) {
    this.setState(obj);
  }

  fetchTotalMedicineCount() {
    const { form, searchQuery } = this.state;
    Meteor.call(
      'fetchTotalMedicineCount',
      { searchQuery, form, src: 'android' },
      (err, res) => {
        console.log(err, res);
        if (err)
          alert('Failed to fetch medicine count, please try again later');
        else if (res) this.setState({ totalPages: Math.ceil(res / page_size) });
      }
    );
  }

  fetchMedicines() {
    const { activePage, searchQuery, mList } = this.state;
    Meteor.call(
      'fetchMedicines',
      { page_no: activePage, searchQuery, src: 'android' },
      (err, res) => {
        // console.log(err, res);
        if (err) alert('Unfortunately failed to fetch  More Medicine.');
        else if (res) {
          this.setState({
            mList: mList.concat(res),
            isLoaded: true,
            activePage: activePage + 1,
            isLoadingMore: false
          }, () => console.log(res));
        }
      }
    );
  }

  addQuantity() {
    this.setState({ quantity: this.state.quantity + 1 });
  }

  reduceQuantity() {
    if (this.state.quantity === 0) {
      return;
    } else {
      this.setState({ quantity: this.state.quantity - 1 });
    }
  }

  handleOrder(item, quantity) {
    this.setState({ processing: true, isModalVisible: false });
    let { cart } = this.state;
    const { brand_name: name, price, form: type, form } = item;
    cart[item._id.toString()] = {
      name,
      price,
      quantity,
      type,
      form
    };

    updateCart(cart, this);
    this.setState(
      {
        isModalVisible: false,
        showSnack: !this.state.showSnack,
        processing: false
      },
      () =>
        setTimeout(() => {
          this.setState({
            showSnack: false
          });
        }, 1500)
    );
  }

  removeItemFromCart(id) {
    let { cart } = this.state;
    delete cart[id];
    updateCart(cart, this);
    this.setState({ removeSnack: true }, () =>
      setTimeout(() => {
        this.setState({
          removeSnack: false
        });
      }, 1500)
    );
  }

  handleSearch() {
    const { searchQuery } = this.state;
    this.setState(
      { isLoaded: false, activePage: 1, mList: [], searchResult: true },
      () => {
        this.fetchTotalMedicineCount();
        this.fetchMedicines(searchQuery);
      }
    );
  }

  handlePaginate() {
    const { activePage, totalPages } = this.state;
    this.setState({ isLoadingMore: true });

    if (activePage <= totalPages) {
      this.fetchMedicines();
    } else {
      this.setState({ isLoadingMore: false });
      if (activePage !== 2)
        ToastAndroid.show('You are at the end of list.', ToastAndroid.SHORT);
    }
  }

  render() {
    const { cart, item, mList, totalPages, activePage } = this.state;
    console.log('cart',cart)

    if (!this.state.isLoaded)
      return (
        <View style={{ flex: 1 }}>
          <Header
            text='Pharmacy'
            iconLeft='arrowleft'
            iconRight='shoppingcart'
            navigation={this.props.navigation}
          />
          <SearchField
            {...this.props}
            updateState={this.updateState.bind(this)}
            placeholderText='Search for a Medicine'
            handleSearch={this.handleSearch.bind(this)}
          />
          <SpinView />
        </View>
      );

    if (this.state.processing) {
      return <SpinView />;
    }

    return (
      <View style={styles.container}>
        <NavigationEvents onWillFocus={payload => fetchCartData(this)} />

        <ItemDetailsModalView
          visibilityStateName='isModalVisible'
          visibility={this.state.isModalVisible}
          updateState={this.updateState.bind(this)}
          addQuantity={this.addQuantity.bind(this)}
          reduceQuantity={this.reduceQuantity.bind(this)}
          quantity={this.state.quantity}
          name={this.state.name}
          price={this.state.price}
          strength={this.state.strength}
          pharma={this.state.pharma}
          type={this.state.type}
          item={item}
          packsize={this.state.packsize}
          administration={this.state.administration}
          indication={this.state.indication}
          interaction={this.state.interaction}
          handleOrder={this.handleOrder.bind(this)}
          genericName={this.state.genericName}
        />
        <Header
          text='Pharmacy'
          iconLeft='arrowleft'
          iconRight='shoppingcart'
          navigation={this.props.navigation}
        />
        <View style={styles.smallView}>
          <SearchField
            {...this.props}
            updateState={this.updateState.bind(this)}
            placeholderText={'Search for a Medicine'}
            value={this.state.searchQuery}
            handleSearch={this.handleSearch.bind(this)}
          />
        </View>
        {this.state.searchResult && (
          <Text
            style={{
              fontSize: moderateScale(15),
              paddingLeft: 10,
              marginBottom: 10
            }}
          >
            Search matched with {this.state.mList.length} items:
          </Text>
        )}

        <View style={styles.largeView}>
          <FlatList
            style={{ width: width }}
            onEndReached={(info: { distanceFromEnd: number }) => {
              this.handlePaginate();
            }}
            onEndReachedThreshold={0.2}
            data={this.state.mList}
            renderItem={({ item }) => (
              <PharmaViewField
                onPress={() =>
                  this.setState({
                    item,
                    isModalVisible: !this.state.isModalVisible,

                    name: item.brand_name,
                    pharma: item.pharma,
                    price: item.price,
                    strength: item.strength,
                    type: item.form,
                    packsize: item.packsize,
                    indication: item.indication,
                    administration: item.administration,
                    interaction: item.interaction,
                    genericName: item.generic_name,
                    quantity: cart.hasOwnProperty(item._id)
                      ? cart[item._id].quantity
                      : 1
                  })
                } // TODO :: use ITEM to store nested properties
                item={item}
                medicineName={item.brand_name}
                medicineStrength={item.strength}
                medicinePrice={item.price}
                medicineType={item.form}
                isOrdered={cart.hasOwnProperty(item._id)}
                quantity={
                  cart.hasOwnProperty(item._id) ? cart[item._id].quantity : 1
                }
                removeItemFromCart={this.removeItemFromCart.bind(this)}
              />
            )}
          />
          {this.state.isLoadingMore && (
            <View style={{ position: 'relative', bottom: 20 }}>
              <Spinner
                type='ThreeBounce'
                isVisible={this.state.isLoadingMore}
                size={50}
                color='grey'
              />
            </View>
          )}
        </View>
        <SnackBar
          visible={this.state.removeSnack}
          textMessage='Medicine has been removed from cart!'
          actionHandler={() => {
            this.setState({ removeSnack: !this.state.removeSnack });
          }}
          actionText='Ok'
          position='bottom'
          autoHidingTime={1000}
        />
        <SnackBar
          visible={this.state.showSnack}
          textMessage='Medicine has been added to the cart!'
          actionHandler={() => {
            this.setState({ showSnack: !this.state.removeSnack });
          }}
          actionText='Ok'
          position='bottom'
          autoHidingTime={2000}
        />
      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    flex: 1
  },
  smallView: {
    flex: 0.09,
    width: width,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: moderateScale(5)
  },
  largeView: {
    flex: 1,
    justifyContent: 'flex-start',
    // width: width,
    alignItems: 'center'
  },
  scrollStyle: {
    flex: 1,
    width: '100%',
    paddingTop: 15,
    backgroundColor: '#ffffff',
    elevation: 2
  },
  modalStyle: {
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1
  },
  modalInsideViewStyle: {
    flex: 0.45,
    justifyContent: 'flex-start',
    alignItems: 'center',
    backgroundColor: '#eeeeee',
    width: '100%',
    borderRadius: 10
  },
  modalChildStyle: {
    flex: 0.33,
    width: '100%',
    alignItems: 'center'
  },
  modalButtonView: {
    flex: 0.33,
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center'
  }
});
