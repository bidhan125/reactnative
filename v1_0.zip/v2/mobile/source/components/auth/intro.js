import React from 'react';
import { AsyncStorage, Dimensions, StyleSheet, View, Text } from 'react-native';
import AppIntroSlider from 'react-native-app-intro-slider';
import Icon from 'react-native-vector-icons/Ionicons';

import LogIn from './logIn';
import { moderateScale } from '../../constants/const_functions';

const height = Dimensions.get('window').height;
const width = Dimensions.get('window').width;

const styles = StyleSheet.create({
  image: {
    width: moderateScale(180),
    height: moderateScale(180),
    resizeMode: 'contain'
  },
  buttonCircle: {
    width: 40,
    height: 40,
    backgroundColor: 'rgba(0, 0, 0, .2)',
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center'
  }
});

const slides = [
  {
    key: 'somethun',
    title: 'Medical Appointment',
    titleStyle: { color: '#0076BE', textAlign: 'center' },
    text:
      'Helps to get active appointments of Efficient and Effective Doctor for patients ',
    image: require('../../assets/intro/appointment.png'),
    textStyle: { color: '#1a1a1a', fontSize: moderateScale(14) },
    imageStyle: styles.image,
    backgroundColor: 'white'
  },
  {
    key: 'somethun-dos',
    title: 'Home Nursing',
    titleStyle: { color: '#0076BE', textAlign: 'center' },
    text:
      'We provide medical home care for the patients who are unable to move or come',
    image: require('../../assets/intro/home_nursing.png'),
    textStyle: { color: '#1a1a1a', fontSize: moderateScale(14) },
    imageStyle: styles.image,
    backgroundColor: 'white'
  },
  {
    key: 'somethun1',
    title: 'Online Medicine and Accessories',
    titleStyle: { color: '#0076BE', textAlign: 'center' },
    text:
      'We provide quality medicine through online order to our patients We also provide medical accessories for our patient’s convenience',
    textStyle: { color: '#1a1a1a', fontSize: moderateScale(14) },
    image: require('../../assets/intro/online_medicine.png'),
    imageStyle: styles.image,
    backgroundColor: 'white'
  },
  {
    key: 'somethun2',
    title: 'Sample Collection  and Report Home Delivery',
    titleStyle: { color: '#0076BE', textAlign: 'center' },
    text:
      "We provide report at our patient's home. We also help patient by collecting sample at patient's home and deliver the reports to their home again",
    textStyle: { color: '#1a1a1a', fontSize: moderateScale(14) },
    image: require('../../assets/intro/sample_collection.png'),
    imageStyle: styles.image,
    backgroundColor: 'white'
  },
  {
    key: 'somethun3',
    title: 'Ambulance and Emergency',
    titleStyle: { color: '#0076BE', textAlign: 'center' },
    text:
      'We also provide direct emergency and ambulance service to our patient',
    textStyle: { color: '#1a1a1a', fontSize: moderateScale(14) },
    image: require('../../assets/intro/ambulance.png'),
    imageStyle: styles.image,
    backgroundColor: 'white'
  }
];

export default class IntroSlider extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showRealApp: false
    };
  }
  _renderSkipButton = () => {
    return (
      <Text style={{ color: 'rgba(0, 0, 0, .5)', fontSize: moderateScale(15) }}>
        SKIP
      </Text>
    );
  };
  _renderNextButton = () => {
    return (
      <View style={styles.buttonCircle}>
        <Icon
          name="md-arrow-round-forward"
          color="rgba(255, 255, 255, .9)"
          size={24}
          style={{ backgroundColor: 'transparent' }}
        />
      </View>
    );
  };
  _renderDoneButton = () => {
    return (
      <View style={styles.buttonCircle}>
        <Icon
          name="md-checkmark"
          color="rgba(255, 255, 255, .9)"
          size={24}
          style={{ backgroundColor: 'transparent' }}
        />
      </View>
    );
  };

  _onSkip = async () => {
    // User finished the introduction. Show real app through
    // navigation or simply by controlling state
    // this.setState({ showRealApp: true });
    await AsyncStorage.setItem('intro', 'ase', () =>
      this.props.navigation.navigate('Auth')
    );
  };

  _onDone = async () => {
    // User finished the introduction. Show real app through
    // navigation or simply by controlling state
    // this.setState({ showRealApp: true });
    await AsyncStorage.setItem('intro', 'ase', () =>
      this.props.navigation.navigate('Auth')
    );
  };
  render() {
    const bg = { backgroundColor: 'rgb(66, 134, 244)' };
    if (this.state.showRealApp) {
      return <Text>fhfsjfgdjh</Text>;
    } else {
      return (
        <AppIntroSlider
          slides={slides}
          renderDoneButton={this._renderDoneButton}
          renderNextButton={this._renderNextButton}
          onDone={this._onDone}
          activeDotStyle={bg}
          renderSkipButton={this._renderSkipButton}
          showSkipButton={true}
          onSkip={this._onSkip}
        />
      );
    }
  }
}
