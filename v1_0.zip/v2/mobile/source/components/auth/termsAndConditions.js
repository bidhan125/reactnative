import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  ScrollView,
  View,
  Dimensions
} from 'react-native';
import Header from '../common/header';

const displayWidth = Dimensions.get('window').width;

export default class TermsAndConditions extends Component {
  render() {
    return (
      <View style={styles.container}>
        <Header
          text='Terms and Conditions'
          iconLeft='arrowleft'
          navigation={this.props.navigation}
        />

        <ScrollView
          style={styles.scrollingView}
          contentContainerStyle={{
            justifyContent: 'flex-start',
            alignItems: 'flex-start'
          }}
        >
          <View height={20} />
          <View>
            {/* <Text style={styles.titleText}>Virgin Hyperloop One</Text> */}
            <Text style={styles.text}>
              This agreement contains warranty disclaimers and other provisions
              that limit the author’s liability to you. Please read these terms
              and conditions carefully and in their entirety, as using,
              accessing and/or browsing the site constitutes acceptance of these
              terms and conditions. If you do not agree to be bound to each and
              every term and condition set forth herein, please exit the site
              immediately and do not use, access and/or browse the site. By
              entering the site, you acknowledge and agree that you have read
              and understand these terms and conditions, that the provisions,
              disclosures and disclaimers set forth herein are fair and
              reasonable, and that your agreement to follow and be bound by
              these terms and conditions is voluntary and is not the result of
              fraud, duress or undue influence exercised upon you by any person
              or entity.
            </Text>
          </View>

          <View>
            <Text style={styles.titleText}>Medical advice disclaimer </Text>
            <Text style={styles.text}>
              The author provides the site and the services, information,
              content and/or data (collectively, “information”) contained
              therein for informational purposes only. The author does not
              provide any medical advice on the site, and the information should
              not be so construed or used. Using, accessing and/or browsing the
              site and/or providing personal or medical information to the
              author does not create a physician-patient relationship between
              you and the author. Nothing contained in the site is intended to
              create a physician-patient relationship, to replace the services
              of a licensed, trained physician or health professional or to be a
              substitute for medical advice of a physician or trained health
              professional licensed in your state. You should not rely on
              anything contained in the site, and you should consult a physician
              licensed in your state in all matters relating to your health. You
              hereby agree that you shall not make any health or medical related
              decision based in whole or in part on anything contained in the
              site.
            </Text>
          </View>

          <View>
            <Text style={styles.titleText}>
              Financial, legal and other advice disclaimer{' '}
            </Text>
            <Text style={styles.text}>
              You hereby acknowledge that nothing contained in the site shall
              constitute financial, investment, legal and/or other professional
              advice and that no professional relationship of any kind is
              created between you and the author. You hereby agree that you
              shall not make any financial, investment, legal and/or other
              decision based in whole or in part on anything contained in the
              site.
            </Text>
          </View>

          <View>
            <Text style={styles.titleText}>Information disclaimer</Text>
            <Text style={styles.text}>
              The opinions expressed in the site are not necessarily the
              opinions of the author and do not necessarily reflect the opinion
              of his employer(s). The site is created by the author in the
              author’s individual capacity, is the author’s personal web site,
              is not edited by the author’s employer(s) and, as a result, may
              not be attributed to the author’s employer. Any opinions of the
              author on the site are or have been rendered based on specific
              facts, under certain conditions, and subject to certain
              assumptions, and may not and should not be used or relied upon for
              any other purpose, including, but not limited to, for use in or in
              connection with any legal proceeding. The information may be
              changed without notice and is not guaranteed to be complete,
              correct, timely, current or up-to-date. Similar to any printed
              materials, the information may become out-of-date. The author
              undertakes no obligation to update any information on the site;
              provided, however, that the author may update the information at
              any time without notice in the author’s sole and absolute
              discretion. The author reserves the right to make alterations or
              deletions to the information at any time without notice.
            </Text>
          </View>

          <View>
            <Text style={styles.titleText}>Posting guidelines</Text>
            <Text style={styles.text}>
              The site is open to the public. Therefore, consider your comments
              carefully and do not include anything in a comment that you would
              like to keep private. By uploading or otherwise making available
              any information to the author in the form of user generated
              comments or otherwise, you grant the author the unlimited,
              perpetual right to distribute, display, publish, reproduce, reuse
              and copy the information contained therein. You are responsible
              for the content you post. You may not impersonate any other person
              through the site. You may not post content that is obscene,
              defamatory, threatening, fraudulent, invasive of another person’s
              privacy rights, or is otherwise unlawful. You may not post content
              that infringes the intellectual property rights of any other
              person or entity. You may not post any content that contains any
              computer viruses or any other code designed to disrupt, damage, or
              limit the functioning of any computer software or hardware. By
              submitting or posting content on the site, you grant the author
              and any company substantially under the control of the author, the
              right to remove any content or comment that, in author’s sole
              judgment, does not comply with the terms and conditions of this
              agreement or is otherwise objectionable. You also grant the author
              and any company substantially under the control of author the
              right to modify, adapt, and edit any content.
            </Text>
          </View>

          <View>
            <Text style={styles.titleText}>
              Third party links and advertisements disclaimer
            </Text>
            <Text style={styles.text}>
              The site may, from time to time, contain links to third party web
              sites. These links are provided solely as a convenience to you and
              not as a guarantee, warranty, or recommendation by the author of
              the services, information, content and/or data on such third party
              web sites or as an indication of any affiliation, sponsorship or
              endorsement of such third party web sites. The author is not
              responsible for the content of linked third party web sites and
              does not make any representations or warranties regarding the
              privacy practices of, or the content or accuracy of materials on,
              such third party websites. If you decide to access linked
              third-party web sites, you do so at your own risk. Your use of
              third-party websites is subject to the terms of use for such
              sites.
            </Text>
            <Text style={styles.text}>
              The inclusion of third party advertisements does not constitute an
              endorsement, guarantee, warranty, or recommendation of, and the
              author makes no representations and/or warranties about, any
              product or service contained therein.
            </Text>
          </View>

          <View>
            <Text style={styles.titleText}>
              Reservation of intellectual property rights
            </Text>
            <Text style={styles.text}>
              The site is protected by united states copyright laws. The author
              hereby reserves any and all intellectual property rights in the
              site.
            </Text>
          </View>

          <View>
            <Text style={styles.titleText}>Age restriction</Text>
            <Text style={styles.text}>
              The site is intended for persons eighteen (18) years or older.
              Persons under the age of eighteen (18) should not access, use
              and/or browse the site.
            </Text>
          </View>

          <View>
            <Text style={styles.titleText}>Invalidity</Text>
            <Text style={styles.text}>
              If any provision of this agreement is held to be invalid or
              unenforceable in whole or in part in any jurisdiction, then that
              provision shall be deemed ineffective in such jurisdiction but
              shall have no effect on the enforceability of the remaining
              provisions.
            </Text>
          </View>

          <View>
            <Text style={styles.titleText}>Entire agreement</Text>
            <Text style={styles.text}>
              You hereby acknowledge that this agreement represents the entire
              understanding between you and the author concerning your use of
              the site and the information contained therein.
            </Text>
            <Text style={styles.text}>
              The site and the information contained therein is made available
              by the author for educational purposes only and is not intended to
              provide medical advice. By accessing the site, you understand and
              acknowledge that there is no physician-patient relationship
              between you and the author. You further acknowledge your
              understanding that the site should not be used as a substitute for
              competent medical advice from a licensed physician in your state
            </Text>
          </View>
        </ScrollView>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'flex-start',
    alignItems: 'center',
    backgroundColor: '#ffffff'
  },
  scrollingView: {
    flexDirection: 'column',
    flex: 0.85,
    paddingHorizontal: 20
  },

  titleText: {
    paddingBottom: 10,
    fontSize: 15,
    fontWeight: 'bold'
  },

  text: {
    paddingBottom: 20,
    fontSize: 15,
    textAlign: 'justify'
  }
});
