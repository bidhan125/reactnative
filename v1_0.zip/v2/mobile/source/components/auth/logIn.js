import React, { Component } from 'react';
import {
  AsyncStorage,
  StyleSheet,
  Text,
  View,
  Dimensions,
  Image,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  ScrollView,
  Platform,
  ToastAndroid
} from 'react-native';
import NavButton from '../common/navigationButton';
import Meteor from 'react-native-meteor';
import SnackBar from 'react-native-snackbar-component';

import { moderateScale } from '../../constants/const_functions';

export default class logIn extends Component {
  constructor(props) {
    super(props);
    this.state = {
      phone: '',
      password: '',
      showSnack: true
    };
  }

  handleLogin() {
    const { phone, password } = this.state;

    console.log(phone, password);

    Meteor.loginWithPassword(phone, password, err => {
      console.log(err);
      if (!err) {
        const user = Meteor.user();
        if (user && !user.profile.isVerified) {
          this.props.navigation.navigate('OTP', {
            phone: phone,
            password: password
          });
          Meteor.call('sendAccountVerificationCode', phone, (err, res) => {
            console.log(err, res);
            if (err) {
              console.log(err);
            } else {
              alert('Please check sms on your phone!');
            }
          });
          ToastAndroid.show(
            `Please verify your phone number to activate your account!`,
            ToastAndroid.SHORT
          );
          this.setState({ signInPressed: false, isLoading: false });
        } else {
          AsyncStorage.setItem('user', JSON.stringify(Meteor.user()), () =>
            !Meteor.user().profile.height ||
            !Meteor.user().profile.weight ||
            !Meteor.user().profile.bloodGroup
              ? this.props.navigation.navigate('ProfileUpdate', {
                  profile: Meteor.user().profile,
                  isNavigationReset: true,
                  id: Meteor.userId()
                })
              : this.props.navigation.navigate('App')
          );
        }
      } else {
        alert('Sorry! Wrong phone number or password');
      }
    });
  }

  handleSnack() {
    this.setState({ showSnack: false }, () => {
      console.log('hello');
    });
  }

  render() {
    const { width, height } = Dimensions.get('window');

    return (
      <KeyboardAvoidingView style={styles.container}>
        <ScrollView style={{ width: '100%' }}>
          <View style={styles.logoStyle} height={height * 0.33}>
            <Image
              source={require('../../assets/LabaidLogo.png')}
              style={{ width: 140, height: 100 }}
            />
          </View>

          <View
            style={styles.inputStyle}
            behavior='position'
            height={height * 0.25}
          >
            <TextInput
              onChangeText={phone => this.setState({ phone })}
              phone={this.state.phone}
              borderBottomWidth={1}
              placeholder='Phone Number'
              returnKeyType='next'
              width={'85%'}
              keyboardType='phone-pad'
              style={{ fontSize: moderateScale(15), paddingBottom: 8 }}
              onSubmitEditing={() => this.refs.password.focus()}
            />

            <TextInput
              onChangeText={password => this.setState({ password })}
              ref='password'
              password={this.state.password}
              borderBottomWidth={1}
              placeholder='Password'
              returnKeyType='done'
              secureTextEntry={true}
              width={'85%'}
              keyboardType='default'
              style={{ fontSize: moderateScale(15), paddingBottom: 8 }}
              onSubmitEditing={() => this.handleLogin()}
            />
          </View>

          <View style={styles.buttonStyle} height={height * 0.15}>
            <NavButton
              buttonText={'Login'}
              buttonLength={'85%'}
              buttonFont={moderateScale(17)}
              navigation={this.props.navigation}
              nav='App'
              onPressFunc={this.handleLogin.bind(this)}
            />
          </View>

          <View style={styles.textStyle} height={height * 0.06}>
            <View style={{ flexDirection: 'row', width: '85%' }}>
              <TouchableOpacity
                style={{ alignItem: 'flex-start', flex: 0.5 }}
                onPress={() => this.props.navigation.navigate('ForgotPass')}
              >
                <Text style={{ color: '#1285ff', fontSize: moderateScale(13) }}>
                  Forgot Password?
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={{ alignItems: 'flex-end', flex: 0.5 }}
                onPress={() => {
                  this.props.navigation.navigate('SignUp');
                }}
              >
                <Text style={{ color: 'purple', fontSize: moderateScale(13) }}>
                  Create New Account
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
        <SnackBar
          visible={
            this.state.showSnack && this.props.navigation.getParam('showSnack')
          }
          textMessage='You have signed up successfully!'
          actionHandler={() => {
            this.handleSnack();
          }}
          actionText='Ok'
          position='bottom'
        />
      </KeyboardAvoidingView>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center'
  },
  logoStyle: {
    marginTop: 30,
    justifyContent: 'center',
    alignItems: 'center'
  },
  inputStyle: {
    width: '100%',
    alignItems: 'center',
    justifyContent: 'space-evenly'
  },
  buttonStyle: {
    alignItems: 'center',
    justifyContent: 'center'
  },
  textStyle: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%'
  }
});
