import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Dimensions,
  Image,
  TextInput,
  Picker,
  CheckBox,
  TouchableOpacity,
  Keyboard,
  KeyboardAvoidingView,
  ScrollView,
  ToastAndroid,
  Platform
} from 'react-native';

import DatePicker from 'react-native-datepicker';
import { CheckBox as CheckBoxEl, Icon } from 'react-native-elements';

import NavButton from '../common/navigationButton';
import {
  Item as FormItem,
  Item,
  Input,
  Label,
  Container,
  Picker as PickerNative,
  Icon as IconNative
} from 'native-base';
import Meteor from 'react-native-meteor';

import { validation, moderateScale } from '../../constants/const_functions';

export default class signUp extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: undefined,
      password: undefined,
      date: undefined,
      gender: undefined,
      agreed: false
    };
    this.inputs = {};
    this.focusNextField = this.focusNextField.bind(this);
  }
  focusNextField(id) {
    this.inputs[id].wrappedInstance.focus();
  }

  handleSubmit() {
    const {
      name,
      phone,
      password,
      password1,
      date,
      gender,
      agreed
    } = this.state;

    console.log(this.state);

    if (validation(name, 'isName') !== true) {
      return;
    }

    if (validation(password, 'isPassword') !== true) {
      return;
    }

    if (validation(phone, 'isPhone') !== true) return;

    if (!agreed) {
      alert(
        'You need to agree with the Terms and Conditions to create an account'
      );
      return;
    }

    if (password != password1) {
      alert("Sorry! Passwords don't match. ");
      return;
    }

    if (date === undefined) {
      alert('Please give valid a valid date of birth');
      return;
    }

    const dob = date;
    console.log({ phone, password, name, gender, dob });

    Meteor.call(
      'create.appUser',
      { phone, password, name, gender, dob },
      (err, res) => {
        console.log(err, res);
        if (err) {
          alert('Sorry! Phone number already exists!');
        } else {
          Meteor.call('sendAccountVerificationCode', phone, (err, res) => {
            console.log(err, res);
            if (err) {
              console.log(err);
              this.setState({ isLoading: false });
            } else {
              this.setState({ isLoading: false });
              this.props.navigation.navigate('OTP', {
                phone: phone,
                password: password
              });
              ToastAndroid.show(
                `Welcome ${name}! Please verify phone no!`,
                ToastAndroid.LONG
              );
            }
          });
        }
      }
    );
  }

  render() {
    const { height, width } = Dimensions.get('window');

    const {
      name,
      phone,
      password,
      password1,
      date,
      gender,
      agreed
    } = this.state;
    return (
      <ScrollView>
        <KeyboardAvoidingView style={styles.avoidView}>
          <View style={styles.logoStyle} height={height * 0.24}>
            <Image
              source={require('../../assets/LabaidLogo.png')}
              style={{ width: 140, height: 98 }}
            />
          </View>

          <View
            style={{
              height: height * 0.27,
              justifyContent: 'space-evenly',
              marginTop: 20
            }}
          >
            <TextInput
              onChangeText={name => this.setState({ name })}
              name={this.state.name}
              borderBottomWidth={1}
              placeholder='Full Name'
              width={moderateScale(300)}
              keyboardType='default'
              returnKeyType='next'
              style={{ fontSize: moderateScale(14), paddingBottom: 8 }}
              onSubmitEditing={() => this.refs.phone.focus()}
            />

            <TextInput
              onChangeText={phone => this.setState({ phone })}
              ref='phone'
              phone={this.state.phone}
              borderBottomWidth={1}
              placeholder='Phone Number'
              width={moderateScale(300)}
              keyboardType='phone-pad'
              returnKeyType='next'
              style={{ fontSize: moderateScale(14), paddingBottom: 8 }}
              onSubmitEditing={() => this.refs.password.focus()}
            />

            <View style={styles.dualFormStyle}>
              <TextInput
                onChangeText={password => this.setState({ password })}
                ref='password'
                password={this.state.password1}
                borderBottomWidth={1}
                placeholder='Password'
                secureTextEntry={true}
                width={moderateScale(150)}
                keyboardType='default'
                returnKeyType='next'
                style={{
                  fontSize: moderateScale(14),
                  flex: 0.5,
                  marginRight: 8,
                  paddingBottom: 8
                }}
                onSubmitEditing={() => this.refs.password1.focus()}
              />
              <TextInput
                onChangeText={password1 => this.setState({ password1 })}
                ref='password1'
                password={this.state.password1}
                borderBottomWidth={1}
                placeholder='Confirm Password'
                secureTextEntry={true}
                width={moderateScale(150)}
                keyboardType='default'
                returnKeyType='done'
                style={{
                  fontSize: moderateScale(14),
                  flex: 0.5,
                  paddingBottom: 8
                }}
                // onSubmitEditing={() => this.focusNextField('five')}
              />
            </View>
          </View>

          <View style={styles.dobStyle} height={height * 0.08}>
            <Text style={styles.appointmentCalendarText}>Date of Birth:</Text>

            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <DatePicker
                date={this.state.date}
                mode='date'
                format='YYYY-MM-DD'
                placeholder='Select date'
                maxDate={new Date()}
                onDateChange={date => {
                  this.setState({ date: date });
                }}
                iconComponent={<Icon name='calendar' type='antdesign' />}
                customStyles={{
                  dateIcon: {},

                  dateInput: {
                    borderWidth: 0
                  }
                }}
              />
            </View>
          </View>

          <View style={styles.genderStyle} height={height * 0.07}>
            <Label style={{ fontSize: moderateScale(14), color: '#464646' }}>
              Select Gender:
            </Label>
            <View style={{ flex: 0.75, justifyContent: 'flex-end' }}>
              {(Platform.OS === 'android' && (
                <Picker
                  selectedValue={gender}
                  mode='dropdown'
                  onValueChange={(itemValue, itemIndex) =>
                    this.setState({ gender: itemValue })
                  }
                >
                  <Picker.Item label='Gender' value={undefined} />
                  <Picker.Item label='Male' value='Male' />
                  <Picker.Item label='Female' value='Female' />
                </Picker>
              )) || (
                <PickerNative
                  selectedValue={gender}
                  mode='dropdown'
                  iosIcon={<IconNative name='arrow-down' />}
                  onValueChange={(itemValue, itemIndex) =>
                    this.setState({ gender: itemValue })
                  }
                >
                  <PickerNative.Item label='Gender' value={undefined} />
                  <PickerNative.Item label='Male' value='Male' />
                  <PickerNative.Item label='Female' value='Female' />
                </PickerNative>
              )}
            </View>
          </View>

          <View style={styles.termsAndConditionsStyle} height={height * 0.08}>
            {/* <CheckBox
              value={agreed}
              onChange={() => {
                this.setState({ agreed: !agreed });
              }}
            /> */}
            <CheckBoxEl
              checked={agreed}
              onPress={() => {
                this.setState({ agreed: !agreed });
              }}
              containerStyle={{ padding: 0 }}
            />
            <Text style={{ fontStyle: 'italic' }}>I Agree to All the </Text>
            <TouchableOpacity
              onPress={() =>
                this.props.navigation.navigate('TermsAndConditions')
              }
            >
              <Text style={{ fontStyle: 'italic', fontWeight: 'bold' }}>
                Terms and Conditions
              </Text>
            </TouchableOpacity>
          </View>

          <View style={styles.buttonStyle} height={height * 0.12}>
            <NavButton
              buttonText={'Sign Up'}
              buttonLength={moderateScale(300)}
              buttonFont={22}
              nav='Home'
              onPressFunc={this.handleSubmit.bind(this)}
            />
          </View>
        </KeyboardAvoidingView>
      </ScrollView>
    );
  }
}

var styles = StyleSheet.create({
  avoidView: {
    backgroundColor: '#ffffff',
    alignItems: 'center',
    flex: 1
  },
  appointmentCalendarText: {
    color: '#464646',
    fontSize: moderateScale(14),
    margin: 0
  },
  itemShortDoB: {
    width: 40,
    height: 40,
    backgroundColor: 'transparent',
    borderColor: '#FFF',
    marginLeft: 0
  },
  dualFormStyle: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  logoStyle: {
    justifyContent: 'flex-end',
    alignItems: 'center'
  },
  genderStyle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: moderateScale(300)
  },
  dobStyle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: moderateScale(300)
  },
  termsAndConditionsStyle: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center'
  },
  buttonStyle: {
    justifyContent: 'flex-start',
    alignItems: 'center'
  }
});
