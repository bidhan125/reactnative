import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Dimensions,
  Image,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  ScrollView,
  AsyncStorage
} from 'react-native';

import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import NavButton from '../common/navigationButton';
import Meteor from 'react-native-meteor';

export default class OTP extends Component {
  constructor(props) {
    super(props);
    this.state = {
      phone: this.props.navigation.getParam('phone'),
      password: this.props.navigation.getParam('password')
    };
  }

  handleActivate() {
    const PhoneNumberPattern = /01\d{9}$/;

    const { phone, code, password } = this.state;

    if (phone === null) {
      alert('Error! Contact No. is Required!');
      return;
    } else if (code === null) {
      alert('Error! Activation Key is Required!');
      return;
    } else if (!PhoneNumberPattern.test(phone)) {
      alert('Your Contact No. is not valid!');
      return;
    }

    this.setState({ isLoading: true });

    Meteor.call('verifyAccount', { phone, code }, (error, result) => {
      console.log(error, result);
      if (result) {
        console.log(result);
        this.setState({ isLoading: false });
        Meteor.loginWithPassword(phone, password, err => {
          console.log(err);
          if (!err) {
            const user = Meteor.user();
            AsyncStorage.setItem('user', JSON.stringify(Meteor.user()), () =>
              !Meteor.user().profile.height ||
              !Meteor.user().profile.weight ||
              !Meteor.user().profile.bloodGroup
                ? this.props.navigation.navigate('ProfileUpdate', {
                    profile: Meteor.user().profile,
                    isNavigationReset: true,
                    id: Meteor.userId()
                  })
                : this.props.navigation.navigate('App')
            );
          } else {
            alert('Sorry! Wrong phone number or password');
          }
        });
      } else {
        console.log('error', error);
        alert('Wrong Phone Number or Activation Code, Please contact support.');
        this.setState({ isLoading: false });
      }
    });
  }

  sendActivationCode() {
    const phone = this.state.phone;
    const PhoneNumberPattern = /01\d{9}$/;

    if (phone === undefined || !PhoneNumberPattern.test(phone)) {
      alert('Please enter the contact no and try again');
      return;
    }
    Meteor.call('sendAccountVerificationCode', phone, (err, res) => {
      console.log(err, res);
      if (err) {
        console.log(err);
        alert(err.message);
      } else {
        alert(res);
      }
    });
  }

  render() {
    return (
      <ScrollView>
        <KeyboardAvoidingView style={styles.container}>
          <View style={styles.logoStyle}>
            <Image
              source={require('../../assets/logo.png')}
              style={{ width: 135, height: 95 }}
            />
          </View>
          {/* <View style={styles.textStyle}>
          <Text style={{ fontSize: 20 }}>Enter the verification code</Text>
        </View> */}
          <View style={styles.inputStyle}>
            <TextInput
              onChangeText={phone => this.setState({ phone })}
              placeholder='Enter phone no.'
              value={this.state.phone}
              editable
              borderBottomWidth={1}
              width='100%'
              returnKeyType='next'
              style={{height: 50, padding: 10, marginTop: 50}}
            />
            <TextInput
              editable
              placeholder='Enter verification code'
              onChangeText={code => this.setState({ code })}
              value={this.state.text}
              borderBottomWidth={1}
              width='100%'
              style={{height: 50, padding: 10, marginTop: 10, marginBottom: 30}}
              onSubmitEditing={() => this.handleActivate()}
            />
          </View>
          <View style={styles.buttonView}>
            <NavButton
              buttonText='Submit'
              buttonLength={140}
              buttonFont={22}
              navigation={this.props.navigation}
              nav='Home'
              onPressFunc={this.handleActivate.bind(this)}
            />
          </View>
          <View style={styles.textStyle}>
            <Text>A 4 digit code is sent to your mobile</Text>
          </View>
          <View style={styles.textStyle}>
            <TouchableOpacity
              onPress={() => this.sendActivationCode()}
              style={{ flexDirection: 'row', alignItems: 'center' }}
            >
              <Icon name='message-text' size={24} color='#1285ffb0' />
              <Text
                style={{ fontSize: 18, fontWeight: 'bold', color: '#808080b0' }}
              >
                {' '}
                Resend SMS
              </Text>
            </TouchableOpacity>
          </View>
        </KeyboardAvoidingView>
      </ScrollView>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center'
  },
  logoStyle: {
    // flex: 0.33,
    height: 200,
    justifyContent: 'center',
    alignItems: 'center'
  },
  textStyle: {
    // flex: 0.08,
    margin: 20,
    justifyContent: 'center',
    alignItems: 'center'
  },
  buttonView: {
    // flex: 0.15,
    height: 50,
    margin: 20,
    justifyContent: 'flex-end',
    alignItems: 'center'
  },
  inputStyle: {
    // flex: 0.12,
    justifyContent: 'center',
    alignItems: 'center',
    width: '65%'
  }
});
