import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  TextInput,
  KeyboardAvoidingView,
  ScrollView
} from 'react-native';
import Meteor from 'react-native-meteor';

import NavButton from '../common/navigationButton';
import { verticalScale } from '../../constants/const_functions';

export default class ForgotPass extends Component {
  constructor(props) {
    super(props);
    this.state = {
      text: undefined
    };
  }

  handlePhone() {
    Meteor.call('forgotPasswordRequest', this.state.text, (err, res) => {
      console.log(err, res);
      if (err) {
        console.log(err);
      } else {
        console.log(res);
        alert('A verfication code has been send to your phone!');
        this.props.navigation.navigate('ChangePass', {phone: this.state.text});
      }
    });
  }

  render() {
    return (
      <KeyboardAvoidingView style={styles.container}>
        <ScrollView showsVerticalScrollIndicator={false}>
          <View style={[styles.container, { marginTop: 50 }]}>
            <View style={styles.logoStyle}>
              <Image
                source={require('../../assets/LabaidLogo.png')}
                style={{ width: 135, height: 100 }}
              />
            </View>

            <View style={styles.textStyle}>
              <Text style={{ fontSize: 20, alignSelf: 'flex-start' }}>
                Enter your Phone Number
              </Text>
            </View>

            <View style={styles.inputStyle}>
              <Text style={{ fontSize: 19 }}>+880 </Text>
              <TextInput
                onChangeText={text => this.setState({ text })}
                value={this.state.text}
                borderBottomWidth={1}
                width='100%'
                keyboardType='number-pad'
                style={{ fontSize: 19 }}
                onSubmitEditing={() => this.handlePhone()}
              />
            </View>

            <View style={styles.buttonView}>
              <NavButton
                buttonText='Send Verification Code'
                buttonFont={17}
                buttonLength={250}
                navigation={this.props.navigation}
                nav='ChangePass'
                onPressFunc={this.handlePhone.bind(this)}
              />
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    flex: 1,
    alignItems: 'center'
  },
  logoStyle: {
    flex: 0.33,
    justifyContent: 'center',
    alignItems: 'center',
    height: verticalScale(150)
  },
  textStyle: {
    flex: 0.06,
    justifyContent: 'center',
    alignItems: 'center',
    height: verticalScale(80)
  },
  buttonView: {
    flex: 0.24,
    justifyContent: 'center',
    alignItems: 'center',
    height: verticalScale(80)
  },
  inputStyle: {
    flex: 0.15,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    width: '70%',
    height: verticalScale(80)
  }
});
