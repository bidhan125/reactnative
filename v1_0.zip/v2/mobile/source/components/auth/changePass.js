import React, { Component } from 'react';
import {
  StyleSheet,
  View,
  Dimensions,
  Image,
  KeyboardAvoidingView,
  ScrollView,
  AsyncStorage
} from 'react-native';
import Meteor from 'react-native-meteor';

import { Input } from 'react-native-elements';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import NavButton from '../common/navigationButton';
import { verticalScale, validation } from '../../constants/const_functions';

export default class Empty extends Component {
  constructor(props) {
    super(props);
    this.state = {
      verificationCode: undefined,
      phone: this.props.navigation.getParam('phone'),
      password: undefined,
      password1: undefined
    };
  }

  changePassword() {
    const { verificationCode, phone, password, password1 } = this.state;
    console.log(verificationCode, phone, password);
    const code = verificationCode;
    if (password === password1) {
      if (validation(password, 'isPassword') !== true) {
        return;
      } else {
        Meteor.call(
          'forgotPasswordSubmit',
          { code, phone, password },
          (err, res) => {
            if (err) {
              console.log(err);
            } else {
              console.log('success', res);
              // alert('The passord successfully updated! Please login.');
              // this.props.navigation.navigate('LogIn');
              Meteor.loginWithPassword(phone, password, err => {
                console.log(err);
                if (!err) {
                  const user = Meteor.user();
                  AsyncStorage.setItem(
                    'user',
                    JSON.stringify(Meteor.user()),
                    () =>
                      !Meteor.user().profile.height ||
                      !Meteor.user().profile.weight ||
                      !Meteor.user().profile.bloodGroup
                        ? this.props.navigation.navigate('ProfileUpdate', {
                            profile: Meteor.user().profile,
                            isNavigationReset: true,
                            id: Meteor.userId()
                          })
                        : this.props.navigation.navigate('App')
                  );
                } else {
                  alert('Sorry! Wrong phone number or password');
                }
              });
            }
          }
        );
      }
    } else {
      alert("The password didn't match");
    }
  }

  render() {
    const { w, h } = Dimensions.get('window');

    return (
      <KeyboardAvoidingView style={styles.container}>
        <ScrollView>
          <View style={styles.container}>
            <View style={styles.logoStyle}>
              <Image
                source={require('../../assets/LabaidLogo.png')}
                style={{ width: 132, height: 95 }}
              />
            </View>

            <View style={styles.mainStyle}>
              <Input
                placeholder='Verification Code'
                onChangeText={verificationCode =>
                  this.setState({ verificationCode })
                }
                leftIcon={<Icon name='security' size={24} />}
                inputContainerStyle={{ borderBottomWidth: 0 }}
                containerStyle={{
                  width: '75%',
                  borderWidth: 1,
                  borderColor: 'gray',
                  borderRadius: 8
                }}
                returnKeyType='next'
                onSubmitEditing={() => this.refs.phone.focus()}
              />
              <Input
                ref='phone'
                value={this.state.phone}
                editable
                placeholder='Phone Number'
                onSubmitEditing={() => this.refs.password.focus()}
                onChangeText={phone => this.setState({ phone })}
                leftIcon={<Icon name='phone' size={24} />}
                inputContainerStyle={{ borderBottomWidth: 0 }}
                containerStyle={{
                  width: '75%',
                  borderWidth: 1,
                  borderColor: 'gray',
                  borderRadius: 8
                }}
                returnKeyType='next'
              />
              <Input
                ref='password'
                placeholder='New Password'
                secureTextEntry={true}
                onChangeText={password => this.setState({ password })}
                leftIcon={<Icon name='pencil-lock' size={24} />}
                inputContainerStyle={{ borderBottomWidth: 0 }}
                containerStyle={{
                  width: '75%',
                  borderWidth: 1,
                  borderColor: 'gray',
                  borderRadius: 8
                }}
                onSubmitEditing={() => this.refs.password1.focus()}
                returnKeyType='next'
              />

              <Input
                ref='password1'
                placeholder='Confirm New Password'
                secureTextEntry={true}
                onChangeText={password1 => this.setState({ password1 })}
                leftIcon={
                  <Image
                    source={require('../../assets/customIcons/lock-freepik.png')}
                    style={{ height: 18, width: 18 }}
                  />
                }
                inputContainerStyle={{ borderBottomWidth: 0 }}
                containerStyle={{
                  width: '75%',
                  borderWidth: 1,
                  borderColor: 'gray',
                  borderRadius: 8
                }}
                onSubmitEditing={() => this.changePassword()}
              />
            </View>

            <View style={{ flex: 0.1, alignItems: 'center' }}>
              <NavButton
                buttonText='Sign in'
                buttonLength={'75%'}
                buttonFont={20}
                nav='Home'
                navigation={this.props.navigation}
                onPressFunc={this.changePassword.bind(this)}
              />
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    flex: 1
  },
  logoStyle: {
    flex: 0.33,
    justifyContent: 'center',
    alignItems: 'center',
    height: verticalScale(150)
  },
  mainStyle: {
    flex: 0.5,
    justifyContent: 'space-evenly',
    alignItems: 'center',
    height: verticalScale(230)
  }
});
