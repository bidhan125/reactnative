import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Dimensions,
  ScrollView
} from 'react-native';
import Header from '../common/header';
import CartItem from './cartItem';
import NavButton from '../common/navigationButton';
import { Button } from 'react-native-elements';

import { fetchCartData, moderateScale } from '../../constants/const_functions';

export default class Checkout extends Component {
  constructor(props) {
    super(props);

    this.state = {
      cart: {}
    };

    fetchCartData(this);
  }
  render() {
    const { width, height } = Dimensions.get('window');
    const { cart } = this.state;
    const arrCart = [];
    let totalPrice = 0;
    for (var key in cart) {
      if (cart.hasOwnProperty(key)) {
        arrCart.push({ ...cart[key], id: key });
      }
    }

    return (
      <View style={styles.container}>
        <Header
          text='Checkout'
          iconLeft='arrowleft'
          navigation={this.props.navigation}
        />
        <ScrollView showsVerticalScrollIndicator={false}>
          <View style={{ height: 15, width: '100%' }} />
          <View
            style={styles.headingStyle}
            height={height * 0.1}
            width={width - 20}
          >
            <View style={styles.viewStyle} flex={0.05}>
              <Text style={styles.textStyle}>#</Text>
            </View>
            <View
              style={[
                styles.viewStyle,
                { flex: 0.3, alignItems: 'flex-start' }
              ]}
            >
              <Text style={styles.textStyle}>Name</Text>
            </View>

            <View style={styles.viewStyle} flex={0.2}>
              <Text style={styles.textStyle}>Quantity</Text>
            </View>

            <View style={[styles.viewStyle, { flex: 0.2 }]}>
              <Text style={styles.textStyle}>Unit Price</Text>
            </View>

            <View
              style={[styles.viewStyle, { flex: 0.25, alignItems: 'flex-end' }]}
            >
              <Text style={styles.textStyle}>Sub Total</Text>
            </View>
          </View>

          <View style={{ borderBottomWidth: 2 }}>
            {arrCart.map((item, idx) => {
              totalPrice += item.quantity * item.price;
              return (
                <CartItem
                  serial={idx + 1}
                  name={item.name}
                  quantity={item.quantity}
                  unitPrice={item.price}
                  subTotal={item.quantity * item.price}
                />
              );
            })}
          </View>

          <View
            style={{ flexDirection: 'row', marginTop: 12, width: width - 20 }}
          >
            <View
              style={{
                justifyContent: 'center',
                alignItems: 'flex-end',
                flex: 0.75
              }}
            >
              <Text style={{ fontSize: 18, fontWeight: 'bold' }}>Total :</Text>
            </View>

            <View
              style={{
                justifyContent: 'center',
                alignItems: 'flex-end',
                flex: 0.25
              }}
            >
              <Text style={{ fontSize: 18 }}>{totalPrice.toFixed(2)}/-</Text>
            </View>
          </View>

          <View
            style={{ flexDirection: 'row', marginTop: 8, width: width - 20 }}
          >
            <View
              style={{
                justifyContent: 'flex-end',
                alignItems: 'center',
                flex: 0.75,
                flexDirection: 'row'
              }}
            >
              <Text
                style={{
                  fontSize: 18,
                  fontStyle: 'italic',
                  color: 'green',
                  borderBottomWidth: 1
                }}
              >
                {' '}
                Discount{' '}
              </Text>
            </View>

            <View
              style={{
                justifyContent: 'center',
                alignItems: 'flex-end',
                flex: 0.25,
                borderBottomWidth: 1
              }}
            >
              <Text style={{ fontSize: 16, textAlign: 'right' }}> 0/-</Text>
            </View>
          </View>

          <View
            style={{ flexDirection: 'row', marginTop: 10, width: width - 20 }}
          >
            <View
              style={{
                justifyContent: 'center',
                alignItems: 'flex-end',
                flex: 0.75
              }}
            >
              <Text style={{ fontSize: 16, fontWeight: 'bold' }}>
                {' '}
                Grand Total :
              </Text>
            </View>

            <View
              style={{
                justifyContent: 'center',
                alignItems: 'flex-end',
                flex: 0.25
              }}
            >
              <Text style={{ fontSize: 16 }}>{totalPrice.toFixed(2)}/-</Text>
            </View>
          </View>

          <View
            style={{
              marginTop: 80,
              flex: 1,
              justifyContent: 'center',
              alignItems: 'center',
              marginBottom: 20
            }}
          >
            <Button
              title='Proceed'
              type='solid'
              onPress={() =>
                this.props.navigation.navigate('BillAndShipment', {
                  cart: cart
                })
              }
              containerStyle={{ width: '100%' }}
              buttonStyle={{ backgroundColor: '#60BB46' }}
              titleStyle={{ fontSize: moderateScale(16) }}
            />
          </View>
        </ScrollView>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    flex: 1,
    alignItems: 'center'
  },
  headingStyle: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    borderBottomWidth: 1
  },
  viewStyle: {
    justifyContent: 'center',
    // alignItems: 'center',
    height: '100%'
  },
  textStyle: {
    fontSize: 15,
    fontWeight: 'bold'
  }
});
