import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Dimensions,
  Image,
  TouchableOpacity
} from 'react-native';

import Icon from 'react-native-vector-icons/AntDesign';
import { Button, Icon as IconEl } from 'react-native-elements';
import { moderateScale } from '../../constants/const_functions';

//props: medicineName,medicineDesc,imgComponentAsProp

export default class CartViewField extends Component {
  render() {
    const displayWidth = Dimensions.get('window').width;
    const displayHeight = Dimensions.get('window').height;
    let fieldHeight = moderateScale(80);
    let imageDiameter = moderateScale(60);
    // console.log(this.props.children);

    return (
      <View
        style={styles.container}
        height={fieldHeight}
        width={displayWidth * 0.94}
      >
        <View style={styles.smallView} alignItems='center'>
          <View
            style={styles.imageViewStyle}
            width={imageDiameter}
            height={imageDiameter}
          >
            {this.props.imgComponentAsProp}
          </View>
        </View>

        <View style={styles.textView}>
          <View
            style={{
              flex: 0.5,
              justifyContent: 'center',
              alignItems: 'flex-start'
            }}
          >
            <Text style={{ fontSize: moderateScale(15), fontWeight: 'bold' }}>
              {this.props.medicineName}
            </Text>
          </View>

          <View
            style={{
              flex: 0.5,
              justifyContent: 'flex-start',
              alignItems: 'flex-start'
            }}
          >
            <Text style={{ fontSize: moderateScale(12) }}>
              {this.props.medicineDesc}
            </Text>
          </View>
        </View>

        <View
          style={{
            flex: 0.46,
            flexDirection: 'row',
            alignItems: 'center'
          }}
        >
          <View
            style={{
              flex: 7,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between'
            }}
          >
            <Button
              onPress={() => this.props.reduceQuantity(this.props.id)}
              containerStyle={{ width: moderateScale(40) }}
              type='clear'
              icon={
                <Icon
                  size={moderateScale(18)}
                  name='minuscircleo'
                  type='antdesign'
                />
              }
            />
            <Text style={{ fontSize: moderateScale(14) }}>
              {this.props.quantity && this.props.quantity.toString()}
            </Text>
            <Button
              onPress={() => this.props.addQuantity(this.props.id)}
              containerStyle={{ width: moderateScale(40) }}
              type='clear'
              icon={
                <Icon
                  size={moderateScale(18)}
                  name='pluscircleo'
                  type='antdesign'
                />
              }
            />
          </View>
          <View style={{ flex: 3 }}>
            <IconEl
              name='trash-o'
              type='font-awesome'
              color='red'
              onPress={() => this.props.removeItemFromCart(this.props.id)}
            />
          </View>
        </View>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    elevation: 1.5,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    borderRadius: 15,
    marginTop: moderateScale(5),
    marginLeft: moderateScale(10),
    marginRight: moderateScale(10),
    marginBottom: moderateScale(5),
    shadowOffset: { width: 3, height: 3 },
    shadowColor: 'grey',
    shadowOpacity: 0.25,
    shadowRadius: 5
  },
  smallView: {
    flex: 0.2,
    justifyContent: 'center',
    flexDirection: 'row'
  },
  imageViewStyle: {
    backgroundColor: '#ffffff',
    borderRadius: 200,
    justifyContent: 'center',
    alignItems: 'center'
  },
  textView: {
    flex: 0.52,
    justifyContent: 'center',
    alignItems: 'flex-start'
  }
});
