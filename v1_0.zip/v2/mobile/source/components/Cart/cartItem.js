import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, Dimensions } from 'react-native';
import { moderateScale } from '../../constants/const_functions';

export default class CartItem extends Component {
  render() {
    const { width, height } = Dimensions.get('window');

    return (
      <View style={styles.container} height={height * 0.08} width={width - 20}>
        <View style={[styles.viewStyle, {flex: 0.05, alignItems: 'flex-start'}]}>
          <Text style={styles.textStyle}>{this.props.serial}</Text>
        </View>

        <View style={[styles.viewStyle, { flex: 0.3, alignItems: 'flex-start' }]}>
          <Text style={styles.textStyle}>{this.props.name}</Text>
        </View>

        <View style={styles.viewStyle} flex={0.2}>
          <Text style={styles.textStyle}>{this.props.quantity}</Text>
        </View>

        <View style={styles.viewStyle} flex={0.2}>
          <Text style={styles.textStyle}>{this.props.unitPrice}</Text>
        </View>

        <View
          style={[styles.viewStyle, { flex: 0.25, alignItems: 'flex-end' }]}
        >
          <Text style={styles.textStyle}>{this.props.subTotal.toFixed(2)}</Text>
        </View>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    flexDirection: 'row',
    justifyContent: 'flex-start',
    borderBottomWidth: 1,
    borderColor: '#80808044'
  },
  viewStyle: {
    justifyContent: 'center',
    alignItems: 'center',
    height: '100%'
  },
  textStyle: {
    fontSize: moderateScale(15)
  }
});
