import React, { Component } from 'react';
import { View, Text } from 'react-native';

import Meteor from 'react-native-meteor';
import { WebView } from 'react-native-webview';

import SpinView from '../common/spinner';

export default class PaymentGateway extends Component {
  constructor(props) {
    webview = null;
    super(props);
    this.state = {
      isLoaded: false
    };

    this.generateInvoice();
  }

  generateInvoice() {
    const navigation = this.props.navigation;
    const orderId = navigation.getParam('orderId');
    const order = navigation.getParam('order');
    const product = navigation.getParam('product');
    const billing = navigation.getParam('billing');
    console.log('Generate invoce method');

    console.log(order, product, billing);

    Meteor.call(
      'generateInvoice',
      { order: order, product: product, billing: billing },
      (err, res) => {
        console.log(err, res);
        if (err) {
          console.log(err);
        } else {
          this.setState({ uri: res.url, invId: res.invId });
          Meteor.call(
            'addInvoiceOrder',
            { orderId, invId: res.invId },
            (err, res) => {
              console.log(err, res);
              if (err) {
                console.log(err);
              } else {
                this.setState({ isLoaded: true });
              }
            }
          );
        }
      }
    );
  }

  async updatePaymentStatus() {
    const orderId = this.props.navigation.getParam('orderId');
    console.log(orderId, this.state.invId)
    Meteor.call(
      'updateOrderPaymentStatus',
      { orderId, invId: this.state.invId },
      (err, res) => {
        console.log(err, res);
      }
    );
  }

  render() {
    const { isLoaded, uri } = this.state;

    if (!isLoaded) {
      return <SpinView />;
    }

    return (
      <WebView
        ref={ref => (this.webview = ref)}
        source={{ uri: uri }}
        onNavigationStateChange={this.handleWebViewNavigationStateChange}
        textZoom={150}
      />
    );
  }

  handleWebViewNavigationStateChange = newNavState => {
    // newNavState looks something like this:
    // {
    //   url?: string;
    //   title?: string;
    //   loading?: boolean;
    //   canGoBack?: boolean;
    //   canGoForward?: boolean;
    // }
    const { url } = newNavState;
    if (!url) return;
    console.log(url)

    if (url.includes('/otp.php')) {
      console.log(url,'zoom.....')
      // this.webview.props.textZoom=300
    }

    if (url.includes('google.com')) {
      this.updatePaymentStatus();
      this.props.navigation.navigate('Home');
    }

    // handle certain doctypes
    // if (url.includes('.pdf')) {
    //   this.webview.stopLoading();
    // open a modal with the PDF viewer
    // }

    // one way to handle a successful form submit is via query strings
    // if (url.includes('?message=success')) {
    //   this.webview.stopLoading();
    // maybe close this view?
    // }

    // one way to handle errors is via query string
    // if (url.includes('?errors=true')) {
    //   this.webview.stopLoading();
    // }

    // redirect somewhere else
    // if (url.includes('google.com')) {
    //   const newURL = 'https://facebook.github.io/react-native/';
    //   const redirectTo = 'window.location = "' + newURL + '"';
    //   this.webview.injectJavaScript(redirectTo);
    // }
  };
}
