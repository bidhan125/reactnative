import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Dimensions,
  PixelRatio,
  ScrollView,
  Image,
  KeyboardAvoidingView,
  TouchableOpacity,
  Alert,
  Picker
} from 'react-native';

import { Picker as PickerNative, Icon as IconNative } from 'native-base';
import Header from '../common/header';
import { Button, Icon, CheckBox } from 'react-native-elements';
import { TextInput } from 'react-native-gesture-handler';
import DatePicker from 'react-native-datepicker';
import Meteor from 'react-native-meteor';
import { RNS3 } from 'react-native-aws3';
import ImagePicker from 'react-native-image-picker';
import SnackBar from 'react-native-snackbar-component';
import { WebView } from 'react-native-webview';

import { optionsS3 } from '../../configs/AppConfig';
import PaymentModal from '../Modal/paymentModal';
import SpinView from '../common/spinner';

import {
  scale,
  verticalScale,
  moderateScale,
  getUserAsync,
  updateCart
} from '../../constants/const_functions';
import { districtList } from '../../constants/const_strings';
// import RNRearCameraCharacteristicsDisplayMetrics from 'react-native-rear-camera-characteristics-display-metrics';

export default class BillAndShipment extends Component {
  constructor(props) {
    super(props);
    this.state = {
      cart: this.props.navigation.getParam('cart'),
      userId: undefined,
      address: '',
      instruction: '',
      date: new Date(),
      phone: undefined,
      pressStatus: [false, false, false, true, false, false],
      name: undefined,
      branchList: [],
      chosenValueCity: undefined,
      chosenValueBranch: undefined,
      isPaymentModalVisible: false,
      deliverType: undefined,
      processing: false,
      avatarSource: undefined,
      prescriptions: [],
      imageNameList: [],
      imageName: undefined,
      webviewVisible: false
    };
    console.log(this.state.cart);
    this.fetchUser();
    this.fetchBranchNSpecialities();
  }

  async fetchUser() {
    const user = JSON.parse(await getUserAsync());
    console.log(user);
    this.setState({
      userId: user._id,
      profile: user.profile,
      phone: user.profile.phone,
      name: user.profile.name,
      email: user.profile.email
    });
  }

  fetchBranchNSpecialities() {
    Meteor.call('fetchBranchNSpecialities', (err, res) => {
      if (err) console.log(err);
      if (res) {
        this.setState(res, () => {
          console.log('branch_list:', this.state.branchList);
        });
      }
    });
  }

  updateState(obj) {
    this.setState(obj);
  }

  handleSubmit(paymentMethod) {
    var price = 0;
    for (let item in this.state.cart) {
      price +=
        parseInt(this.state.cart[item].price) * this.state.cart[item].quantity;
    }

    const {
      userId,
      cart,
      phone,
      instruction,
      date,
      chosenValueCity,
      name,
      chosenValueBranch,
      deliverType,
      email,
      prescriptions
    } = this.state;

    var medicine = false;
    for (var key in cart) {
      if (cart[key].form) {
        medicine = true;
      }
    }

    const address = this.state.address || this.state.profile.address;

    if (deliverType === undefined) {
      alert('Please select the type of delevery.');
      return;
    } else if (deliverType === 'home') {
      if (
        address === undefined ||
        address.length <= 0 ||
        chosenValueCity === undefined
      ) {
        alert('Please give your address');
        return;
      }
    } else if (deliverType === 'self') {
      this.setState({ address: chosenValueBranch });
      if (chosenValueBranch === undefined) {
        alert('Please select a branch for self pickup.');
        return;
      }
    }

    if (medicine && prescriptions.length <= 0) {
      alert('Please upload prescription!');
      return;
    }

    data = {
      uid: userId,
      cart,
      address,
      phone,
      instruction,
      paymentMethod,
      time: date,
      deliverType,
      district: chosenValueCity,
      name,
      price,
      chosenValueBranch,
      orderType: 'medicine',
      prescriptions: prescriptions
    };

    const order = {
      amount: price,
      currency: 'BDT',
      redirect_url: 'http://google.com'
    };
    const product = {
      name: 'medicine',
      description: 'this is dummy description'
    };
    const billing = {
      customer: {
        name: name,
        email: email,
        phone: phone,
        address: {
          street: address || chosenValueBranch,
          city: chosenValueCity || chosenValueBranch.split(',')[1] || 'Dhaka',
          state: chosenValueCity || chosenValueBranch.split(',')[1] || 'Dhaka',
          zipcode: '1000',
          country: 'BD'
        }
      }
    };

    console.log('Data - ', data);

    this.setState({ processing: true });

    Meteor.call('addOrder', data, (err, res) => {
      console.log(err, res);
      this.setState({ processing: false });
      if (err) {
        alert(
          'Sorry! Failed to submit your request at this moment. Please try again later'
        );
      } else if (res) {
        if (paymentMethod === 'Pay Online') {
          this.props.navigation.navigate('PaymentGateway', {
            orderId: res,
            order: order,
            product: product,
            billing: billing
          });
        } else {
          Alert.alert(
            'Success',
            'Congratulations! Your request has been received successfully! Thank you!',
            [
              {
                text: 'Ok',
                onPress: () => this.props.navigation.navigate('Home')
              }
            ],
            { cancelable: false }
          );
        }
      }
    });

    let emptyCart = {};
    updateCart(emptyCart, this);
  }

  selectPhotoTapped() {
    const options = {
      color: '#464646',
      quality: 1.0,
      maxWidth: 500,
      maxHeight: 500,
      storageOptions: {
        skipBackup: true
      }
    };

    ImagePicker.showImagePicker(options, response => {
      console.log('Response - ', response);

      if (response.didCancel) {
        console.log('User cancelled photo picker');
      } else if (response.error) {
        console.log('ImagePicker Error: ', response.error);
      } else if (response.customButton) {
        console.log('User tapped custom button: ', response.customButton);
      } else {
        const source = { uri: response.uri };
        console.log(source);
        this.setState(
          {
            avatarSource: source,
            imageName: response.fileName
          },
          () => this.handleUpdateProfilePicture()
        );
      }
    });
  }

  handleUpdateProfilePicture() {
    console.log('Update Profile Picture');
    this.setState({ processing: !this.state.processing });
    this.uploadPhoto();
  }

  uploadPhoto() {
    console.log('dfsfs');
    const file = {
      uri: this.state.avatarSource.uri,
      name: this.state.name + Math.random() + 'prescription.png',
      type: 'image/png'
    };
    // console.log(file);
    let temp = this.state.imageNameList;
    temp.push(this.state.imageName);
    let a = this.state.prescriptions;
    RNS3.put(file, optionsS3).then(responseS3 => {
      // console.log('RNS3 put method called...');
      // console.log('response received... ', responseS3);
      if (responseS3.status !== 201) {
        throw new Error('Failed to upload image to S3');
      }
      a.push(responseS3.body.postResponse.location);
      this.setState(
        {
          avatarSource: responseS3.body.postResponse.location,
          prescriptions: a,
          processing: !this.state.processing,
          removeSnack: true,
          imageNameList: temp
        },
        () => {
          setTimeout(() => {
            this.setState({
              removeSnack: false
            });
          }, 1500);
        }
      );
    });
    // .progress((e) => console.log(e.percent));
  }

  render() {
    const { cart } = this.state;

    const distOptions = [];
    districtList.map(item =>
      distOptions.push(<Picker.Item label={item.name} value={item.name} />)
    );

    if (this.state.processing) {
      return <SpinView />;
    }

    var medicine = false;
    for (var key in cart) {
      if (cart[key].form) {
        medicine = true;
      }
    }

    return (
      <View style={styles.container}>
        <SnackBar
          visible={this.state.removeSnack}
          textMessage='Prescription has been uploaded successfully!'
          actionHandler={() => {
            this.setState({ removeSnack: !this.state.removeSnack });
          }}
          actionText='Ok'
          position='bottom'
          autoHidingTime={1000}
        />
        <PaymentModal
          visibilityStateName='isPaymentModalVisible'
          visibility={this.state.isPaymentModalVisible}
          updateState={this.updateState.bind(this)}
          handleSubmit={this.handleSubmit.bind(this)}
        />

        <Header
          text='Billing Address'
          iconLeft='arrowleft'
          navigation={this.props.navigation}
        />
        <ScrollView showsVerticalScrollIndicator={false}>
          <View style={styles.body}>
            <View
              style={{
                flex: 0.2,
                marginTop: moderateScale(15),
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between'
              }}
            >
              <View style={{ flex: 0.4 }}>
                <Text style={styles.text}>Name:</Text>
              </View>
              <View style={{ flex: 0.6 }}>
                <TextInput
                  multiline={false}
                  editable={true}
                  onChangeText={name => this.setState({ name })}
                  value={this.state.name}
                  style={{
                    borderColor: '#bcbdc0',
                    textAlign: 'center',
                    borderBottomWidth: 1
                  }}
                  placeholder='Name'
                />
              </View>
            </View>
            <View
              style={{
                flex: 0.2,
                marginTop: moderateScale(15),
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between'
              }}
            >
              <View style={{ flex: 0.4 }}>
                <Text style={styles.text}>Phone Number:</Text>
              </View>
              <View style={{ flex: 0.6 }}>
                <TextInput
                  multiline={false}
                  editable={true}
                  onChangeText={phone => this.setState({ phone })}
                  value={this.state.phone}
                  style={{
                    borderColor: '#bcbdc0',
                    textAlign: 'center',
                    borderBottomWidth: 1
                  }}
                  placeholder='Phone Number'
                />
              </View>
            </View>
            <View style={styles.delivery}>
              <View style={{ flex: 0.4 }}>
                <Text style={styles.text}>Delivery Date & Time: </Text>
              </View>
              <View
                style={{
                  flex: 0.6,
                  borderBottomWidth: 1,
                  borderBottomColor: '#bcbdc0'
                }}
              >
                <DatePicker
                  style={{ width: '100%' }}
                  date={this.state.date}
                  mode='datetime'
                  placeholder='select date'
                  format='YYYY-MM-DD'
                  minDate={this.state.date}
                  confirmBtnText='Confirm'
                  cancelBtnText='Cancel'
                  showIcon={false}
                  customStyles={{
                    // dateIcon: {
                    //     position: 'absolute',
                    //     left: 0,
                    //     top: 4,
                    //     marginLeft: 0
                    // },
                    dateInput: {
                      marginLeft: 20,
                      borderWidth: 0
                    }
                  }}
                  onDateChange={date => {
                    this.setState({ date: date });
                  }}
                />
              </View>
            </View>
            <View
              style={{
                flex: 0.2,
                flexDirection: 'row',
                justifyContent: 'space-between',
                marginBottom: verticalScale(8),
                marginTop: verticalScale(15)
              }}
            >
              <CheckBox
                title='Self Pickup'
                checked={this.state.deliverType == 'self'}
                containerStyle={styles.checkBoxStyle}
                onPress={() => this.setState({ deliverType: 'self' })}
              />

              <CheckBox
                title='Home Delivery'
                checked={this.state.deliverType == 'home'}
                containerStyle={styles.checkBoxStyle}
                onPress={() => this.setState({ deliverType: 'home' })}
              />
            </View>
            {this.state.deliverType === 'self' && (
              <View
                style={{
                  flex: 0.2,
                  marginBottom: verticalScale(8),
                  marginTop: verticalScale(15)
                }}
              >
                <Text style={styles.text}>Delivery Pickup Point:</Text>
                <View
                  style={{
                    flex: 1,
                    elevation: 1,
                    height: moderateScale(45),
                    borderRadius: 10,
                    backgroundColor: 'white',
                    shadowOffset: { width: 3, height: 3 },
                    shadowColor: 'grey',
                    shadowOpacity: 0.25,
                    shadowRadius: 5
                  }}
                >
                  {(Platform.OS == 'android' && (
                    <Picker
                      style={{ flex: 1 }}
                      selectedValue={this.state.chosenValueBranch}
                      mode='dropdown'
                      onValueChange={(itemValue, itemIndex) =>
                        this.setState({ chosenValueBranch: itemValue })
                      }
                    >
                      <Picker.Item label='Select Branch' value={undefined} />
                      {this.state.branchList.map((branch, sl_no) => {
                        return (
                          <Picker.Item
                            key={sl_no}
                            label={branch.name}
                            value={branch.name}
                          />
                        );
                      })}
                    </Picker>
                  )) || (
                    <PickerNative
                      style={{ width: '100%' }}
                      iosIcon={<IconNative name='arrow-down' />}
                      selectedValue={this.state.chosenValueBranch}
                      mode='dropdown'
                      onValueChange={(itemValue, itemIndex) =>
                        this.setState({ chosenValueBranch: itemValue })
                      }
                    >
                      <PickerNative.Item
                        label='Select Branch'
                        value={undefined}
                      />
                      {this.state.branchList.map((branch, sl_no) => {
                        return (
                          <PickerNative.Item
                            key={sl_no}
                            label={branch.name}
                            value={branch.name}
                          />
                        );
                      })}
                    </PickerNative>
                  )}
                </View>
              </View>
            )}
            {this.state.deliverType === 'home' && (
              <View
                style={{
                  flex: 0.2,
                  marginBottom: verticalScale(8),
                  marginTop: verticalScale(8)
                }}
              >
                <Text style={styles.text}>Select District:</Text>
                <View
                  style={{
                    flex: 1,
                    elevation: 1,
                    height: moderateScale(45),
                    borderRadius: 10,
                    backgroundColor: 'white',
                    shadowOffset: { width: 3, height: 3 },
                    shadowColor: 'grey',
                    shadowOpacity: 0.25,
                    shadowRadius: 5
                  }}
                >
                  {(Platform.OS == 'android' && (
                    <Picker
                      style={{ flex: 1 }}
                      selectedValue={this.state.chosenValueCity}
                      mode='dropdown'
                      onValueChange={(itemValue, itemIndex) =>
                        this.setState({ chosenValueCity: itemValue })
                      }
                    >
                      <Picker.Item label='Select City' value={undefined} />
                      {distOptions}
                    </Picker>
                  )) || (
                    <PickerNative
                      style={{ width: '100%' }}
                      iosIcon={<IconNative name='arrow-down' />}
                      selectedValue={this.state.chosenValueCity}
                      mode='dropdown'
                      onValueChange={(itemValue, itemIndex) =>
                        this.setState({ chosenValueCity: itemValue })
                      }
                    >
                      <PickerNative.Item
                        label='Select City'
                        value={undefined}
                      />
                      {distOptions}
                    </PickerNative>
                  )}
                </View>
              </View>
            )}
            {this.state.deliverType === 'home' && (
              <View style={styles.address}>
                <Text style={styles.text}>Address:</Text>
                <TextInput
                  multiline={true}
                  numberOfLines={4}
                  textAlignVertical='top'
                  onChangeText={address => this.setState({ address })}
                  value={this.state.address}
                  style={{
                    borderColor: '#bcbdc0',
                    borderWidth: 1,
                    borderRadius: 10,
                    height: '100%'
                  }}
                  placeholder='Provide shipping address, (Your profile address will be used if left Empty)'
                  textContentType='location'
                />
              </View>
            )}

            <View style={styles.instruction}>
              <Text
                style={{
                  fontSize: moderateScale(15),
                  paddingTop: moderateScale(15),
                  color: '#707070',
                  paddingBottom: moderateScale(5),
                  fontWeight: 'bold'
                }}
              >
                Instruction:
              </Text>
              <TextInput
                multiline={true}
                numberOfLines={4}
                textAlignVertical='top'
                onChangeText={instruction => this.setState({ instruction })}
                value={this.state.instruction}
                style={{
                  borderColor: '#bcbdc0',
                  borderWidth: 1,
                  borderRadius: 10,
                  height: '100%'
                }}
                placeholder='Provide instructions'
                textContentType='location'
              />
            </View>

            <View style={styles.payCashViewStyle}>
              {/* <Text style={{ fontSize: moderateScale(15), fontWeight: 'bold' }}>
                Payment Method
              </Text>
              <TouchableOpacity
                onPress={() =>
                  this.setState({
                    isPaymentModalVisible: !this.state.isPaymentModalVisible
                  })
                }
              >
                <View
                  style={{
                    flexDirection: 'row'
                  }}
                >
                  <Text
                    style={{ fontSize: moderateScale(15), color: '#1285ff' }}
                  >
                    Select Payment Method
                  </Text>
                  <Icon
                    name='arrow-right'
                    type='material-community'
                    size={20}
                    color='#1285ff'
                  />
                </View>
              </TouchableOpacity> */}
            </View>

            {medicine && (
              <View>
                <Button
                  title='Upload Prescription'
                  containerStyle={{ width: '100%' }}
                  buttonStyle={{ borderRadius: 10, backgroundColor: '#60BB46' }}
                  titleStyle={{ fontSize: moderateScale(18) }}
                  onPress={() => this.selectPhotoTapped()}
                />
              </View>
            )}

            {this.state.imageNameList.length > 0 && (
              <Text
                style={{
                  fontSize: moderateScale(15),
                  fontWeight: 'bold',
                  paddingTop: 10,
                  paddingBottom: 5
                }}
              >
                Uploaded prescriptions:
              </Text>
            )}

            {this.state.imageNameList.length > 0 &&
              this.state.imageNameList.map(item => {
                return (
                  <View>
                    <Text>{item}</Text>
                  </View>
                );
              })}

            <View
              style={{
                height: 1,
                backgroundColor: 'grey',
                width: '100%',
                alignSelf: 'center',
                opacity: 0.3,
                marginTop: 10
              }}
            />
            <View
              style={{
                flex: 0.1,
                justifyContent: 'center',
                alignItems: 'center',
                paddingTop: verticalScale(20),
                paddingBottom: verticalScale(10)
              }}
            >
              <Button
                title='Confirm'
                containerStyle={{ width: '100%' }}
                buttonStyle={{ borderRadius: 10, backgroundColor: '#60BB46' }}
                titleStyle={{ fontSize: moderateScale(18) }}
                onPress={() =>
                  this.setState({
                    isPaymentModalVisible: !this.state.isPaymentModalVisible
                  })
                }
              />
            </View>
          </View>
        </ScrollView>
      </View>
    );
  }
}

const width = Dimensions.get('window').width;

const styles = StyleSheet.create({
  container: {
    flex: 1
  },

  body: {
    flex: 1,
    margin: moderateScale(20)
  },

  address: {
    flex: 0.2,
    // marginBottom: Platform.OS == 'ios' ? 30 : 0,
    marginBottom: 30
  },

  text: {
    fontSize: moderateScale(15),
    color: '#707070',
    paddingBottom: moderateScale(10),
    fontWeight: '500'
  },

  delivery: {
    flex: 0.1,
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: moderateScale(15),
    justifyContent: 'space-between'
  },

  instruction: {
    flex: 0.2,
    // marginBottom: Platform.OS == 'ios' ? 30 : 0,
    marginBottom: 30
  },

  image: {
    flex: 0.98,
    resizeMode: 'contain',
    width: width * 0.13,
    height: width * 0.14
  },

  imagePressed: {
    flex: 0.98,
    resizeMode: 'contain',
    width: width * 0.14,
    height: width * 0.14,
    borderColor: 'black',
    borderWidth: 1,
    borderRadius: 5,
    justifyContent: 'center',
    alignItems: 'center'
  },

  payCashViewStyle: {
    flex: 0.1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: verticalScale(45),
    paddingTop: moderateScale(15),
    paddingBottom: moderateScale(15)
  },

  checkBoxStyle: {
    backgroundColor: '#ffffff',
    width: '45%',
    marginLeft: 0,
    marginRight: 0
  }
});
