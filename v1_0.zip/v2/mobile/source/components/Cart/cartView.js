import React, { Component } from 'react';
import {
  Platform,
  AsyncStorage,
  StyleSheet,
  Text,
  View,
  Dimensions,
  ScrollView,
  Image,
  FlatList
} from 'react-native';
import Header from '../common/header';
import CartViewField from './cartViewField';
import ItemDetailsModalView from '../Modal/itemDetailsModalView';
import { Button } from 'react-native-elements';
import Spinner from 'react-native-spinkit';

import PrescriptionModal from '../Modal/prescriptionModal';
import SpinView from '../common/spinner';
import {
  fetchCartData,
  updateCart,
  moderateScale
} from '../../constants/const_functions';

export default class CartView extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isModalVisible: false,
      quantity: {},
      cart: {},
      isReady: false
    };

    this.fetchCartData();
  }

  async fetchCartData() {
    await fetchCartData(this);
    const quantity = {};
    for (key in this.state.cart) quantity[key] = this.state.cart[key].quantity;
    console.log(this.state.cart);
    this.setState({ quantity, isReady: true });
  }

  addQuantity(id) {
    const { quantity, cart } = this.state;
    quantity[id] = quantity[id] + 1;
    // console.log(quantity);

    this.setState({ quantity }, () => {
      for (key in quantity) cart[key].quantity = quantity[key];
      updateCart(cart, this);
    });
  }

  reduceQuantity(id) {
    const { quantity, cart } = this.state;
    if (quantity[id] == 0) {
      // TODO :: Show toast message
      return;
    }
    quantity[id] = quantity[id] - 1;
    // console.log(quantity, id)

    this.setState({ quantity }, () => {
      for (key in quantity) {
        cart[key].quantity = quantity[key];
        if (quantity[key] === 0) {
          delete cart[key];
          this.setState({ quantity, isReady: false }, () => this.fetchCartData());
        }
      }
      updateCart(cart, this);
    });
  }

  removeItemFromCart(id) {
    let { cart } = this.state;
    delete cart[id];
    updateCart(cart, this);
    this.setState({ removeSnack: true }, () =>
      setTimeout(() => {
        this.setState({
          removeSnack: false
        });
      }, 1500)
    );
  }

  updateState(obj) {
    this.setState({ isModalVisible: obj.isModalVisible });
  }

  handlePrescription() {
    this.setState({ isModalVisible: false });
    this.props.navigation.navigate('Checkout');
  }

  render() {
    console.log('cart main', this.state);
    const { cart, quantity } = this.state;
    const arrCart = [];
    for (var key in cart) {
      if (cart.hasOwnProperty(key)) {
        arrCart.push({ ...cart[key], id: key });
      }
    }

    if (!this.state.isReady) {
      return (
        <View style={{ flex: 1 }}>
          <Header
            text='Cart'
            iconLeft='arrowleft'
            navigation={this.props.navigation}
          />
          <View
            style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}
          >
            <SpinView />
          </View>
        </View>
      );
    }

    if (arrCart.length <= 0) {
      return (
        <View style={{ flex: 1 }}>
          <Header
            text='Cart'
            iconLeft='arrowleft'
            navigation={this.props.navigation}
          />

          <View
            style={{
              flex: 1,
              justifyContent: 'center',
              alignItems: 'center'
            }}
          >
            <Image
              source={require('../../assets/empytPageIcon/Group_640.png')}
              style={{
                width: 150,
                height: 150,
                marginRight: moderateScale(40)
              }}
              resizeMode='contain'
            />
            <Text style={{ fontSize: moderateScale(22) }}>
              Nothing in the Cart!
            </Text>
            <Text style={{ fontSize: moderateScale(16) }}>
              You have not added anything in the cart yet.
            </Text>
          </View>
        </View>
      );
    }

    return (
      <View style={styles.container}>
        <PrescriptionModal
          visibility={this.state.isModalVisible}
          visibilityStateName='isModalVisible'
          updateState={this.updateState.bind(this)}
          handlePrescription={this.handlePrescription.bind(this)}
        />
        <Header
          text='Cart'
          iconLeft='arrowleft'
          navigation={this.props.navigation}
        />
        <View style={styles.largeView}>
          <FlatList
            data={arrCart}
            renderItem={({ item, index }) => (
              <CartViewField
                key={index}
                // onPress={() => {}}
                id={item.id}
                medicineName={item.name}
                medicineDesc={item.type}
                addQuantity={this.addQuantity.bind(this)}
                reduceQuantity={this.reduceQuantity.bind(this)}
                removeItemFromCart={this.removeItemFromCart.bind(this)}
                quantity={quantity[item.id]}
                imgComponentAsProp={
                  <Image
                    source={require('../../assets/customIcons/drug.png')}
                    style={{ width: 35, height: 35 }}
                  />
                }
              />
            )}
          />
        </View>
        {arrCart.length > 0 && (
          <Button
            title='Checkout'
            containerStyle={{
              width: '96%',
              alignSelf: 'center',
              marginBottom: Platform.OS === 'ios' ? 20 : 5
            }}
            buttonStyle={{ backgroundColor: '#60BB46' }}
            titleStyle={{ fontSize: moderateScale(17) }}
            onPress={() => {
              this.props.navigation.navigate('Checkout');
            }}
          />
        )}
      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    flex: 1
  },
  smallView: {
    flex: 0.12,
    width: '100%',
    justifyContent: 'flex-end',
    alignItems: 'center',
    marginTop: 12,
    marginBottom: 10
  },
  largeView: {
    flex: 1,
    justifyContent: 'flex-start',
    width: '100%',
    alignItems: 'center'
  },
  scrollStyle: {
    flex: 1,
    width: '100%',
    paddingTop: 15,
    backgroundColor: '#ffffff'
    // elevation: 2,
  },
  modalStyle: {
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1
  },
  modalInsideViewStyle: {
    flex: 0.45,
    justifyContent: 'flex-start',
    alignItems: 'center',
    backgroundColor: '#eeeeee',
    width: '100%',
    borderRadius: 10
  },
  modalChildStyle: {
    flex: 0.33,
    width: '100%',
    alignItems: 'center'
  },
  modalButtonView: {
    flex: 0.33,
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center'
  }
});
