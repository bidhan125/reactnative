import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Dimensions,
  Image,
  TouchableOpacity,
} from 'react-native';
import { verticalScale, moderateScale } from '../../constants/const_functions';

//props: borderTopRadiusLeft,borderTopRadiusRight,borderBottomRadiusLeft,borderBottomRadiusRight,textLeft,textRight

export default class HomeViewField extends Component {
  render() {
    const displayWidth = Dimensions.get('window').width;
    const displayHeight = Dimensions.get('window').height;

    let childWidth = displayWidth / 2.2;
    let childHeight = verticalScale(166);
    let gap = (displayWidth * 3.5) / 100;

    return (
      <View
        style={styles.brokenView}
        height={childHeight}
        width={displayWidth * 0.94}
        marginTop={0.5}
      >
        <TouchableOpacity
          onPress={() => {
            this.props.navigation.navigate(this.props.navLeft);
          }}
        >
          <View
            style={styles.finalView}
            height={childHeight}
            width={childWidth}
            borderTopLeftRadius={this.props.borderRadiusTopLeft}
            borderBottomLeftRadius={this.props.borderRadiusBottomLeft}
          >
            <View>{this.props.leftImgAsComponent}</View>

            <View style={{ height: moderateScale(12) }} />

            <Text style={styles.textStyle}>{this.props.textLeft}</Text>

            {this.props.textAsComponent}
          </View>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => {
            this.props.navigation.navigate(this.props.navRight);
          }}
        >
          <View
            style={styles.finalView}
            height={childHeight}
            width={childWidth}
            borderTopRightRadius={this.props.borderRadiusTopRight}
            borderBottomRightRadius={this.props.borderRadiusBottomRight}
          >
            <View>{this.props.rightImgAsComponent}</View>

            <View style={{ height: moderateScale(12) }} />

            <View style={{ alignItems: 'center' }}>
              <Text style={styles.textStyle}>{this.props.textRight}</Text>
            </View>
          </View>
        </TouchableOpacity>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  brokenView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 10,
  },
  finalView: {
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
    elevation: 2,
    shadowOffset: { width: 3, height: 3 },
    shadowColor: 'grey',
    shadowOpacity: 0.25,
    shadowRadius: 5,
  },
  textStyle: {
    fontSize: moderateScale(15),
    fontWeight: 'bold',
    textAlign: 'center'
  },
});
