import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Dimensions,
  ScrollView,
  Image
} from 'react-native';

import Header from '../common/header';
import HomeViewField from './homeViewField';
import { moderateScale, verticalScale } from '../../constants/const_functions';

export default class Home extends Component {
  render() {
    const displayWidth = Dimensions.get('window').width;
    const displayHeight = Dimensions.get('window').height;
    let childWidth = displayWidth / 2.2;
    let childHeight = displayWidth / 2;
    let gap = (displayWidth * 3.5) / 100;
    let upperPadding = displayHeight * 0.02;

    return (
      <View style={styles.container}>
        <Header
          text="Home"
          iconLeft="bars"
          iconRight="shoppingcart"
          rightIconAction={() => this.props.navigation.navigate('Cart')}
          navigation={this.props.navigation}
        />

        <View style={styles.largeView}>
          <ScrollView
            style={styles.scrollingView}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{
              justifyContent: 'flex-start',
              alignItems: 'center'
            }}
          >
            <HomeViewField
              navigation={this.props.navigation}
              navLeft="Appointments"
              navRight="Diagnostics"
              textLeft="Appointments"
              textRight="Diagnostics"
              borderRadiusTopLeft={8}
              borderRadiusTopRight={8}
              leftImgAsComponent={
                <Image
                  resizeMode='contain'
                  source={require('../../assets/home/Appointment.png')}
                  style={{
                    width: moderateScale(91),
                    height: moderateScale(92)
                  }}
                />
              }
              rightImgAsComponent={
                <Image
                  resizeMode='contain'
                  source={require('../../assets/home/Artboard.png')}
                  style={{
                    width: moderateScale(91),
                    height: moderateScale(92)
                  }}
                />
              }
            />

            <HomeViewField
              navigation={this.props.navigation}
              navLeft="HomeCare"
              navRight="Ambulance"
              textLeft="Home Care"
              textRight="Ambulance and Emergencies"
              leftImgAsComponent={
                <Image
                  source={require('../../assets/home/Home_service.png')}
                  style={{
                    width: moderateScale(91),
                    height: moderateScale(92)
                  }}
                />
              }
              rightImgAsComponent={
                <Image
                  resizeMode='contain'
                  source={require('../../assets/home/Ambulance.png')}
                  style={{
                    width: moderateScale(91),
                    height: moderateScale(92)
                  }}
                />
              }
            />

            <HomeViewField
              navigation={this.props.navigation}
              textLeft="Healthcare"
              textAsComponent={
                <Text
                  style={{ fontSize: moderateScale(15), fontWeight: 'bold' }}
                >
                  Accessories
                </Text>
              }
              textRight="Pharmacy"
              navLeft="HealthCareAccessories"
              navRight="Pharmacy"
              borderRadiusBottomLeft={8}
              borderRadiusBottomRight={8}
              leftImgAsComponent={
                <Image
                  source={require('../../assets/home/Medical_Accessories.png')}
                  style={{
                    width: moderateScale(91),
                    height: moderateScale(92)
                  }}
                />
              }
              rightImgAsComponent={
                <Image
                  source={require('../../assets/home/Pharmacy.png')}
                  style={{
                    width: moderateScale(92),
                    height: moderateScale(92)
                  }}
                />
              }
            />
          </ScrollView>
        </View>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
    alignItems: 'flex-start',
    justifyContent: 'center'
  },
  largeView: {
    flex: 1,
    width: '100%',
    justifyContent: 'flex-start',
    alignItems: 'center'
  },

  scrollingView: {
    width: '100%',
    flex: 1,
    paddingTop: 15
  }
});
