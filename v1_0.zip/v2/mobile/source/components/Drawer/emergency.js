import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, ScrollView } from 'react-native';
import Header from '../common/header';
import EmergencyFieldView from './emergencyFieldView';

export default class Emergency extends Component {
  render() {
    return (
      <View style={{ flex: 1 }}>
        <Header
          text="Emergency"
          iconLeft="arrowleft"
          iconRight="shoppingcart"
          bottomMargin={0}
          navigation={this.props.navigation}
        />
        <ScrollView
          style={styles.scrollStyle}
          contentContainerStyle={{
            justifyContent: 'flex-start',
            alignItems: 'center'
          }}
        >
          <EmergencyFieldView text="Labaid Hotline" phone='01766661030' />
          <EmergencyFieldView text="24 Hours Emergency" phone='01766661030' />
          <EmergencyFieldView text="Home Service" phone='01766661030' />
          <EmergencyFieldView text="Cardiac Customer Care" phone='01766661030' />
          <EmergencyFieldView text="Specialized Customer Care" phone='01766661030' />
          <EmergencyFieldView text="Cardiac Admission" phone='01766661030' />
          <EmergencyFieldView text="Specialized Admission" phone='01766661030' />
        </ScrollView>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  scrollStyle: {
    flex: 0.7,
    paddingTop: 15
  }
});
