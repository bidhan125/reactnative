import React, { Component } from 'react';
import {
  AsyncStorage,
  Text,
  View,
  StyleSheet,
  Image,
  ScrollView,
  TouchableOpacity,
  Alert,
  Platform,
  SafeAreaView,
  ToastAndroid
} from 'react-native';
import { Icon } from 'react-native-elements';
import Styles from '../common/styles';
import Meteor from 'react-native-meteor';

import {
  getUserAsync,
  moderateScale,
  logout
} from '../../constants/const_functions';
import { version } from '../../constants/const_strings';

export default class DrawerContentComponents extends Component {
  constructor(props) {
    super(props);

    this.state = {
      user: {}
    };

    this.fetchUsser();
  }

  async fetchUsser() {
    this.setState({ user: JSON.parse(await getUserAsync()) });
  }

  navigateToScreen = route => () => {
    const navigateAction = NavigationActions.navigate({
      routeName: route
    });
    this.props.navigation.dispatch(navigateAction);
  };

  render() {
    const { user } = this.state;
    console.log(user);
    return (
      <View style={styles.mainView}>
        <SafeAreaView style={styles.headerView}>
          <TouchableOpacity
            onPress={() => this.props.navigation.navigate('ProfileInfo')}
            style={{
              borderRadius: 100,
              overflow: 'hidden',
              height: moderateScale(80),
              width: moderateScale(80),
              marginLeft: Platform.OS === 'ios' ? 10 : 0
            }}
          >
            {user.profile !== undefined && (
              <Image
                // source={require('../../assets/customIcons/user-choms.png')}
                source={{ uri: user.profile.avatar }}
                style={styles.profileImage}
              />
            )}
          </TouchableOpacity>
          <View>
            <TouchableOpacity
              onPress={() => this.props.navigation.navigate('ProfileInfo')}
            >
              <Text
                style={{
                  fontSize: moderateScale(20),
                  paddingLeft: moderateScale(10),
                  color: 'white',
                  fontWeight: 'bold'
                }}
              >
                {user.profile
                  ? user.profile.name.length > 18
                    ? user.profile.name.substring(0, 18) + '...'
                    : user.profile.name
                  : 'Loading...'}
              </Text>
              <Text
                style={{
                  fontSize: moderateScale(15),
                  paddingLeft: moderateScale(10),
                  color: 'white'
                }}
              >
                {user.profile ? user.profile.phone : 'Loading...'}
              </Text>
            </TouchableOpacity>
          </View>
        </SafeAreaView>
        <View style={styles.bodyView}>
          <ScrollView>
            <TouchableOpacity
              onPress={() => {
                this.props.navigation.navigate('Home');
              }}
            >
              <View style={Styles.navItemStyle}>
                <View style={styles.leftFlex}>
                  <Icon
                    name='home'
                    type='font-awesome'
                    iconStyle={{ color: '#707070' }}
                    size={moderateScale(25)}
                  />
                </View>
                <View style={styles.reightFlex}>
                  <Text style={Styles.navTextStyle}>Home</Text>
                </View>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => {
                this.props.navigation.navigate('MedicalTourism');
              }}
            >
              <View style={Styles.navItemStyle}>
                <View style={styles.leftFlex}>
                  <Image
                    source={require('../../assets/customIcons/earth-globe-symbol-of-grid.png')}
                    style={{
                      width: moderateScale(23),
                      height: moderateScale(23)
                    }}
                  />
                </View>
                <View style={styles.reightFlex}>
                  <Text style={Styles.navTextStyle}>Medical Tourism</Text>
                </View>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => this.props.navigation.navigate('ProfileInfo')}
            >
              <View style={[Styles.navItemStyle]}>
                <View style={styles.leftFlex}>
                  <Icon
                    name='account'
                    type='material-community'
                    iconStyle={{ color: '#707070' }}
                    size={moderateScale(25)}
                  />
                </View>
                <View style={styles.reightFlex}>
                  <Text style={Styles.navTextStyle}>My Profile</Text>
                </View>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => this.props.navigation.navigate('MyBeneficiaries')}
            >
              <View style={[Styles.navItemStyle]}>
                <View style={styles.leftFlex}>
                  <Icon
                    name='account-group'
                    type='material-community'
                    iconStyle={{ color: '#707070' }}
                    size={moderateScale(25)}
                  />
                </View>
                <View style={styles.reightFlex}>
                  <Text style={Styles.navTextStyle}>My Beneficiaries</Text>
                </View>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => this.props.navigation.navigate('MedicalReport')}
            >
              <View style={[Styles.navItemStyle]}>
                <View style={styles.leftFlex}>
                  <Image
                    source={require('../../assets/medical-report.png')}
                    style={{
                      width: moderateScale(23),
                      height: moderateScale(23)
                    }}
                  />
                </View>

                <View style={styles.reightFlex}>
                  <Text style={Styles.navTextStyle}>Medical Report</Text>
                </View>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => this.props.navigation.navigate('MedicalHistory')}
            >
              <View style={[Styles.navItemStyle]}>
                <View style={styles.leftFlex}>
                  <Image
                    source={require('../../assets/medical-report.png')}
                    style={{
                      width: moderateScale(23),
                      height: moderateScale(23)
                    }}
                  />
                </View>

                <View style={styles.reightFlex}>
                  <Text style={Styles.navTextStyle}>Medical History</Text>
                </View>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => this.props.navigation.navigate('Emergency')}
            >
              <View style={[Styles.navItemStyle]}>
                <View style={styles.leftFlex}>
                  <Icon
                    name='telephone'
                    type='foundation'
                    iconStyle={{ color: '#707070' }}
                    size={moderateScale(25)}
                  />
                </View>

                <View style={styles.reightFlex}>
                  <Text style={Styles.navTextStyle}>Emergency Lines</Text>
                </View>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => this.props.navigation.navigate('History')}
            >
              <View style={[Styles.navItemStyle]}>
                <View style={styles.leftFlex}>
                  <Icon
                    name='history'
                    iconStyle={{ color: '#707070' }}
                    size={moderateScale(25)}
                  />
                </View>
                <View style={styles.reightFlex}>
                  <Text style={Styles.navTextStyle}>Order History</Text>
                </View>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => this.props.navigation.navigate('Faq')}
            >
              <View style={[Styles.navItemStyle]}>
                <View style={styles.leftFlex}>
                  <Icon
                    name='comment-question'
                    type='material-community'
                    iconStyle={{ color: '#707070' }}
                    size={moderateScale(25)}
                  />
                </View>
                <View style={styles.reightFlex}>
                  <Text style={Styles.navTextStyle}>FAQ</Text>
                </View>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => this.props.navigation.navigate('Feedback')}
            >
              <View style={[Styles.navItemStyle]}>
                <View style={styles.leftFlex}>
                  <Icon
                    name='comment-text-multiple'
                    type='material-community'
                    iconStyle={{ color: '#707070' }}
                    size={moderateScale(25)}
                  />
                </View>
                <View style={styles.reightFlex}>
                  <Text style={Styles.navTextStyle}>Feedback</Text>
                </View>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => this.props.navigation.navigate('PrivacyPolicy')}
            >
              <View style={[Styles.navItemStyle]}>
                <View style={[styles.leftFlex]}>
                  <Icon
                    name='shield'
                    type='foundation'
                    iconStyle={{ color: '#707070' }}
                    size={moderateScale(27)}
                  />
                </View>
                <View style={styles.reightFlex}>
                  <Text style={Styles.navTextStyle}>Privacy Policy</Text>
                </View>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => this.props.navigation.navigate('AboutUs')}
            >
              <View style={[Styles.navItemStyle]}>
                <View style={styles.leftFlex}>
                  <Icon
                    name='info-with-circle'
                    type='entypo'
                    iconStyle={{ color: '#707070' }}
                    size={moderateScale(25)}
                  />
                </View>
                <View style={styles.reightFlex}>
                  <Text style={Styles.navTextStyle}>About Us</Text>
                </View>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => {
                console.log('signout pressed');
                Alert.alert('Sign Out', 'Are you sure?', [
                  { text: 'No', style: 'cancel' },
                  {
                    text: 'Yes',
                    onPress: () => {
                      Meteor.logout(() => {
                        logout();
                        this.props.navigation.navigate('LogIn');
                        //   console.log('Logged out successfully!');
                        //   AsyncStorage.multiRemove(['user', 'cart'], () =>
                        //     this.props.navigation.navigate('LogIn')
                        //   );
                        ToastAndroid.show(
                          'You have logged out successfuly!',
                          ToastAndroid.LONG
                        );
                      });
                    }
                  }
                ]);
              }}
            >
              <View style={[Styles.navItemStyle]}>
                <View style={styles.leftFlex}>
                  <Image
                    source={require('../../assets/customIcons/logout.png')}
                    style={{ width: 25, height: 25 }}
                  />
                </View>
                <View style={styles.reightFlex}>
                  <Text style={Styles.navTextStyle}>Sign Out</Text>
                </View>
              </View>
            </TouchableOpacity>
          </ScrollView>
        </View>
        <View style={styles.footer}>
          <Text style={{ fontSize: moderateScale(10), paddingRight: 20 }}>
            Developed By
          </Text>
          <Image
            resizeMode={'contain'}
            style={styles.logoImage}
            source={require('../../assets/dl_logo.png')}
          />
          <Text
            style={{
              paddingRight: 20,
              fontSize: moderateScale(8),
              opacity: 0.7
            }}
          >
            {version}
          </Text>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  mainView: {
    flex: 1
    // marginTop: Platform.OS == 'ios' ? 20 : 0
  },

  headerView: {
    flex: 1.5,
    backgroundColor: '#1285ff',
    paddingLeft: moderateScale(10),
    flexDirection: 'row',
    alignItems: 'center'
  },

  bodyView: {
    flex: 8,
    paddingLeft: moderateScale(10)
  },

  footer: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'flex-end'
  },

  profileImage: {
    // overflow: 'hidden',
    // borderWidth: 1,
    // borderRadius: Platform.OS == 'ios' ? 53 : 100,
    width: moderateScale(80),
    height: moderateScale(80)
  },

  text: {
    fontSize: 20
  },

  logoImage: {
    flex: 1,
    width: '35%',
    marginRight: 20
  },

  leftFlex: {
    flex: 1.1,
    justifyContent: 'center',
    alignItems: 'flex-start'
  },

  reightFlex: {
    flex: 9
  }
});
