import React, { Component } from 'react';
import {
  Text,
  StyleSheet,
  ScrollView,
  View,
  Dimensions,
  Image
} from 'react-native';

import Header from '../common/header';

const { width, height } = Dimensions.get('window');

export default class PrivacyPolicy extends Component {
  render() {
    return (
      <View style={styles.container}>
        <Header
          text="Privacy Policy"
          iconLeft="arrowleft"
          navigation={this.props.navigation}
        />

        <ScrollView style={styles.scrollingView}>
          <View
            style={{
              justifyContent: 'center',
              alignItems: 'center',
              marginTop: 10,
              height: height * 0.2
            }}
          >
            <Image
              source={require('../../assets/LabaidLogo.png')}
              style={{ width: 140, height: 100 }}
            />
          </View>

          <View>
            <Text style={styles.text}>
              We will not disclose the Medical health reports to anyone except
              the patient or customer who or she is getting the service.
            </Text>
          </View>

          <View>
            <Text style={styles.titleText}>Use of Personal Information</Text>
            <Text style={styles.text}>
              Personal information collected through our website is used by us
              to, among other things, process and manage registrations, operate
              and improve our website, track site usage policies and statistics,
              make the sites or services easier to use by eliminating the need
              for you to repeatedly enter the same information, and for other
              purposes pursuant to your consent. We also use your personal
              information to communicate with you in other ways. For instance,
              when you register on this site, we may use your personal
              information to send you an email confirming your registration. We
              also use personal information to inform you of significant changes
              to this Privacy Policy.
            </Text>
          </View>

          <View>
            <Text style={styles.titleText}>Security</Text>
            <Text style={styles.text}>
              We have implemented procedures to help protect the personal
              information that you provide to us. However, no method of
              transmitting or storing electronic data is ever completely secure,
              and we cannot guarantee that such information will never be
              accessed, used, or released in a manner that is inconsistent with
              this policy.
            </Text>
          </View>

          <View>
            <Text style={styles.titleText}>
              Changes to This Privacy Statement
            </Text>
            <Text style={styles.text}>
              We may update this Privacy Policy in the future. We will notify
              you about material changes to this Privacy Policy by sending a
              notice to the e-mail address you provided to us.
            </Text>
          </View>
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'flex-start',
    alignItems: 'center',
    backgroundColor: '#ffffff'
  },
  scrollingView: {
    flexDirection: 'column',
    flex: 0.85,
    paddingHorizontal: 20
  },

  titleText: {
    paddingBottom: 10,
    fontSize: 15,
    fontWeight: 'bold'
  },

  text: {
    paddingBottom: 20,
    fontSize: 15,
    textAlign: 'justify'
  }
});
