import React, { Component } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  Image,
  TouchableOpacity,
  FlatList
} from 'react-native';

import Meteor from 'react-native-meteor';
import Pdf from 'react-native-pdf';
import Modal from 'react-native-modal';
import moment from 'moment';

import Header from '../common/header';
import SpinView from '../common/spinner';

const { width, height } = Dimensions.get('window');

export default class MedicalHistory extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      isLoaded: false,
      isModalVisible: false
    };

    this.fetchMedicalHistory();
  }

  fetchMedicalHistory() {
    const patientId = Meteor.userId();
    Meteor.call(
      'fetchMedicalHistories',
      { patientId, page_no: 1 },
      (err, res) => {
        console.log(err, res);
        if (err) {
          console.log(err);
        } else {
          this.setState({ data: res, isLoaded: true });
        }
      }
    );
  }

  updateState(obj) {
    this.setState(obj);
  }

  render() {
    const { isLoaded, data, isModalVisible, source } = this.state;
    console.log(this.state.source)

    return (
      <View style={{ flex: 1 }}>
        <Header
          text='Medical History'
          iconLeft='arrowleft'
          iconRight='shoppingcart'
          navigation={this.props.navigation}
        />

        <Modal
          animationType='fade'
          cancellable={true}
          transparent={false}
          visible={isModalVisible}
          onBackdropPress={() =>
            this.setState({ isModalVisible: !isModalVisible })
          }
          onBackButtonPress={() =>
            this.setState({ isModalVisible: !isModalVisible })
          }
        >
          <View
            style={{
              position: 'relative',
              flex: 1,
              backgroundColor: '#F0F5F6'
            }}
          >
            <Pdf
              source={source}
              // source={this.props.pdfUrl}
              onLoadComplete={(numberOfPages, filePath) => {
                console.log(`number of pages: ${numberOfPages}`);
              }}
              onPageChanged={(page, numberOfPages) => {
                console.log(`current page: ${page}`);
              }}
              onError={error => {
                console.log(error);
              }}
              style={styles.pdf}
            />
          </View>
        </Modal>

        <View style={styles.container}>
          <FlatList
            data={this.state.data}
            renderItem={({ item, index }) => (
              <View style={styles.cardStyle}>
                <View style={{ flex: 7, justifyContent: 'center' }}>
                  <Text style={{ fontSize: 20, padding: 5 }}>{item.name}</Text>
                  <Text style={{ fontSize: 15, padding: 5 }}>
                    {item.patientName}
                  </Text>
                  <Text style={{ fontSize: 15, padding: 5 }}>
                    {moment(item.createdAt).format('YYY-MM-DD')}
                  </Text>
                </View>
                <TouchableOpacity
                  style={{ flex: 7 }}
                  onPress={() => this.setState({ isModalVisible: true, source: {uri: item.fileUrl, cache: true} })}
                >
                  <Image
                    source={require('../../assets/pdf.png')}
                    style={{
                      height: 120,
                      width: 100,
                      alignSelf: 'flex-end',
                      borderBottomRightRadius: 10
                    }}
                  />
                </TouchableOpacity>
              </View>
            )}
          />
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    // flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white'
  },

  cardStyle: {
    flexDirection: 'row',
    backgroundColor: 'white',
    borderRadius: 10,
    width: width - 20,
    height: 120,
    elevation: 2,
    marginLeft: 10,
    marginRight: 10,
    marginTop: 5,
    marginBottom: 10,
    shadowOffset: { width: 3, height: 3 },
    shadowColor: 'grey',
    shadowOpacity: 0.25,
    shadowRadius: 7
  },

  cardHeading: {
    height: 40,
    justifyContent: 'center',
    alignItems: 'center'
  },

  headerText: {
    fontSize: 20,
    color: 'black'
  },

  cardBody: {
    // height: 110,
    padding: 8,
    flexDirection: 'row',
    justifyContent: 'space-between'
  },

  text: {
    fontSize: 18
  },

  row: {
    height: 28,
    width: '100%',
    flexDirection: 'row'
  },
  pdf: {
    flex: 1,
    width: Dimensions.get('window').width - 50
  }
});
