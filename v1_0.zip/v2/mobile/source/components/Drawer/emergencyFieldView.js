import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Dimensions,
  Image,
  TouchableOpacity
} from 'react-native';
import call from 'react-native-phone-call';
//props: text

export default class EmergencyFieldView extends Component {
  render() {
    const displayWidth = Dimensions.get('window').width;
    const displayHeight = Dimensions.get('window').height;
    let h = displayHeight * 0.15;
    let w;

    const args = {
      number: this.props.phone,
      prompt: false
    };

    return (
      <View style={styles.fieldView} height={h}>
        <View style={{ flex: 0.75 }}>
          <Text style={{ fontSize: 17, fontFamily: 'times new roman' }}>
            {this.props.text}
          </Text>
        </View>
        <View
          style={{ flex: 0.25, justifyContent: 'center', alignItems: 'center' }}
        >
          <TouchableOpacity
            style={{
              // elevation: 1,
              padding: 6,
              borderRadius: 100,
              shadowOffset: { width: 3, height: 3 },
              shadowColor: 'grey',
              shadowOpacity: 1,
              shadowRadius: 5
            }}
            activeOpacity={0.6}
            onPress={() => call(args).catch(console.error)}
          >
            <Image
              source={require('../../assets/customIcons/call-answer.png')}
              style={{ width: 23, height: 23 }}
            />
          </TouchableOpacity>
        </View>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  fieldView: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    width: '94%',
    borderRadius: 9,
    backgroundColor: '#00FFFF15',
    paddingLeft: 20,
    marginBottom: 8
  }
});
