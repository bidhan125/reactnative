import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  TextInput,
  Image,
  KeyboardAvoidingView,
  ScrollView,
  Picker,
  Alert
} from 'react-native';
import { Picker as PickerNative, Icon as IconNative } from 'native-base';
import { Input, Icon, Button } from 'react-native-elements';
import Meteor from 'react-native-meteor';

import Header from '../common/header';
import SpinView from '../common/spinner';
import GreenButton from '../common/lifeplusGreenButton';
import {
  moderateScale,
  verticalScale,
  getUserAsync,
  validation
} from '../../constants/const_functions';
import { feedback_type } from '../../constants/const_strings';

export default class Feedback extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: undefined,
      phone: undefined,
      email: undefined,
      description: undefined,
      categrory: undefined,
      processing: false
    };
  }

  onSubmit() {
    const { name, phone, email, category, description } = this.state;

    if (validation(name, 'isName') !== true) return;
    if (validation(phone, 'isPhone') !== true) return;
    if (validation(email, 'isEmail') !== true) return;
    if (category === undefined) {
      alert('Please select a category!');
      return;
    }
    if (description === undefined || description.length <= 0) {
      alert('Give your feedback');
      return;
    }

    this.setState({ processing: true });

    data = {
      name,
      phone,
      email,
      category,
      description
    };

    Meteor.call('addFeedback', data, (err, res) => {
      console.log(err, res);
      this.setState({ processing: false });
      if (err) {
        alert(
          'Sorry! Failed to submit your request at this moment. Please try again later'
        );
      } else if (res) {
        Alert.alert(
          'Success',
          'Congratulations! Your feedback has been received successfully! Thank you!'
        );
      }
    });
  }

  render() {
    const feedBackOptions = [];
    for (var v in feedback_type) {
      feedBackOptions.push(
        <Picker.Item key={v} label={feedback_type[v]} value={v} />
      );
    }

    if (this.state.processing) {
      return <SpinView />;
    }
    return (
      <KeyboardAvoidingView style={styles.container}>
        <Header
          text={'Feedback'}
          iconLeft="arrowleft"
          iconRight="shoppingcart"
          navigation={this.props.navigation}
        />

        <ScrollView
          style={{ width: '100%' }}
          contentContainerStyle={{
            justifyContent: 'center',
            alignItems: 'center'
          }}
        >
          <View style={{ margin: moderateScale(20), flex: 1, width: '80%' }}>
            <Input
              placeholder="Name"
              value={this.state.name}
              editable={true}
              onChangeText={name => this.setState({ name: name })}
              leftIcon={
                <Icon name="user" type="antdesign" size={24} color="#707070" />
              }
              leftIconContainerStyle={{paddingRight: Platform.OS === 'ios' ? 10 : 0}}
              onSubmitEditing={() => this.phoneRef.focus()}
              containerStyle={{
                borderWidth: 1,
                borderRadius: 20,
                marginBottom: 20,
                borderColor: '#BCBDC0'
              }}
              inputContainerStyle={{ borderBottomWidth: 0 }}
              returnKeyType="next"
            />
            <Input
              placeholder="Phone"
              value={this.state.phone}
              editable={true}
              onChangeText={phone => this.setState({ phone: phone })}
              leftIcon={
                <Icon name="phone" type="antdesign" size={24} color="#707070" />
              }
              containerStyle={{
                borderWidth: 1,
                borderRadius: 20,
                marginBottom: 20,
                borderColor: '#BCBDC0'
              }}
              inputContainerStyle={{ borderBottomWidth: 0 }}
              leftIconContainerStyle={{paddingRight: Platform.OS === 'ios' ? 10 : 0}}
              keyboardType="phone-pad"
              ref={ref => (this.phoneRef = ref)}
              onSubmitEditing={() => this.emailRef.focus()}
              returnKeyType="next"
            />
            <Input
              placeholder="Email"
              value={this.state.email}
              editable={true}
              onChangeText={email => this.setState({ email: email })}
              keyboardType="email-address"
              leftIcon={
                <Icon name="mail" type="antdesign" size={24} color="#707070" />
              }
              containerStyle={{
                borderWidth: 1,
                borderRadius: 20,
                marginBottom: 20,
                borderColor: '#BCBDC0'
              }}
              inputContainerStyle={{ borderBottomWidth: 0 }}
              leftIconContainerStyle={{paddingRight: Platform.OS === 'ios' ? 10 : 0}}
              ref={ref => (this.emailRef = ref)}
              onSubmitEditing={() => this.feedBackRef.focus()}
              returnKeyType="next"
            />
            <View
              style={{
                flex: 1,
                borderWidth: 1,
                marginBottom: 20,
                borderRadius: 20,
                borderColor: '#BCBDC0',
                flexDirection: 'row',
                // justifyContent: 'center',
                paddingLeft: 20
              }}
            >
              {/* {Platform.OS == 'ios' && ( */}
              <Icon
                flex={1}
                name="exclamationcircleo"
                type="antdesign"
                color="#707070"
              />
              {/* )} */}
              {(Platform.OS == 'android' && (
                <Picker
                  selectedValue={this.state.category}
                  iosIcon={<IconNative name="arrow-down" />}
                  mode="dropdown"
                  onValueChange={(itemValue, itemIndex) =>
                    this.setState({ category: itemValue })
                  }
                  style={{
                    flex: 1,
                    borderWidth: 1,
                    borderColor: '#BCBDC0',
                    borderRadius: 20,
                    color: '#707070'
                  }}
                >
                  <Picker.Item
                    key="key_select"
                    label="Choose Catagory"
                    value={undefined}
                  />
                  {feedBackOptions}
                </Picker>
              )) || (
                <PickerNative
                  selectedValue={this.state.category}
                  mode="dropdown"
                  placeholder="Choose Category"
                  iosIcon={<IconNative name="arrow-down" />}
                  onValueChange={(itemValue, itemIndex) =>
                    this.setState({ category: itemValue })
                  }
                  style={{
                    flex: 1,
                    color: '#707070'
                  }}
                >
                  {feedBackOptions}
                </PickerNative>
              )}
            </View>
            <Input
              ref={ref => (this.feedBackRef = ref)}
              placeholder="Write your feedback"
              containerStyle={{
                borderWidth: 1,
                borderRadius: 20,
                marginBottom: 20,
                borderColor: '#BCBDC0',
                height: 100
              }}
              inputStyle={null}
              multiline={true}
              numberOfLines={4}
              textAlignVertical="top"
              onChangeText={description =>
                this.setState({ description: description })
              }
              inputContainerStyle={{ borderBottomWidth: 0 }}
            />
            <Button
              title="Submit"
              onPress={() => this.onSubmit()}
              containerStyle={{ width: '100%', alignSelf: 'center' }}
              buttonStyle={{ backgroundColor: '#60BB46', borderRadius: 20 }}
              titleStyle={{ color: 'white' }}
            />
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'flex-start',
    alignItems: 'center',
    backgroundColor: '#ffffff'
  },

  keyboardAvoidView: {
    flex: 0.75,
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center'
  },

  inputText: {
    marginBottom: 10,
    paddingBottom: 20
  }
});
