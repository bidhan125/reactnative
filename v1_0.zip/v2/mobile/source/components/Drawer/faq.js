import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  ScrollView,
  View,
  Dimensions
} from 'react-native';
import Header from '../common/header';

const displayWidth = Dimensions.get('window').width;

export default class Faq extends Component {
  render() {
    return (
      <View style={styles.container}>
        <Header
          text='FAQ'
          iconLeft='arrowleft'
          iconRight='shoppingcart'
          navigation={this.props.navigation}
        />

        <ScrollView
          style={styles.scrollingView}
          contentContainerStyle={{
            justifyContent: 'flex-start',
            alignItems: 'flex-start'
          }}
        >
          <View height={30} />
          <View>
            <Text style={styles.titleText}>1. What is LifePlus BD?</Text>
            <Text style={styles.text}>
              A Sister Concern of Labaid Group. A Maestro in Healthcare by
              providing solutions through Software Applications.
            </Text>
          </View>

          <View>
            <Text style={styles.titleText}>
              2. How it creates impact in human life?
            </Text>
            <Text style={styles.text}>
              It is a healthcare app based creation where providing health
              solutions are the prime aim.
            </Text>
          </View>

          <View>
            <Text style={styles.titleText}>3. What are the facilities?</Text>
            <Text style={styles.text}>
              Report Home Delivery, Doctor Appointment, Home Nursing, Ambulance
              Services, Medical Equipment Selling, on line Pharmacy Store,
              Tele-Medicine etc.
            </Text>
          </View>

          <View>
            <Text style={styles.titleText}>
              4. What are the Payment method?
            </Text>
            <Text style={styles.text}>
              We take cash on delivery and credit cards are also viable.
            </Text>
          </View>

          <View>
            <Text style={styles.titleText}>
              5. How much time it will take to have the products, reports at my
              hand?
            </Text>
            <Text style={styles.text}>Within 24 hours.</Text>
          </View>

          <View>
            <Text style={styles.titleText}>
              6. How much time will be given by the home nurses?
            </Text>
            <Text style={styles.text}>Depends on the Patient’s condition</Text>
          </View>
        </ScrollView>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'flex-start',
    alignItems: 'center',
    backgroundColor: '#ffffff'
  },
  scrollingView: {
    flexDirection: 'column',
    flex: 0.85,
    paddingHorizontal: 20
  },

  titleText: {
    paddingBottom: 10,
    fontSize: 15,
    fontWeight: 'bold'
  },
  text: {
    paddingBottom: 20,
    fontSize: 15,
    textAlign: 'justify'
  }
});
