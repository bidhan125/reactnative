import React, { Component } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  ScrollView,
  Dimensions,
  TouchableOpacity,
  FlatList,
  Platform,
  ToastAndroid,
  PermissionsAndroid,
  ProgressBarAndroid
} from 'react-native';

// import RNFetchBlob from 'rn-fetch-blob';
import ImageView from 'react-native-image-view';
import RNFS from 'react-native-fs';
import { Icon } from 'react-native-elements';
import Carousel from 'react-native-looped-carousel';
import Meteor from 'react-native-meteor';
import Lightbox from 'react-native-lightbox';
import Spinner from 'react-native-spinkit';
import moment from 'moment';
import shorthash from 'shorthash';

import Header from '../common/header';
import SpinView from '../common/spinner';

const { width, height } = Dimensions.get('window');

const pageSize = 10;

export default class MedicalReport extends Component {
  constructor(props) {
    super(props);
    console.log(RNFS.DocumentDirectoryPath);
    this.state = {
      isLoaded: false,
      reportList: [],
      activePage: 1,
      totalPages: 1,
      isVisible: false,
      imageUri: undefined,
      progress: 0,
      loading: false
    };

    this.fetchReport();
    this.fetchTotalReportCount();
  }

  fetchTotalReportCount() {
    Meteor.call('fetchTotalReportCount', (err, res) => {
      console.log(err, res);
      if (err) {
        alert('Could not fetch total report count');
      } else {
        this.setState({ totalPages: Math.ceil(res / pageSize) });
      }
    });
  }

  fetchReport() {
    const patientId = Meteor.userId();
    const { activePage, reportList } = this.state;
    Meteor.call('fetchReport', { patientId, page_no: activePage }, (err, res) => {
      console.log(err, res);
      if (err) {
        alert('Cannot fetch report now!');
      } else {
        this.setState({
          reportList: reportList.concat(res),
          activePage: activePage + 1,
          isLoaded: true,
          isLoadingMore: false
        });
      }
    });
  }

  handlePaginate() {
    const { activePage, totalPages } = this.state;
    this.setState({ isLoadingMore: true });

    if (activePage <= totalPages) {
      this.fetchReport();
    } else {
      this.setState({ isLoadingMore: false });
      if (activePage !== 2) alert('You are at the end of list.');
    }
  }

  async downloadFile() {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
        {
          title: 'Storage Permission',
          message: 'App needs access to memory to download the file '
        }
      );
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        this.downloadImage();
      } else {
        Alert.alert(
          'Permission Denied!',
          'You need to give storage permission to download the file'
        );
      }
    } catch (err) {
      console.warn(err);
    }
  }

  downloadImage() {
    const name = shorthash.unique(this.state.imageUri);
    const extension = Platform.OS === 'android' ? 'file://' : '';
    const path =
      Platform.OS === 'ios'
        ? `${extension}${RNFS.DocumentDirectoryPath}/${name}.png`
        : `${extension}${RNFS.PicturesDirectoryPath}/${name}.png`;
    console.log(path);
    RNFS.exists(path)
      .then(exists => {
        if (exists) {
          alert('File already exists');
          return;
        } else {
          RNFS.downloadFile({
            fromUrl: this.state.imageUri,
            toFile: path
          })
            .promise.then(res => alert('download complete'))
            .catch(err => alert(err));
        }
      })
      .catch(err => alert(err));
  }

  render() {
    const { isLoaded, isLoadingMore, reportList } = this.state;
    console.log(reportList);

    if (!isLoaded) {
      return (
        <View style={{ flex: 1 }}>
          <Header
            text='Medical Report'
            iconLeft='arrowleft'
            iconRight='shoppingcart'
            navigation={this.props.navigation}
          />
          <SpinView />
        </View>
      );
    }

    return (
      <View style={{ flex: 1 }}>
        <Header
          text='Medical Report'
          iconLeft='arrowleft'
          iconRight='shoppingcart'
          navigation={this.props.navigation}
        />

        <ImageView
          images={[
            {
              source: {
                uri: this.state.imageUri
              },
              title: 'Paris'
              // width: width-100,
              // height: height-200
            }
          ]}
          imageIndex={0}
          isVisible={this.state.isVisible}
          renderFooter={currentImage => (
            <View
              style={{
                paddingBottom: 20,
                backgroundColor: 'rgba(0, 0, 0, 0.4)'
              }}
            >
              <TouchableOpacity
                onPress={() =>
                  Platform.OS === 'ios'
                    ? this.downloadImage()
                    : this.downloadFile()
                }
              >
                <Icon name='download' type='antdesign' color='white' />
              </TouchableOpacity>
            </View>
          )}
        />
        <View style={styles.container}>
          <FlatList
            onEndReached={(info: { distanceFromEnd: number }) => {
              this.handlePaginate();
            }}
            onEndReachedThreshold={0.2}
            data={reportList}
            renderItem={({ item, index }) => (
              <TouchableOpacity
                onPress={() =>
                  this.setState({ isVisible: true, imageUri: item.url })
                }
                style={styles.cardStyle}
              >
                {/* <View style={styles.cardStyle}> */}
                <View style={styles.cardHeading}>
                  <Text style={styles.headerText}>{item.name}</Text>
                </View>
                <View
                  style={{ height: 1, backgroundColor: 'grey', opacity: 0.5 }}
                />
                <View style={styles.cardBody}>
                  <View style={{ flex: 7 }}>
                    <View style={{ height: 28 }}>
                      <Text style={styles.text} numberOfLines={1}>
                        {item.patient_name}
                      </Text>
                    </View>
                    <View style={styles.row}>
                      <Text style={styles.text}>Date: </Text>
                      <Text style={styles.text}>
                        {moment(item.date).format('LL')}
                      </Text>
                    </View>
                    <View style={styles.row}>
                      <Text style={styles.text}>Report Id: </Text>
                      <Text style={styles.text}>{item.reportId}</Text>
                    </View>
                    <View style={styles.row}>
                      <Text style={styles.text}>Status: </Text>
                      <Text style={styles.text}>{item.status}</Text>
                    </View>
                  </View>
                  <View
                    style={{
                      flex: 3,
                      height: 100,
                      width: 105
                    }}
                  >
                    <Image
                      resizeMode='contain'
                      source={{
                        uri: item.url
                      }}
                      style={{ width: '100%', height: '110%' }}
                    />
                  </View>
                </View>
                {/* </View> */}
              </TouchableOpacity>
            )}
          />
          {this.state.isLoadingMore && (
            <View style={{ position: 'relative', bottom: 20 }}>
              <Spinner
                type='ThreeBounce'
                isVisible={this.state.isLoadingMore}
                size={50}
                color='grey'
              />
            </View>
          )}
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white'
  },

  cardStyle: {
    backgroundColor: 'white',
    // borderWidth: 1,
    borderRadius: 10,
    width: width - 20,
    elevation: 2,
    marginLeft: 10,
    marginRight: 10,
    marginTop: 5,
    marginBottom: 5,
    shadowOffset: { width: 3, height: 3 },
    shadowColor: 'grey',
    shadowOpacity: 0.25,
    shadowRadius: 7
  },

  cardHeading: {
    height: 40,
    justifyContent: 'center',
    alignItems: 'center'
  },

  headerText: {
    fontSize: 20,
    color: 'black'
  },

  cardBody: {
    // height: 110,
    padding: 8,
    flexDirection: 'row',
    justifyContent: 'space-between'
  },

  text: {
    fontSize: 18
  },

  row: {
    height: 28,
    width: '100%',
    flexDirection: 'row'
  }
});
