import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  ScrollView,
  View,
  Dimensions,
  Image
} from 'react-native';
import Header from '../common/header';

const { width, height } = Dimensions.get('window');

export default class AboutUs extends Component {
  render() {
    return (
      <View style={styles.container}>
        <Header
          text="About Us"
          iconLeft="arrowleft"
          iconRight="shoppingcart"
          navigation={this.props.navigation}
        />

        <ScrollView
          style={styles.scrollingView}
          // contentContainerStyle={{
          //   justifyContent: 'flex-start',
          //   alignItems: 'flex-start',
          // }}
        >
          <View
            style={{
              justifyContent: 'center',
              alignItems: 'center',
              marginTop: 10,
              height: height * 0.15,
            }}
          >
            <Image
              source={require('../../assets/LabaidLogo.png')}
              style={{ width: 140, height: 100 }}
            />
          </View>
          <View style={{ paddingBottom: 15, paddingTop: 35 }}>
            <Text style={{ fontSize: 15 }}>
              Labaid Group adds yet another feather in its ornate cap - Labaid
              Hospital commissioned on 15 July 2004. A new era in the field of
              care is dawned, a new chapter opened.
            </Text>
          </View>
          <View style={{ paddingBottom: 15 }}>
            <Text style={{ fontSize: 15 }}>
              Labaid Hospital - the fist international standard super-specialty
              hospital of the country, dedicated exclusively to the diagnosis
              and treatment of cardiovascular diseases have been built on a six
              storied building at, Dhanmondi - a commercial cum residential hub
              of Dhaka City, covering a floor space of more than 100000 sq.
              feet.
            </Text>
          </View>
          <View style={{ paddingBottom: 15 }}>
            <Text style={{ fontSize: 15 }}>
              Rapid urbanization, ever changing life style coupled with physical
              inactivity and unhealthy food habit amongst urban population have
              contributed to increased incidence of heart ailments in this
              category of people. Labaid Specialized Hospital, a super specialty
              hospital of international standard manned by renowned
              cardiologists, cardiac surgeons and other support staff shall play
              an all important role in providing optimum care and treatment to
              cardiac patients of the country.{' '}
            </Text>
          </View>
        </ScrollView>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    // justifyContent: 'flex-start',
    alignItems: 'center',
    backgroundColor: '#ffffff'
  },
  scrollingView: {
    flexDirection: 'column',
    flex: 0.85,
    paddingHorizontal: 20,
    width: '100%'
  }
});
