import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  ScrollView,
  Image,
  TouchableOpacity,
} from 'react-native';
import Header from '../common/header';
import ViewHomeCare from '../common/rectangleViewHomeCare';

export default class HomeCare extends Component {
  render() {
    return (
      <View style={styles.container}>
        <Header
          text="Home Care"
          iconLeft="arrowleft"
          iconRight="shoppingcart"
          navigation={this.props.navigation}
        />
        <View style={{ flex: 1, width: '100%' }}>
          <ScrollView
            style={styles.scrollingView}
            contentContainerStyle={{
              justifyContent: 'flex-start',
              alignItems: 'center',
            }}
          >
            {/* <TouchableOpacity
              onPress={() =>
                this.props.navigation.navigate('NursingCare', {
                  title: 'Nursing Care'
                })
              }
            > */}
            <ViewHomeCare
              navigation={this.props.navigation}
              title="Nursing Care"
              imageText="Nursing Care"
              imgAsComponent={
                <Image
                  source={require('../../assets/customIcons/nurse.png')}
                  style={{ width: 40, height: 40 }}
                />
              }
              rectangleHeight={98}
              flexLeft={0.3}
              flexRight={0.7}
              bottomMargin={8}
            />
            {/* </TouchableOpacity> */}

            {/* <TouchableOpacity
              onPress={() =>
                this.props.navigation.navigate('NursingCare', {
                  title: 'Portable ECG'
                })
              }
            > */}
            <ViewHomeCare
              navigation={this.props.navigation}
              title="Portable ECG"
              imageText="Portable ECG"
              imgAsComponent={
                <Image
                  source={require('../../assets/customIcons/heart.png')}
                  style={{ width: 40, height: 34 }}
                />
              }
              rectangleHeight={98}
              flexLeft={0.3}
              flexRight={0.7}
              bottomMargin={8}
            />
            {/* </TouchableOpacity> */}

            {/* <TouchableOpacity
              onPress={() =>
                this.props.navigation.navigate('NursingCare', {
                  title: '2D Ultrasonogram'
                })
              }
            > */}
            <ViewHomeCare
              navigation={this.props.navigation}
              title="2D Ultrasonogram"
              imageText="2D Ultrasonogram"
              imgAsComponent={
                <Image
                  source={require('../../assets/customIcons/patient2.png')}
                  style={{ width: 40, height: 34 }}
                />
              }
              rectangleHeight={98}
              flexLeft={0.3}
              flexRight={0.7}
              bottomMargin={8}
            />
            {/* </TouchableOpacity> */}

            {/* <TouchableOpacity
              onPress={() =>
                this.props.navigation.navigate('NursingCare', {
                  title: 'Physiotherapy'
                })
              }
            > */}
            <ViewHomeCare
              navigation={this.props.navigation}
              title="Physiotherapy"
              imageText="Physiotherapy"
              imgAsComponent={
                <Image
                  source={require('../../assets/customIcons/brain.png')}
                  style={{ width: 40, height: 40 }}
                />
              }
              rectangleHeight={98}
              flexLeft={0.3}
              flexRight={0.7}
              bottomMargin={8}
            />
            {/* </TouchableOpacity> */}
          </ScrollView>
        </View>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  scrollingView: {
    flex: 1,
    paddingTop: 15,
    paddingBottom: 10,
    width: '100%',
  },
  viewStyle: {
    width: '94%',
    backgroundColor: '#ffffff',
    elevation: 1.5,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    borderRadius: 8,
    shadowOffset: { width: 3, height: 3 },
    shadowColor: 'grey',
    shadowOpacity: 0.25,
    shadowRadius: 5,
  },
});
