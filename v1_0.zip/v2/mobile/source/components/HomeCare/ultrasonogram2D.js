import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Dimensions,
  Image,
  TextInput,
  TouchableOpacity,
  Picker,
  ScrollView,
  KeyboardAvoidingView
} from 'react-native';
import { CheckBox } from 'react-native-elements';
import Modal from 'react-native-modal';
import { Button, Fab } from 'native-base';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import Header from '../common/header';
import GreenButton from '../common/lifeplusGreenButton';
import call from 'react-native-phone-call';

export default class Ultrasonogram2D extends Component {
  state = {
    text: '',
    isModalVisible: false,
    chosenValueCity: 'key0',
    chosenValueArea: 'key0'
  };

  modalMethod = () => {
    this.setState({ isModalVisible: !this.state.isModalVisible });
  };

  render() {
    const args = {
      number: '999',
      prompt: false
    };

    return (
      <ScrollView>
        <KeyboardAvoidingView style={styles.container}>
          <Header
            text="2D Ultrasonogram"
            iconLeft="arrowleft"
            iconRight="shoppingcart"
            navigation={this.props.navigation}
          />

          <View style={styles.viewStyle}>
            <View
              style={{
                flex: 25,
                elevation: 1.5,
                backgroundColor: 'white',
                marginTop: 10,
                borderRadius: 20
              }}
            >
              <Text style={styles.textViewStyle}> Patient's Address</Text>

              <View style={styles.dropDownViewStyle}>
                <Text
                  style={{
                    flex: 0.4,
                    fontSize: 16,
                    fontWeight: 'bold',
                    paddingLeft: 10
                  }}
                >
                  Select City:{' '}
                </Text>

                <Picker
                  style={{ flex: 0.6 }}
                  selectedValue={this.state.chosenValueCity}
                  mode="dropdown"
                  onValueChange={(itemValue, itemIndex) =>
                    this.setState({ chosenValueCity: itemValue })
                  }
                >
                  <Picker.Item label="Select City" value="key0" />
                  <Picker.Item label="Dhaka" value="key1" />
                  <Picker.Item label="Chittagong" value="key2" />
                  <Picker.Item label="Sylhet" value="key3" />
                </Picker>
              </View>
              <Text
                style={{
                  fontSize: 16,
                  paddingBottom: 5,
                  fontWeight: 'bold',
                  paddingLeft: 10
                }}
              >
                Detail Address:
              </Text>
              <View style={styles.addressInputStyle}>
                <TextInput
                  placeholder="Type patient's address"
                  multiline={true}
                  editable={true}
                  onChangeText={text => this.setState({ text })}
                  value={this.state.text}
                  style={{ backgroundColor: '#ddddddaa' }}
                  numberOfLines={4}
                  textAlignVertical="top"
                  underlineColorAndroid="transparent"
                />
              </View>
            </View>
            <Text style={styles.textViewStyle}> Patient's Details</Text>

            <View style={styles.patientInfoViewStyle}>
              <View style={styles.nameViewStyle}>
                <TextInput
                  style={{
                    height: 40,
                    borderColor: 'gray',
                    borderBottomWidth: 1,
                    fontSize: 18,
                    fontSize: 16
                  }}
                  value={this.state.nameText}
                  onChangeText={nameText => this.setState({ nameText })}
                  placeholder="Type patient's name"
                />
              </View>
              <View style={styles.genderViewStyle}>
                <Text
                  style={{ fontSize: 16, fontWeight: 'bold', color: '#777777' }}
                >
                  Gender
                </Text>
                <CheckBox
                  title="Male"
                  checked={this.state.checkMale}
                  containerStyle={styles.checkBoxStyle}
                  onPress={() =>
                    this.setState({ checkMale: !this.state.checkMale })
                  }
                />

                <CheckBox
                  title="Female"
                  checked={this.state.checkFemale}
                  containerStyle={styles.checkBoxStyle}
                  onPress={() =>
                    this.setState({ checkFemale: !this.state.checkFemale })
                  }
                />
              </View>

              <View style={styles.specsViewStyle} alignItems="flex-start">
                <TextInput
                  style={{
                    flex: 0.2,
                    height: 40,
                    borderColor: 'gray',
                    fontSize: 15
                  }}
                  value={this.state.age}
                  onChangeText={age => this.setState({ age })}
                  placeholder="Age"
                  multiline={false}
                  borderBottomWidth={1}
                  width={120}
                />

                <Picker
                  style={{ flex: 0.75 }}
                  selectedValue={this.state.chosenValue}
                  mode="dropdown"
                  onValueChange={(itemValue, itemIndex) =>
                    this.setState({ chosenValue: itemValue })
                  }
                >
                  <Picker.Item label="Select Patient Condition" value="key0" />
                  <Picker.Item label="             Mildly Sick" value="key1" />
                  <Picker.Item label="             Moderate" value="key2" />
                  <Picker.Item label="             Severe" value="key3" />
                </Picker>
              </View>

              <View style={styles.phoneNumberViewStyle}>
                <Text style={styles.numberHolderStyle}>Mobile Number</Text>
                <Text style={styles.numberPrefixStyle}>+880</Text>
                <TextInput
                  style={styles.numberInputStyle}
                  value={this.state.inputText}
                  onChangeText={inputText => this.setState({ inputText })}
                  width={155}
                />
              </View>
            </View>

            <View style={styles.payCashViewStyle}>
              <Text style={{ fontSize: 16, fontWeight: 'bold' }}>
                Payment Method
              </Text>
              <View style={{ flexDirection: 'row' }}>
                <Text style={{ fontSize: 16, color: '#1285ff' }}>
                  Cash on Delivery{' '}
                </Text>
                <Icon name="arrow-right" size={20} color="#1285ff" />
              </View>
            </View>

            <View style={styles.button}>
              <GreenButton
                buttonText="  Send Request  "
                buttonFont={20}
                passFunction={this.modalMethod}
              />
            </View>
          </View>

          <Modal
            style={styles.modalStyle}
            transparent={true}
            isVisible={this.state.isModalVisible}
            onBackButtonPress={() => {
              this.modalMethod();
            }}
          >
            <View style={styles.modalInsideViewStyle}>
              <View style={styles.modalChildStyle} justifyContent="flex-end">
                <Image
                  source={require('../../assets/customIcons/patient2.png')}
                  style={{ width: 40, height: 40 }}
                />
              </View>

              <View style={styles.modalChildStyle} justifyContent="center">
                <Text
                  style={{
                    fontSize: 19,
                    textAlign: 'center',
                    marginLeft: 30,
                    marginRight: 30
                  }}
                >
                  Do you want to make a call for 2D Ultrasonogram Home care
                  service?
                </Text>
              </View>

              <View style={styles.modalButtonView}>
                <View
                  style={{
                    width: '50%',
                    justifyContent: 'center',
                    alignItems: 'center',
                    paddingLeft: 5
                  }}
                >
                  <Button
                    bordered
                    primary
                    rounded
                    onPress={() => this.modalMethod()}
                  >
                    <Text style={{ fontSize: 20 }}> Later </Text>
                  </Button>
                </View>

                <View
                  style={{ justifyContent: 'center', alignItems: 'center' }}
                >
                  <GreenButton
                    passFunction={() => call(args).catch(console.error)}
                    buttonText="       Call       "
                    buttonFont={20}
                  />
                </View>
              </View>
            </View>
          </Modal>
        </KeyboardAvoidingView>
      </ScrollView>
    );
  }
}

const height = Dimensions.get('window').height;

var styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    flex: 1,
    alignItems: 'center'
  },
  viewStyle: {
    flex: 1,
    width: '92%'
  },
  textViewStyle: {
    flex: 5,
    fontSize: 16,
    fontWeight: 'bold',
    paddingTop: 16,
    height: (height * 5) / 100
  },
  dropDownViewStyle: {
    flex: 15,
    flexDirection: 'row',
    alignItems: 'center',
    height: (height * 15) / 100
  },
  addressInputStyle: {
    flex: 15,
    height: (height * 15) / 100
  },
  patientInfoViewStyle: {
    flex: 45,
    backgroundColor: '#ffffff',
    elevation: 1.5,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 5,
    height: (height * 45) / 100
  },
  button: {
    flex: 15,
    justifyContent: 'center',
    alignItems: 'center',
    height: (height * 15) / 100
  },
  nameViewStyle: {
    flex: 18,
    width: '92%',
    justifyContent: 'center'
  },
  genderViewStyle: {
    flex: 15,
    width: '92%',
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    alignItems: 'center'
  },
  phoneNumberViewStyle: {
    flex: 20,
    width: '92%',
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    marginBottom: 10
  },
  numberHolderStyle: {
    position: 'absolute',
    bottom: 20,
    fontSize: 15,
    left: 4
  },
  numberPrefixStyle: {
    position: 'absolute',
    bottom: 20,
    left: 105,
    fontSize: 15,
    fontWeight: 'bold'
  },
  numberInputStyle: {
    height: 40,
    borderColor: 'gray',
    borderBottomWidth: 1,
    fontSize: 16,
    position: 'absolute',
    bottom: 10,
    left: 150
  },
  checkBoxStyle: {
    backgroundColor: '#ffffff',
    width: '36%'
  },
  specsViewStyle: {
    flex: 10,
    width: '92%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  smallViewStyle: {
    flex: 0.5,
    alignItems: 'center'
  },
  modalStyle: {
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1
  },
  modalInsideViewStyle: {
    flex: 0.5,
    justifyContent: 'flex-start',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    width: '100%',
    borderRadius: 10
  },
  modalChildStyle: {
    flex: 0.33,
    width: '100%',
    alignItems: 'center'
  },
  modalButtonView: {
    flex: 0.33,
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center'
  },
  payCashViewStyle: {
    flex: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: (height * 10) / 100
  }
});
