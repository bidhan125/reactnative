export const stackNavigatorConfig = {
  headerMode: 'none'
};
