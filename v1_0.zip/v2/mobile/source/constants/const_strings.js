export const version = 'Version 0.2.9';

export const relations = [
  'Father',
  'Mother',
  'Sister',
  'Brother',
  'Spouse',
  'Son',
  'Daughter',
  'Father in Law',
  'Mother in Law',
  'Sister in Law',
  'Brother in Law',
  'Nephew',
  'Niece',
  'Grandfather',
  'Grandmother',
  'Grandson',
  'Grand daughter',
  'Uncle',
  'Aunt'
];

export const blood_group = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];

export const order_types = [
  'single_test',
  'package_test',
  'medicine',
  'medical_tools',
  'home_care',
  'report_delivery'
];

export const districtList = [
  { name: 'Dhaka' },
  { name: 'Faridpur' },
  { name: 'Gazipur' },
  { name: 'Gopalganj' },
  { name: 'Jamalpur' },
  { name: 'Kishoreganj' },
  { name: 'Madaripur' },
  { name: 'Manikganj' },
  { name: 'Munshiganj' },
  { name: 'Mymensingh' },
  { name: 'Narayanganj' },
  { name: 'Narsingdi' },
  { name: 'Netrokona' },
  { name: 'Rajbari' },
  { name: 'Shariatpur' },
  { name: 'Sherpur' },
  { name: 'Tangail' },
  { name: 'Bogra' },
  { name: 'Joypurhat' },
  { name: 'Naogaon' },
  { name: 'Natore' },
  { name: 'Nawabganj' },
  { name: 'Pabna' },
  { name: 'Rajshahi' },
  { name: 'Sirajgonj' },
  { name: 'Dinajpur' },
  { name: 'Gaibandha' },
  { name: 'Kurigram' },
  { name: 'Lalmonirhat' },
  { name: 'Nilphamari' },
  { name: 'Panchagarh' },
  { name: 'Rangpur' },
  { name: 'Thakurgaon' },
  { name: 'Barguna' },
  { name: 'Barisal' },
  { name: 'Bhola' },
  { name: 'Jhalokati' },
  { name: 'Patuakhali' },
  { name: 'Pirojpur' },
  { name: 'Bandarban' },
  { name: 'Brahmanbaria' },
  { name: 'Chandpur' },
  { name: 'Chittagong' },
  { name: 'Comilla' },
  { name: 'Cox’s Bazar' },
  { name: 'Feni' },
  { name: 'Khagrachari' },
  { name: 'Lakshmipur' },
  { name: 'Noakhali' },
  { name: 'Rangamati' },
  { name: 'Habiganj' },
  { name: 'Maulvibazar' },
  { name: 'Sunamganj' },
  { name: 'Sylhet' },
  { name: 'Bagerhat' },
  { name: 'Chuadanga' },
  { name: 'Jessore' },
  { name: 'Jhenaidah' },
  { name: 'Khulna' },
  { name: 'Kushtia' },
  { name: 'Magura' },
  { name: 'Meherpur' },
  { name: 'Narail' },
  { name: 'Satkhira' }
];

export const branchCity = [
  { name: 'Dhaka' },
  { name: 'Faridpur' },
  { name: 'Gazipur' },
  { name: 'Narayanganj' },
  { name: 'Munshiganj' },
  { name: 'Mymensingh' },
  { name: 'Sylhet' },
  { name: 'Chittagong' },
  { name: 'Noakhali' },
  { name: 'Khulna' },
  { name: 'Jessore' },
  { name: 'Barisal' },
  { name: 'Bogra' },
  { name: 'Naogaon' },
  { name: 'Pabna' },
  { name: 'Rajshahi' },
  { name: 'Rangpur' },
  { name: 'Dinajpur' }
];

export const medicine_types = [
  { name: 'Tablet', icon: 'tablet.png' },

  { name: 'Capsule', icon: 'capsules.png' },

  { name: 'Injection', icon: 'injection.png' },

  { name: 'Syrup', icon: 'liquid.png' },
  { name: 'Suspension', icon: 'liquid.png' },
  { name: 'Powder for Suspension', icon: 'liquid.png' },

  { name: 'Gel', icon: 'topical.png' },
  { name: 'Eye gel', icon: 'topical.png' },
  { name: 'Topical Solution', icon: 'topical.png' },
  { name: 'Cream', icon: 'topical.png' },
  { name: 'Ointment', icon: 'topical.png' },
  // { name: 'Scalp Lotion', icon: 'topical.png' },

  { name: 'Suppository', icon: 'suppositories.png' },

  { name: 'Eye Drops', icon: 'drops.png' },
  { name: 'Paediatric Drops', icon: 'drops.png' },

  { name: 'Inhaler', icon: 'inhalers.png' },
  { name: 'Mouthwash', icon: 'inhalers.png' },

  { name: 'Implants or patches', icon: 'implants.png' },
  { name: 'Buccal or sublingual tablets or liquids', icon: 'buccal.png' }
];

export const feedback_type = {
  signIn: 'Problem in SignIn',
  appCrash: 'App Crashing',
  notWorking: 'App not working',
  others: 'Others'
};

export const colors = {
  red: '#db2828',
  orange: '#f2711c',
  yellow: '#fbbd08',
  olive: '#b5cc18',
  green: '#21ba45',
  teal: '#00b5ad',
  blue: '#2185d0',
  voilet: '#6435c9',
  purple: '#a333c8',
  pink: '#e03997',
  brown: '#a5673f',
  grey: '#767676',
  black: '#1b1c1d'
};
