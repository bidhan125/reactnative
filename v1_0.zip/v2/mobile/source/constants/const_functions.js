import moment from 'moment';
import { AsyncStorage, Dimensions } from 'react-native';
import Meteor from 'react-native-meteor';

export const getUserAsync = async () => {
  const user = await AsyncStorage.getItem('user');
  return user;
};

const { width, height } = Dimensions.get('window');

//Guideline sizes are based on standard ~5" screen mobile device
const guidelineBaseWidth = 350;
const guidelineBaseHeight = 620;

const scale = size => (width / guidelineBaseWidth) * size;
const verticalScale = size => (height / guidelineBaseHeight) * size;
const moderateScale = (size, factor = 0.25) =>
  size + (scale(size) - size) * factor;

export { scale, verticalScale, moderateScale };

export function validation(value, fieldType) {
  switch (fieldType) {
    case 'isName':
      if (value === undefined || !isNaN(value) || value.length <= 2) {
        return alert('Please give your name.');
      } else {
        return true;
      }

    case 'isPassword':
      if (value === undefined || value.length < 4) {
        return alert(
          'The password must be greater than or equal four chartacters'
        );
      } else return true;

    case 'isPhone':
      var phone = new RegExp(/^01\d{9}$/);
      if (isNaN(value)) {
        return alert('Please give valid phone number');
      } else if (value.match(phone)) {
        return true;
      } else return alert('Please give valid phone number');

    case 'isDob':
      console.log('called');
      var age = moment().diff(moment(value, 'YYYY-MM-DD'), 'years');
      console.log('age:', age);
      if (age <= 0) {
        return alert('Please give a valid date of birth.');
      } else return true;

    case 'isEmail':
      var mailformat = new RegExp(
        /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/
      );
      if (value === undefined || value.length <= 0) {
        return alert('Enter a valid email address');
      } else if (value.match(mailformat)) {
        return true;
      } else {
        return alert('Enter a valid email address');
      }

    default:
      break;
  }
}

export const fetchCartData = async context => {
  await AsyncStorage.getItem('cart', (err, res) => {
    const cart = res ? JSON.parse(res) : {};
    context.setState({ cart });
  });
};

export const updateCart = async (cart, context) => {
  await AsyncStorage.setItem('cart', JSON.stringify(cart), (err, res) => {
    context.setState({ cart });
  });
};

export const logout = () => {
  Meteor.logout(() => {
    console.log('Logged out successfully!');
    AsyncStorage.multiRemove(['user', 'cart']);
  });
};
