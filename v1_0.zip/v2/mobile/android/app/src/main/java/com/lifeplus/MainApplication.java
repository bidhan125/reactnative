package com.lifeplus;

import android.app.Application;

import com.facebook.react.ReactApplication;
import org.wonday.pdf.RCTPdfView;
import com.RNFetchBlob.RNFetchBlobPackage;
import com.RNTextInputMask.RNTextInputMaskPackage;
import com.reactnativecommunity.webview.RNCWebViewPackage;
import com.horcrux.svg.SvgPackage;
import com.rnfs.RNFSPackage;
import com.imagepicker.ImagePickerPackage;
import com.azendoo.reactnativesnackbar.SnackbarPackage;
import com.react.rnspinkit.RNSpinkitPackage;
import com.reactlibrary.RNRearCameraCharacteristicsDisplayMetricsPackage;
import com.learnium.RNDeviceInfo.RNDeviceInfo;
import com.BV.LinearGradient.LinearGradientPackage;
import com.swmansion.reanimated.ReanimatedPackage;
import com.oblador.vectoricons.VectorIconsPackage;
import com.swmansion.gesturehandler.react.RNGestureHandlerPackage;
import com.facebook.react.ReactNativeHost;
import com.facebook.react.ReactPackage;
import com.facebook.react.shell.MainReactPackage;
import com.facebook.soloader.SoLoader;

import java.util.Arrays;
import java.util.List;

public class MainApplication extends Application implements ReactApplication {

  private final ReactNativeHost mReactNativeHost = new ReactNativeHost(this) {
    @Override
    public boolean getUseDeveloperSupport() {
      return BuildConfig.DEBUG;
    }

    @Override
    protected List<ReactPackage> getPackages() {
      return Arrays.<ReactPackage>asList(new MainReactPackage(),
            new RCTPdfView(),
            new RNFetchBlobPackage(),
            new RNTextInputMaskPackage(),
            new RNCWebViewPackage(),
            new SvgPackage(),
            new RNFSPackage(),
            new ImagePickerPackage(), new SnackbarPackage(), new RNSpinkitPackage(),
          new RNRearCameraCharacteristicsDisplayMetricsPackage(), new RNDeviceInfo(), new LinearGradientPackage(),
          new ReanimatedPackage(), new VectorIconsPackage(), new RNGestureHandlerPackage(),
          new LinearGradientPackage());
    }

    @Override
    protected String getJSMainModuleName() {
      return "index";
    }
  };

  @Override
  public ReactNativeHost getReactNativeHost() {
    return mReactNativeHost;
  }

  @Override
  public void onCreate() {
    super.onCreate();
    SoLoader.init(this, /* native exopackage */ false);
  }
}
